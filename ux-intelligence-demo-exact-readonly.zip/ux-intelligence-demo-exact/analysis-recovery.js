// Recovery reads document-owned history only. It never derives insights from the KB.
const documentRecoveryCandidates = new Map();
function recoverableDocumentMaterial(document, historical) {
  if (!document?.id || historical?.id !== document.id) return false;
  const file = document.originalName || document.fileMeta?.name;
  const oldFile = historical.originalName || historical.fileMeta?.name;
  if (file && oldFile && file !== oldFile) return false;
  const review = historical.archivedReview, interpretation = review?.interpretation;
  const originals = interpretation?.originalRecords, units = interpretation?.units, insights = review?.insights;
  if (!originals?.length || !units?.length || !insights?.length) return false;
  if (!Array.isArray(interpretation.tableRows)) return false;
  const sourceOwned = record => record?.id && typeof record.text === 'string' && record.source?.documentId === document.id;
  if (!originals.every(record => sourceOwned(record) && sourceOwned(record.originalFinding))) return false;
  if (!units.every(sourceOwned)) return false;
  const originalIds = new Set(originals.map(record => record.id)), unitIds = new Set(units.map(unit => unit.id));
  if (originalIds.size !== originals.length || unitIds.size !== units.length) return false;
  if (!units.every(unit => originalIds.has(unit.id) || unit.originalFindingIds?.length && unit.originalFindingIds.every(id => originalIds.has(id)))) return false;
  const assigned = insights.flatMap(insight => insight.findings || []);
  if (new Set(insights.map(insight => insight.id)).size !== insights.length ||
      !insights.every(insight => insight.id && typeof insight.displayTitle === 'string' &&
        typeof insight.displaySynthesis === 'string' && ['pages','devices','types','contextTags'].every(key => Array.isArray(insight[key])) &&
        insight.findings?.length && insight.findings.every(sourceOwned))) return false;
  if (assigned.length !== units.length || new Set(assigned.map(unit => unit.id)).size !== units.length ||
      !assigned.every(unit => unitIds.has(unit.id) && unit.text === units.find(record => record.id === unit.id).text)) return false;
  // A publication without its operations is insufficient to safely reopen published decisions.
  if (review.publicationStamp && (historical.analysis?.publication?.status !== 'published' ||
      historical.analysis.publication.publishedAt !== review.publicationStamp || !historical.analysis.publication.operations?.length)) return false;
  if (historical.analysis?.findings?.length && JSON.stringify(historical.analysis.findings) !== JSON.stringify(originals.map(record => record.originalFinding))) return false;
  return true;
}
function hasRecoveredDocumentAnalysis(item) {
  return Boolean(item?.analysis?.recovery?.documentId === item?.id && recoverableDocumentMaterial(item,item));
}
function documentAnalysisRecoverable(item) {
  return !hasDocumentAnalysis(item) && documentRecoveryCandidates.has(item.id);
}
async function discoverRecoverableAnalyses() {
  if (!projectHistory.ready || projectHistory.error) return;
  try {
    const response = await fetch('/api/history/recoverable', {cache:'no-store'});
    if (!response.ok) throw Error('No se ha podido consultar el material histórico recuperable.');
    const {candidates = []} = await response.json();
    for (const item of sourceItems) {
      if (hasDocumentAnalysis(item) || !hasDocumentHistory(item)) continue;
      const local = {document:item, revision:projectHistory.revision};
      const candidate = [local,...candidates.filter(candidate => candidate.document?.id === item.id)]
        .find(candidate => recoverableDocumentMaterial(item,candidate.document));
      if (candidate) documentRecoveryCandidates.set(item.id,JSON.parse(JSON.stringify(candidate)));
    }
  } catch (error) { console.error('[UX Intel recuperación histórica]', error); }
}
async function recoverDocumentAnalysis(item) {
  const candidate = documentRecoveryCandidates.get(item.id);
  if (!candidate || !recoverableDocumentMaterial(item,candidate.document)) return false;
  const historical = JSON.parse(JSON.stringify(candidate.document));
  const before = {analysis:item.analysis, archivedReview:item.archivedReview, hasAnalysis:item.hasAnalysis};
  // Empty structural fields mean unavailable, never inferred pages, text or classifications.
  const analysis = historical.analysis || {
    findings:historical.archivedReview.interpretation.originalRecords.map(record => record.originalFinding),
    pages:null, extractedPages:[], extractedText:'', extraction:{}, coverage:{},
    metadata:{products:[],screens:[],components:[],devices:[],markets:[]},
    relations:historical.archivedReview.insights.flatMap(insight => insight.relations || []), clusterReview:{}
  };
  analysis.recovery = {documentId:item.id, revision:candidate.revision, recoveredAt:new Date().toISOString()};
  item.analysis=analysis; item.archivedReview=historical.archivedReview; item.hasAnalysis=true;
  try {
    await saveDocumentAnalysis(item.id,analysis);
    if (!await queueProjectHistory()) throw Error('No se ha guardado el análisis recuperado.');
    safeStorageWrite(); documentRecoveryCandidates.delete(item.id); renderSources();
    return true;
  } catch (error) {
    Object.assign(item,before);
    await saveDocumentAnalysis(item.id,before.analysis || null);
    showToast('No se ha recuperado el análisis',error.message);
    return false;
  }
}
