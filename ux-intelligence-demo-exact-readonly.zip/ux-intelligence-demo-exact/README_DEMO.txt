UX Intelligence Demo - solo consulta.
Esta copia conserva la interfaz exacta y los datos de consulta necesarios para explorar, filtrar y exportar CSV.
No incluye los archivos fuente originales y no guarda cambios.
