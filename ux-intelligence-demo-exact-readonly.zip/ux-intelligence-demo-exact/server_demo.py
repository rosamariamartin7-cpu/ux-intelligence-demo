#!/usr/bin/env python3
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import os, json, hashlib, mimetypes, re

ROOT = Path(__file__).resolve().parent
HISTORY = ROOT / 'history'
TAXONOMY = ROOT / 'taxonomy-state.json'
SOURCE_FILES = ROOT / 'data' / 'source-files'
HOST = '0.0.0.0'
PORT = int(os.environ.get('PORT','4175'))
HEX64 = re.compile(r'^[0-9a-f]{64}$')


def read_history():
    pointer = HISTORY / 'latest.json'
    if not pointer.exists():
        return {'revision': None, 'snapshot': None}
    revision = json.loads(pointer.read_text(encoding='utf-8')).get('revision')
    if not isinstance(revision,str) or not HEX64.match(revision):
        raise RuntimeError('Referencia histórica no válida')
    snap = HISTORY / f'{revision}.json'
    if not snap.exists():
        raise RuntimeError('Snapshot histórico no encontrado')
    return {'revision': revision, 'snapshot': json.loads(snap.read_text(encoding='utf-8'))}


def read_taxonomy():
    state=json.loads(TAXONOMY.read_text(encoding='utf-8'))
    compact=json.dumps(state, ensure_ascii=False, separators=(',',':')).encode('utf-8')
    return {'revision': hashlib.sha256(compact).hexdigest(), 'state':state}


def recoverable_history():
    current = read_history().get('snapshot') or {}
    docs=current.get('documents') if isinstance(current.get('documents'),list) else []
    missing={d.get('id') for d in docs if isinstance(d,dict) and not d.get('analysis') and d.get('id')}
    candidates=[]
    for path in sorted(HISTORY.glob('*.json'), key=lambda p:p.stat().st_mtime, reverse=True):
        if not HEX64.match(path.stem):
            continue
        try: snap=json.loads(path.read_text(encoding='utf-8'))
        except Exception: continue
        for item in snap.get('documents') or []:
            if isinstance(item,dict) and item.get('id') in missing and isinstance(item.get('archivedReview'),dict) and item['archivedReview'].get('insights'):
                candidates.append({'revision':path.stem,'document':item})
    return {'candidates':candidates}


def safe_segment(value, fallback):
    cleaned=''.join(ch if (ch.isalnum() or ch in '. _-') else '_' for ch in str(value)).strip(' ._')[:180]
    return cleaned or fallback


def source_file(doc_id, kind):
    if kind not in {'insight-register','document'}:
        return None
    directory=SOURCE_FILES / safe_segment(doc_id,'document') / kind
    if not directory.is_dir():
        return None
    files=[p for p in directory.iterdir() if p.is_file() and not p.name.endswith('.tmp')]
    return max(files,key=lambda p:p.stat().st_mtime) if files else None

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,directory=str(ROOT),**kwargs)

    def log_message(self, fmt, *args):
        print('%s - %s' % (self.address_string(), fmt%args))

    def end_headers(self):
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','SAMEORIGIN')
        self.send_header('Referrer-Policy','same-origin')
        self.send_header('X-Robots-Tag','noindex, nofollow, noarchive')
        super().end_headers()

    def json_out(self,status,payload):
        body=json.dumps(payload,ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(body)))
        self.send_header('Cache-Control','no-store')
        self.end_headers(); self.wfile.write(body)

    def do_GET(self):
        parsed=urlparse(self.path)
        if parsed.path=='/api/history':
            try: return self.json_out(200,read_history())
            except Exception as e: return self.json_out(500,{'error':str(e)})
        if parsed.path=='/api/history/recoverable':
            try: return self.json_out(200,recoverable_history())
            except Exception as e: return self.json_out(500,{'error':str(e)})
        if parsed.path=='/api/taxonomy':
            try: return self.json_out(200,read_taxonomy())
            except Exception as e: return self.json_out(500,{'error':str(e)})
        if parsed.path=='/api/source-file':
            q=parse_qs(parsed.query)
            path=source_file((q.get('id') or [''])[0],(q.get('kind') or [''])[0])
            if not path: return self.json_out(404,{'error':'Archivo fuente no disponible en esta copia demo'})
            data=path.read_bytes()
            ctype=mimetypes.guess_type(path.name)[0] or 'application/octet-stream'
            self.send_response(200); self.send_header('Content-Type',ctype)
            self.send_header('Content-Disposition',f'attachment; filename="{path.name}"')
            self.send_header('Content-Length',str(len(data))); self.send_header('Cache-Control','private, no-store')
            self.end_headers(); self.wfile.write(data); return
        if parsed.path.startswith('/history') or parsed.path.startswith('/data/'):
            return self.json_out(403,{'error':'Acceso directo desactivado'})
        return super().do_GET()

    def _read_only_noop(self):
        # The UI can issue background persistence calls during bootstrap. Accept them
        # without writing anything, so the shared demo remains immutable.
        if self.path.startswith('/api/history'):
            return self.json_out(200,read_history())
        if self.path.startswith('/api/taxonomy'):
            return self.json_out(200,read_taxonomy())
        return self.json_out(403,{'error':'Demo en modo solo consulta'})

    do_POST=_read_only_noop
    do_PUT=_read_only_noop
    do_PATCH=_read_only_noop
    do_DELETE=_read_only_noop

if __name__=='__main__':
    print(f'UX Intelligence demo: http://{HOST}:{PORT}/')
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
