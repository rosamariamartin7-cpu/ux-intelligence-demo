// Document-only editing overlays. Source records and published knowledge are never
// mutated by an editor save. Publication remains a separate, explicit transaction.
let analysisEditSaving = false;
const insightEditorialFields = ['editorialTitle','editorialSynthesis','editorialNuance','uxImplication','context','limits','notDemonstrated','product','screen','component','element','device','market','segment','tags','proposedClassification'];
const insightContextFields = ['uxImplication','context','limits','notDemonstrated','product','screen','component','element','device','market','segment','tags'];
const insightDecisionFields = ['targetKind','targetId','contribution','title','synthesis','scope','confidence','question','restriction','restrictionState','source','impact','reason','support','problem','limitation','relationNature'];
const insightExtraDecisions = ['Usar como evidencia','Crear restricción','Actualizar restricción existente','Solo contexto / evidencia documental','Descartar'];
function insightDecisionOptions() { return [...new Set([...consolidationOptions,...insightExtraDecisions])]; }
function insightDecisionLabel(value) {
  return ({'Ampliar learning':'Ampliar learning existente','Contradice learning':'Marcar contradicción','Posible oportunidad':'Crear oportunidad','Posible patrón':'Proponer patrón','Mantener solo como evidencia':'Solo contexto / evidencia documental'})[value]||value;
}
function insightIsReviewed(insight) { return ['approved','reviewed','validated','published','discarded'].includes(insight.reviewStatus); }
function insightReviewLabel(insight) { return insight.decision==='Descartar'?'Descartado':insightIsReviewed(insight)?'Revisado':'Pendiente'; }
function insightContext(insight) {
  const first=insight.findings?.[0]||{},saved=insight.editorialContext||{};
  return Object.fromEntries(insightContextFields.map(key=>[key,saved[key]??insight[key]??(key==='device'?(insight.devices||[]).join(', '):key==='tags'?(insight.contextTags||[]).join(', '):first[key])??'']));
}
function insightRelatedRecords(kind) {
  const questions=[...openQuestionItems,...learnings.flatMap(learning=>(learning.open||[]).map((text,index)=>({id:`${learning.id}:question:${index}`,text})))];
  return (kind==='learning'?learnings:kind==='pattern'?patternItems:kind==='question'?questions:kind==='restriction'?evolutionState.validations:kind==='knowledge'?[...knowledgeUnits,...evidenceItems]:[])
    .map(record=>({id:record.id,title:record.title||record.text||record.name||record.id}));
}
function insightDecisionDetails(insight) {
  const saved=insight.decisionDetails||{},context=insightContext(insight);
  return {targetKind:insight.learningId?'learning':'',targetId:insight.learningId||'',contribution:insight.displaySynthesis||'',
    title:insight.displayTitle||'',synthesis:insight.displaySynthesis||'',scope:context.context||[context.product,context.screen,context.component].filter(Boolean).join(' / '),
    confidence:insight.findings?.[0]?.confidence||'Baja',question:`¿Qué necesitamos validar sobre ${(insight.displayTitle||'este insight').replace(/[.?!]+$/,'').toLocaleLowerCase('es')}?`,
    restriction:insight.displaySynthesis||'',restrictionState:'Desconocida',source:'',impact:context.uxImplication||'',reason:'',support:insight.displaySynthesis||'',problem:'',limitation:context.notDemonstrated||context.limits||'',relationNature:'Contradice',...saved};
}
function insightDecisionErrors(insight) {
  const d=insight.decision,details=insight.decisionDetails||{},errors=[];
  const requireText=(key,label)=>{if(!details[key]?.trim())errors.push(`Completa ${label}.`);};
  if(['Reforzar learning existente','Ampliar learning'].includes(d)&&!learnings.some(item=>item.id===insight.learningId))errors.push('Selecciona un learning existente.');
  if(['Usar como evidencia','Contradice learning','Actualizar restricción existente'].includes(d)){
    if(!details.targetKind||!insightRelatedRecords(details.targetKind).some(item=>item.id===details.targetId))errors.push('Selecciona el conocimiento relacionado.');
    if(d==='Actualizar restricción existente'&&details.targetKind!=='restriction')errors.push('Selecciona una restricción.');
  }
  if(['Usar como evidencia','Contradice learning','Reforzar learning existente','Ampliar learning'].includes(d))requireText('contribution','qué aporta este insight');
  if(['Crear nuevo learning','Posible oportunidad','Posible patrón','Recomendación de sistema'].includes(d)){requireText('title','el título de la propuesta');requireText('synthesis','la propuesta');}
  if(d==='Crear nuevo learning'){requireText('scope','el alcance');if(!['Alta','Media','Baja'].includes(details.confidence))errors.push('Selecciona la confianza inicial.');}
  if(d==='Crear pregunta abierta')requireText('question','la pregunta');
  if(d==='Posible patrón')requireText('support','la evidencia que respalda el patrón');
  if(['Crear restricción','Actualizar restricción existente'].includes(d)){
    requireText('restriction','la restricción');requireText('source','la fuente');requireText('impact','el impacto');
    if(!['Pendiente','Viable','Viable con restricciones','No viable actualmente','Desconocida'].includes(details.restrictionState))errors.push('Selecciona el estado de la restricción.');
  }
  return errors;
}
function insightField(name,label,value='',kind='textarea',choices=null,required=false) {
  const attributes=`name="${escapeHtml(name)}" ${required?'required':''}`;
  const input=choices?`<select ${attributes}>${choices.map(option=>{const [key,text]=Array.isArray(option)?option:[option,option];return `<option value="${escapeHtml(key)}" ${key===value?'selected':''}>${escapeHtml(text)}</option>`;}).join('')}</select>`:
    kind==='input'?`<input ${attributes} value="${escapeHtml(value)}">`:`<textarea ${attributes}>${escapeHtml(value)}</textarea>`;
  return `<label class="form-field full">${escapeHtml(label)}${input}</label>`;
}
function insightEditorFields(insight,item) {
  const context=insightContext(insight),field=(name,label,value,kind='textarea')=>insightField(name,label,value,kind);
  // Presentation only: omitted legacy fields are not submitted or migrated.
  // An older limits-only record edits that same field under the shared label.
  const boundaryKey=context.notDemonstrated||!context.limits?'notDemonstrated':'limits';
  const remainder=(value,represented)=>represented.filter(Boolean).reduce((text,copy)=>{
    text=String(text||'').trim();copy=String(copy).trim();
    if(copy.includes(text))return '';
    if(text.endsWith(copy))return text.slice(0,-copy.length).trim();
    if(text.startsWith(copy))return text.slice(copy.length).trim();
    return text;
  },value||'');
  const legacy=(text)=>text?`<p class="insight-editor-reference">${escapeHtml(text)}</p>`:'';
  const nuance=remainder(insight.nuance,[insight.displaySynthesis,context.uxImplication,context.notDemonstrated,context.limits,context.context]);
  const extraLimits=boundaryKey==='notDemonstrated'?remainder(context.limits,[context.notDemonstrated]):'';
  const scope=item.analysis?.documentEditorial?.scope;
  const excludedProduct=scope?.excluded?.some(value=>value===context.product);
  const wrongComponent=scope?.component&&context.component&&context.component!=='No especificado'&&scope.component!==context.component;
  const unknownClassification=insight.proposedClassification&&!knowledgeTypes.includes(insight.proposedClassification);
  const needsAttention=Boolean(insight.classificationConflict||insight.editorialContext?.classificationConflict||excludedProduct||wrongComponent||unknownClassification);
  const classifications=[['','Mantener clasificación original'],...knowledgeTypes];
  if(unknownClassification)classifications.push([insight.proposedClassification,`${insight.proposedClassification} (revisar)`]);
  return field('editorialTitle','Título',insight.displayTitle,'input')+
    `<div class="form-field full insight-editor-content">${field('editorialSynthesis','Qué dice el documento',insight.displaySynthesis)}${legacy(nuance)}</div>`+
    field('uxImplication','Qué significa para UX',context.uxImplication)+
    `<div class="form-field full insight-editor-content">${field(boundaryKey,'Qué no demuestra',context[boundaryKey])}${legacy(extraLimits)}</div>`+
    field('context','Contexto',context.context)+
    `<details class="form-field full insight-editor-extra"${needsAttention?' open':''}><summary>Clasificación y contexto</summary>${needsAttention?'<p class="insight-editor-attention">Revisa la clasificación: hay un valor que no coincide con el alcance del documento o con las opciones disponibles.</p>':''}<div class="form-grid">`+insightField('proposedClassification','Clasificación editorial',insight.proposedClassification,'select',classifications)+
    [['product','Producto'],['screen','Pantalla'],['component','Componente'],['element','Elemento'],['device','Dispositivo'],['market','Mercado'],['segment','Segmento'],['tags','Tags / dimensiones']].map(([key,label])=>field(key,label,context[key],'input')).join('')+
    '</div></details>'+
    (isDocumentPublished(item)?`<label class="form-field full"><span><input type="checkbox" name="publishEditorialChanges" ${item.analysis.clusterReview?.[insight.id]?.publishEditorialChanges?'checked':''}> Proponer también esta redacción para el conocimiento publicado</span><span>Solo se aplicará tras revisar el impacto y publicar explícitamente.</span></label>`:'');
}
function fitInsightEditor(form) {
  if(!form)return;
  const fit=textarea=>{
    if(!textarea.getClientRects().length)return;
    textarea.style.height='auto';
    textarea.style.height=`${Math.min(240,Math.max(72,textarea.scrollHeight+2))}px`;
  };
  const fitAll=()=>form.querySelectorAll('textarea').forEach(fit);
  requestAnimationFrame(fitAll);
  form.addEventListener('input',event=>{if(event.target.matches('textarea'))fit(event.target);});
  form.querySelectorAll('details').forEach(details=>details.addEventListener('toggle',fitAll));
}
function insightDecisionFieldsMarkup(insight,item,decision,values=insightDecisionDetails(insight)) {
  const field=(name,label,required=true,kind='textarea',options=null)=>insightField('detail.'+name,label,values[name]||'',kind,options,required);
  const target=(kind=null,required=true)=>{
    const selected=kind||values.targetKind||'learning';values={...values,targetKind:selected};
    return (kind?`<input type="hidden" name="detail.targetKind" value="${kind}">`:field('targetKind','Tipo de conocimiento',true,'select',[['learning','Learning'],['pattern','Patrón'],['question','Pregunta abierta'],['restriction','Restricción'],['knowledge','Otro conocimiento']]))+
      insightField('detail.targetId',kind==='learning'?'Learning relacionado':kind==='restriction'?'Restricción relacionada':'Conocimiento relacionado',values.targetId||'', 'select',[['',required?'Seleccionar':'Sin relación seleccionada'],...insightRelatedRecords(selected).map(record=>[record.id,`${record.id} · ${record.title}`])],required);
  };
  if(['Reforzar learning existente','Ampliar learning'].includes(decision))return target('learning')+field('contribution',decision==='Ampliar learning'?'Propuesta de ampliación':'Qué parte del insight lo refuerza');
  if(['Usar como evidencia','Contradice learning'].includes(decision))return target()+(decision==='Contradice learning'?field('relationNature','Cómo se relaciona',true,'select',['Contradice','Limita','Matiza']):'')+field('contribution',decision==='Contradice learning'?'Por qué contradice, limita o matiza':'Qué aporta la evidencia');
  if(decision==='Crear nuevo learning')return field('title','Título del learning',true,'input')+field('synthesis','Qué sabemos')+field('scope','Alcance')+field('confidence','Confianza inicial',true,'select',['Baja','Media','Alta'])+field('limitation','Qué no demuestra',false);
  if(decision==='Crear pregunta abierta')return field('question','Pregunta propuesta')+field('scope','Contexto de la pregunta',false)+target(null,false);
  if(['Posible oportunidad','Recomendación de sistema','Posible patrón'].includes(decision))return field('title','Título de la propuesta',true,'input')+field('synthesis',decision==='Posible oportunidad'?'Oportunidad propuesta':decision==='Posible patrón'?'Patrón propuesto':'Recomendación propuesta')+field('scope',decision==='Posible patrón'?'Ámbito':'Contexto',false)+(decision==='Posible patrón'?field('support','Evidencia que lo respalda'):decision==='Posible oportunidad'?field('problem','A qué problema responde',false):'');
  if(['Crear restricción','Actualizar restricción existente'].includes(decision)){
    if(!values.source)values={...values,source:`${item.name} · páginas ${formatPageRanges(insight.pages)}`};
    return (decision==='Actualizar restricción existente'?target('restriction'):'')+field('restriction','Restricción')+field('restrictionState','Estado técnico',true,'select',['Pendiente','Viable','Viable con restricciones','No viable actualmente','Desconocida'])+field('source','Fuente')+field('scope','Contexto',false)+field('impact','Impacto sobre la solución o el contexto');
  }
  return decision==='Descartar'?field('reason','Motivo del descarte (opcional)',false):'<p class="form-field full">Se conservará el insight con su trazabilidad, sin crear conocimiento nuevo.</p>';
}
function openInsightDecision(id) {
  const item=activeReviewDocument();if(!reviewCanEdit(item))return;
  const insight=reviewInsightsForDocument(item).find(record=>record.id===id);if(!insight)return;
  // Existing decisions keep their stored values; equivalent names are display labels only.
  const decisions=insightDecisionOptions(),labels=[...new Set(decisions.map(insightDecisionLabel))];
  const choices=labels.map(label=>[insightDecisionLabel(insight.decision)===label?insight.decision:decisions.find(value=>insightDecisionLabel(value)===label),label]);
  openDrawer(`<div class="drawer-kicker">Decisión del insight</div><h2>Gestionar decisión</h2><p class="drawer-lead">${escapeHtml(insight.displayTitle)}</p>`,
    `<form id="insight-decision-form" data-insight-id="${escapeHtml(id)}"><div class="form-grid">${insightField('decision','Decisión',insight.decision,'select',choices,true)}<div class="form-field full" id="insight-decision-fields">${insightDecisionFieldsMarkup(insight,item,insight.decision)}</div>${insightField('status','Estado de revisión',insightIsReviewed(insight)?'approved':'pending','select',[['pending','Pendiente'],['approved','Revisado']])}<p class="form-field full">Guardar no publica conocimiento. Si cambia una decisión revisada, quedará pendiente de confirmar.</p></div><div class="form-actions"><button class="secondary-button" type="button" data-close-editor>Cancelar</button><button class="action-button" type="submit">Guardar</button></div></form>`);
}
function insightDecisionHistoryMarkup(insight) {
  if(!insight.decisionHistory?.length)return '';
  const labels={targetId:'Relación',contribution:'Aportación',title:'Título',synthesis:'Propuesta',scope:'Alcance',confidence:'Confianza',question:'Pregunta',restriction:'Restricción',restrictionState:'Estado',source:'Fuente',impact:'Impacto',reason:'Motivo',support:'Evidencia de apoyo'};
  const details=value=>Object.entries(labels).filter(([key])=>value?.[key]).map(([key,label])=>`<p><strong>${label}:</strong> ${escapeHtml(value[key])}</p>`).join('')||'<p>Sin detalles adicionales.</p>';
  return `<details><summary>Histórico de decisiones (${insight.decisionHistory.length})</summary>${insight.decisionHistory.map(event=>`<section class="drawer-section"><p><strong>${escapeHtml(new Date(event.at).toLocaleString('es-ES'))}</strong><br>${escapeHtml(insightDecisionLabel(event.before.decision))} ${escapeHtml(event.before.learningId||event.before.details?.targetId||'')} → ${escapeHtml(insightDecisionLabel(event.after.decision))} ${escapeHtml(event.after.learningId||event.after.details?.targetId||'')}<br>Fuente: ${escapeHtml(event.source.documentId)} · ${escapeHtml(event.source.file)} · páginas ${formatPageRanges(event.source.pages)}${event.publication?`<br>Publicación asociada: ${escapeHtml(event.publication)}`:''}</p><details><summary>Ver detalle del cambio</summary><h4>Anterior</h4>${details(event.before.details)}<h4>Nueva</h4>${details(event.after.details)}</details></section>`).join('')}</details>`;
}
function insightReadCopy(value) { return escapeHtml(String(value??'').replace(/;\s*(\p{L})?/gu,(_,letter)=>'. '+(letter?letter.toLocaleUpperCase('es'):''))); }
function insightManagementMarkup(insight,item,findingsList) {
  const ctx=insightContext(insight),details=insight.decisionDetails||{},relation=details.targetId||insight.learningId||'';
  const part=(label,value)=>value?`<p><strong>${escapeHtml(label)}:</strong> ${insightReadCopy(value)}</p>`:'';
  const fact=(label,value)=>`<div${!value||value==='No especificado'?' class="insight-fact-unspecified"':''}><dt>${label}</dt><dd>${insightReadCopy(value||'No especificado')}</dd></div>`;
  const chips=[...new Set(insight.types||[])].slice(0,3);
  // Read-only presentation: exact repeated passages are shown once; stored fields stay intact.
  const remaining=(value,shown)=>shown.filter(Boolean).reduce((text,copy)=>{
    text=String(text||'').trim();copy=String(copy).trim();
    if(copy.includes(text))return '';
    if(text.startsWith(copy))return text.slice(copy.length).trim();
    if(text.endsWith(copy))return text.slice(0,-copy.length).trim();
    return text;
  },value||'');
  const paragraphs=values=>values.filter(Boolean).map(value=>`<p>${escapeHtml(value)}</p>`).join('');
  const notDemonstrated=ctx.notDemonstrated||insight.notDemonstrated;
  const limits=remaining(ctx.limits||insight.limits,[notDemonstrated]);
  const nuance=remaining(insight.nuance,[insight.displaySynthesis,ctx.uxImplication,notDemonstrated,ctx.limits||insight.limits,ctx.context]);
  const ux=paragraphs([ctx.uxImplication]),boundaries=paragraphs([notDemonstrated,limits]);
  const proposal=['contribution','title','synthesis','question','restriction','restrictionState','source','impact','scope','confidence','support','reason','problem','limitation','relationNature'].map(key=>part(({contribution:'Aportación',title:'Título propuesto',synthesis:'Propuesta',question:'Pregunta',restriction:'Restricción',restrictionState:'Estado técnico',source:'Fuente',impact:'Impacto',scope:'Alcance',confidence:'Confianza',support:'Evidencia de apoyo',reason:'Motivo',problem:'Problema al que responde',limitation:'Qué no demuestra',relationNature:'Relación'})[key],details[key])).join('');
  const reviewed=insightIsReviewed(insight),pending=pendingAnalysisChanges(item).includes(insight.id);
  return `<div class="insight-layout"><div class="insight-main"><section class="insight-section"><div class="insight-copy-head"><h3>Qué dice el documento</h3><button class="text-button insight-edit" type="button" data-insight-edit="${insight.id}">Editar insight</button></div>${paragraphs([insight.displaySynthesis])}${chips.length?`<div class="insight-tags">${chips.map(type=>`<span class="status-badge neutral">${escapeHtml(humanKnowledgeLabel(type))}</span>`).join('')}</div>`:''}</section>${ux?`<section class="insight-section"><h3>Qué significa para UX</h3>${ux}</section>`:''}${boundaries?`<section class="insight-section"><h3>Qué no demuestra</h3>${boundaries}</section>`:''}</div><aside class="insight-aside"><section class="insight-operation"><h3>Qué hacemos con este insight</h3><dl class="insight-facts">${fact('Decisión actual',insightDecisionLabel(insight.decision))}${relation?fact('Relación actual',relation):''}${fact('Estado',insightReviewLabel(insight))}</dl>${proposal?`<details class="insight-secondary"><summary>Propuesta guardada</summary>${proposal}</details>`:''}<div class="form-actions"><button class="secondary-button" type="button" data-insight-decision="${insight.id}">${reviewed?'Cambiar decisión':'Gestionar decisión'}</button>${!reviewed?`<button class="action-button" type="button" data-cluster-approve="${insight.id}">Confirmar decisión</button>`:''}</div>${pending?'<p class="insight-pending">Cambios pendientes de publicar</p>':''}</section><section class="insight-context"><h3>Contexto</h3><dl class="insight-facts">${[['product','Producto'],['screen','Pantalla'],['component','Componente'],['element','Elemento'],['device','Dispositivo'],['market','Mercado'],['segment','Segmento']].filter(([key])=>!['element','segment'].includes(key)||ctx[key]).map(([key,label])=>fact(label,ctx[key])).join('')}</dl>${ctx.context?part('Contexto adicional',ctx.context):''}${paragraphs([nuance])}</section></aside></div><details class="insight-secondary"><summary>Hallazgos relacionados · ${insight.findings.length}</summary><div class="cluster-findings">${findingsList}</div></details><footer class="insight-trace"><div><strong>${escapeHtml(item.name)}</strong><span>${escapeHtml(item.originalName||item.fileMeta?.name||'')} · ${escapeHtml(documentDate(item))}</span></div><div>${insight.findings.length} unidades válidas · págs. ${formatPageRanges(insight.pages)}<span>Registros originales protegidos</span></div></footer><div class="insight-history">${insightDecisionHistoryMarkup(insight)}</div>`;
}
function insightPublicationCopy(operation) {
  const details=operation.decisionDetails||{},editorial=operation.editorialContext||{};
  const specificNoProof=[details.noProof,details.limitation,editorial.notDemonstrated,editorial.limits].find(value=>Array.isArray(value)?value.some(text=>typeof text==='string'&&text.trim()):typeof value==='string'&&value.trim());
  return {title:details.title||operation.name,synthesis:details.contribution||details.synthesis||operation.synthesis,
    question:details.question||`¿Qué necesitamos validar sobre ${operation.name.toLocaleLowerCase('es')} antes de convertirlo en una decisión de diseño?`,
    scope:details.scope||(operation.decision==='Crear nuevo learning'?editorial.context:'')||'',
    noProof:specificNoProof?(Array.isArray(specificNoProof)?[...specificNoProof]:[specificNoProof]):[],
    confidence:details.confidence||operation.findings?.[0]?.confidence||'Baja'};
}
function insightPublicationContext(operation) {
  const first=operation.findings[0]||{},context=operation.editorialContext||{};
  return {...first,...Object.fromEntries(['product','screen','component','element','device','market','segment'].filter(key=>Object.hasOwn(context,key)).map(key=>[key,context[key]]))};
}
function insightProposalPreview(operation) {
  const details=operation.decisionDetails||{};
  const labels={targetId:'Conocimiento relacionado',contribution:'Aportación',title:'Título propuesto',synthesis:'Propuesta',scope:'Alcance',confidence:'Confianza inicial',question:'Pregunta',restriction:'Restricción',restrictionState:'Estado',source:'Fuente',impact:'Impacto',reason:'Motivo',support:'Evidencia que lo respalda',problem:'Problema al que responde',limitation:'Qué no demuestra',relationNature:'Tipo de relación'};
  return Object.entries(labels).filter(([key])=>details[key]).map(([key,label])=>`<p><strong>${label}:</strong> ${escapeHtml(details[key])}</p>`).join('');
}
// These functions are called only inside the existing explicit publication transaction.
function publishInsightDecisionDetails(item,operation,publishedAt) {
  const details=operation.decisionDetails||{},key=`PUB-${item.id}-${operation.id}`,first=insightPublicationContext(operation);
  if(['Usar como evidencia','Contradice learning'].includes(operation.decision)&&details.targetKind&&details.targetKind!=='learning'){
    const collection=details.targetKind==='pattern'?patternItems:details.targetKind==='question'?openQuestionItems:details.targetKind==='restriction'?evolutionState.validations:[...knowledgeUnits,...evidenceItems];
    const target=collection.find(record=>record.id===details.targetId)||(details.targetKind==='question'?learnings.find(learning=>(learning.open||[]).some((text,index)=>`${learning.id}:question:${index}`===details.targetId)):null);
    if(!target)throw Error('El conocimiento relacionado ya no está disponible.');
    target.insightContributions=[...(target.insightContributions||[]).filter(entry=>entry.id!==key),{id:key,documentId:item.id,clusterId:operation.id,decision:operation.decision,targetKind:details.targetKind,targetId:details.targetId,text:details.contribution,unitIds:operation.findings.map(unit=>unit.id),publishedAt}];
  }
  if(['Crear restricción','Actualizar restricción existente'].includes(operation.decision)){
    let target=operation.decision==='Actualizar restricción existente'?evolutionState.validations.find(record=>record.id===details.targetId):evolutionState.validations.find(record=>record.publicationOperationId===key);
    if(!target){if(operation.decision==='Actualizar restricción existente')throw Error('La restricción relacionada ya no está disponible.');target={id:`V-${item.id}-${operation.id}`,publicationOperationId:key,documentId:item.id,solutionStatus:'No definida',history:[],relationIds:[],variants:[]};evolutionState.validations.push(target);}
    const before={text:target.text||'',technicalStatus:target.technicalStatus||'Desconocida',source:target.source||'',impact:target.impact||''};
    Object.assign(target,{text:details.restriction,technicalStatus:details.restrictionState,source:details.source,impact:details.impact,product:first.product,screen:first.screen,component:first.component,element:first.element,device:first.device,market:first.market});
    target.history=[...(target.history||[]),{at:publishedAt,before:before.technicalStatus,after:details.restrictionState,previous:before,documentId:item.id,clusterId:operation.id,publicationOperationId:key,source:details.source}];
  }
}
function cloneAnalysisValue(value) { return JSON.parse(JSON.stringify(value)); }
function publishedAnalysisInsights(item, interpretation=documentInterpretation(item)) {
  if(item.archivedReview?.insights?.length&&item.archivedReview.publicationStamp===item.analysis.publication?.publishedAt)return item.archivedReview.insights;
  return (item.analysis.publication?.operations||[]).map(operation=>{
    const findings=interpretation.units.filter(unit=>(operation.unitIds||[]).includes(unit.id));
    return {id:operation.id,name:operation.name,displayTitle:operation.name,displaySynthesis:operation.synthesis||'',nuance:operation.nuance||'',
      decision:operation.decision,learningId:operation.learningId||'',learning:learnings.find(item=>item.id===operation.learningId)||null,
      findings,pages:findings.map(item=>Number(item.source?.page)),devices:[...new Set(findings.map(item=>item.device).filter(Boolean))],
      types:operation.types||[...new Set(findings.map(item=>item.type).filter(Boolean))],proposedClassification:operation.proposedClassification||'',decisionDetails:operation.decisionDetails||{},editorialContext:operation.editorialContext||{},
      contextTags:[...new Set(findings.flatMap(item=>item.contextTags||[]))],hasLowConfidence:false,
      hasContradiction:operation.decision==='Contradice learning',needsDecision:false,reviewStatus:operation.decision==='Descartar'?'discarded':'approved'};
  });
}
function applyAnalysisEditorial(item, insights) {
  return insights.map(insight=>{
    const saved=item.analysis?.clusterReview?.[insight.id]||{};
    const learningId=Object.hasOwn(saved,'learningId')?saved.learningId:insight.learningId||insight.learning?.id||'';
    const decision=saved.decision||insight.decision;
    const proposedClassification=saved.proposedClassification??insight.proposedClassification??'';
    return {...insight,displayTitle:saved.editorialTitle??insight.displayTitle,displaySynthesis:saved.editorialSynthesis??insight.displaySynthesis,
      nuance:saved.editorialNuance??insight.nuance,decision,learningId,learning:learnings.find(learning=>learning.id===learningId)||null,
      proposedClassification,types:proposedClassification?[proposedClassification]:insight.types,
      editorialContext:{...(insight.editorialContext||{}),...Object.fromEntries(insightContextFields.filter(key=>Object.hasOwn(saved,key)).map(key=>[key,saved[key]]))},
      devices:Object.hasOwn(saved,'device')?saved.device.split(',').map(value=>value.trim()).filter(Boolean):insight.devices,
      decisionDetails:cloneAnalysisValue(saved.decisionDetails??insight.decisionDetails??{}),decisionHistory:saved.decisionHistory||[],
      reviewStatus:saved.status||insight.reviewStatus,
      needsDecision:decision!=='Descartar'&&(insight.hasLowConfidence||decision==='Contradice learning'||['Crear nuevo learning','Ampliar learning','Crear pregunta abierta','Posible patrón','Posible oportunidad','Recomendación de sistema','Crear restricción','Actualizar restricción existente','Usar como evidencia'].includes(decision))};
  });
}
function analysisDecisionKey(insight) {
  return JSON.stringify([insight.decision,Object.hasOwn(insight,'learningId')?insight.learningId:insight.learning?.id||'',insight.proposedClassification||'',
    insightDecisionFields.map(key=>insight.decisionDetails?.[key]||''),insightContextFields.map(key=>insightContext(insight)[key]||'')]);
}
function pendingAnalysisChanges(item) {
  if(!isDocumentPublished(item))return [];
  const baseline=publishedAnalysisInsights(item),current=applyAnalysisEditorial(item,baseline);
  return current.filter(insight=>{
    const before=baseline.find(record=>record.id===insight.id),saved=item.analysis.clusterReview?.[insight.id]||{};
    return analysisDecisionKey(insight)!==analysisDecisionKey(before)||Boolean(saved.publishEditorialChanges&&[
      [insight.displayTitle,before.displayTitle],[insight.displaySynthesis,before.displaySynthesis],[insight.nuance,before.nuance]
    ].some(([a,b])=>(a||'')!==(b||'')));
  }).map(insight=>insight.id);
}
function applyAnalysisEdit(item,id,patch) {
  if(!hasDocumentAnalysis(item))throw Error('No hay un análisis disponible.');
  const insight=reviewInsightsForDocument(item).find(insight=>insight.id===id);if(!insight)throw Error('No se encuentra el insight.');
  const allowed=[...insightEditorialFields,'decision','learningId','status','publishEditorialChanges','decisionDetails'];
  const safe=Object.fromEntries(Object.entries(patch).filter(([key])=>allowed.includes(key)));
  for(const [key,value] of Object.entries(safe))if(key!=='decisionDetails'&&key!=='publishEditorialChanges'&&typeof value!=='string')throw Error('El análisis solo admite campos de texto.');
  if(safe.decisionDetails){
    safe.decisionDetails=Object.fromEntries(insightDecisionFields.filter(key=>Object.hasOwn(safe.decisionDetails,key)).map(key=>{
      if(typeof safe.decisionDetails[key]!=='string')throw Error('Los detalles de la decisión deben ser texto.');
      return [key,safe.decisionDetails[key]];
    }));
  }
  if(safe.decision&&!insightDecisionOptions().includes(safe.decision))throw Error('Decisión no válida.');
  if(safe.learningId&&!learnings.some(learning=>learning.id===safe.learningId))throw Error('El learning seleccionado no existe.');
  if(safe.proposedClassification&&!knowledgeTypes.includes(safe.proposedClassification))throw Error('Clasificación no válida.');
  if(safe.status&&!['pending','approved','reviewed','validated','published','discarded'].includes(safe.status))throw Error('Estado de revisión no válido.');
  const effective={...insight,...safe,editorialContext:{...(insight.editorialContext||{}),...Object.fromEntries(insightContextFields.filter(key=>Object.hasOwn(safe,key)).map(key=>[key,safe[key]]))}};
  if(safe.decisionDetails){const errors=insightDecisionErrors(effective);if(errors.length)throw Error(errors.join(' '));}
  if(safe.proposedClassification!==undefined)effective.proposedClassification=safe.proposedClassification;
  const impact=analysisDecisionKey(effective)!==analysisDecisionKey(insight)||Boolean(safe.publishEditorialChanges&&[
    ['editorialTitle','displayTitle'],['editorialSynthesis','displaySynthesis'],['editorialNuance','nuance']
  ].some(([field,original])=>safe[field]!==undefined&&safe[field]!==insight[original]));
  const current=item.analysis.clusterReview?.[id]||{},now=new Date().toISOString();
  // Only the review overlay changes. Never assign into findings, source or pages.
  const decisionChanged=JSON.stringify([insight.decision,insight.learningId,insight.decisionDetails])!==JSON.stringify([effective.decision,effective.learningId,effective.decisionDetails]);
  const history=[...(current.decisionHistory||[])];
  const nextStatus=effective.decision==='Descartar'?'discarded':impact?'pending':safe.status||current.status||insight.reviewStatus||'pending';
  if(decisionChanged)history.push({at:now,documentId:item.id,insightId:id,reviewStatus:nextStatus,previousReviewStatus:insight.reviewStatus||'pending',before:{decision:insight.decision,learningId:insight.learningId||'',details:cloneAnalysisValue(insight.decisionDetails||{})},
    after:{decision:effective.decision,learningId:effective.learningId||'',details:cloneAnalysisValue(effective.decisionDetails||{})},
    source:{documentId:item.id,file:item.originalName||item.fileMeta?.name||'',pages:[...new Set(insight.pages||[])],unitIds:insight.findings.map(unit=>unit.id)},publication:item.analysis.publication?.publishedAt||null});
  item.analysis.clusterReview={...(item.analysis.clusterReview||{}),[id]:{...current,...safe,decisionHistory:history,
    status:nextStatus,editorialUpdatedAt:now}};
  const pending=pendingAnalysisChanges(item);
  if(pending.length)item.analysis.pendingPublication={status:'Cambios pendientes de publicar',insightIds:pending,basePublishedAt:item.analysis.publication.publishedAt,updatedAt:now};
  else delete item.analysis.pendingPublication;
  touchReview(item);
}
async function saveAnalysisEdit(item,id,patch) {
  if(!reviewCanEdit(item)||analysisEditSaving)return false;
  analysisEditSaving=true;
  const before=cloneAnalysisValue(item.analysis);
  try{
    applyAnalysisEdit(item,id,patch);
    await persistDocumentAnalysis(item,before);
    try{await saveDocumentAnalysis(item.id,item.analysis);safeStorageWrite({project:false});}
    catch(error){console.error('Edición guardada en el proyecto; no se pudo actualizar la copia del navegador',error);}
    return true;
  }catch(error){
    item.analysis=before;
    try{await saveDocumentAnalysis(item.id,before);}catch(rollbackError){console.error('No se pudo recuperar la copia local del análisis',rollbackError);}
    console.error('[UX Intel edición]',{documentId:item.id,insightId:id,message:error.message,phase:error.phase,stack:error.stack,error});
    renderReview();showToast('No se ha guardado la edición',error.message);return false;
  }finally{analysisEditSaving=false;}
}
function analysisEditStatusMarkup(item,plan) {
  if(!isDocumentPublished(item)||!pendingAnalysisChanges(item).length)return '';
  return `<section class="publish-ready"><div class="publish-ready-copy"><span class="publish-ready-label">Cambios pendientes de publicar</span><p>La versión publicada sigue intacta. Revisa los cambios antes de incorporarlos a UX Intel.</p></div>${reviewCanEdit(item)&&plan.ready?'<button class="action-button" type="button" data-open-publish-preview>Ver impacto y publicar</button>':''}</section>`;
}
function analysisRevisionNotes(item,operation) {
  if(!isDocumentPublished(item))return '';
  const before=publishedAnalysisInsights(item).find(insight=>insight.id===operation.id);
  return `<p><strong>Publicado:</strong> ${escapeHtml(before?.decision||'Sin decisión')} ${escapeHtml(before?.learningId||'')}</p><p><strong>Propuesto:</strong> ${escapeHtml(operation.decision)} ${escapeHtml(operation.learningId||'')}</p><p>Se sustituirá únicamente la aportación de este insight. La versión anterior se conserva en el histórico.</p>`;
}
// Fail closed when an old generated record is now shared with another source.
// No edit can silently remove another document's contribution during republication.
function analysisRevisionConflicts(item,plan) {
  if(!isDocumentPublished(item))return [];
  const errors=[];
  for(const operation of plan.operations){
    const before=item.analysis.publication.operations.find(previous=>previous.id===operation.id);
    if(!before)continue;
    const operationId=`PUB-${item.id}-${operation.id}`;
    if(['Crear restricción','Actualizar restricción existente'].includes(before.decision)){
      const restriction=evolutionState.validations.find(record=>record.publicationOperationId===operationId||record.id===before.decisionDetails?.targetId);
      if(restriction?.history?.length&&restriction.history.at(-1).publicationOperationId!==operationId)errors.push('La restricción tiene cambios posteriores de otra fuente. Revisa su histórico antes de sustituir esta aportación.');
      if(restriction?.insightContributions?.some(entry=>entry.documentId!==item.id))errors.push('La restricción tiene otras aportaciones. Revisa su consolidación antes de sustituirla.');
    }
    const generated=learnings.find(learning=>learning.publicationOperationId===operationId);
    if(generated){
      const otherSources=(generated.sourceNames||[]).filter(name=>name!==item.name);
      const otherHistory=(generated.publicationHistory||[]).filter(entry=>entry.documentId!==item.id);
      const references=[...patternItems,...knowledgeUnits,...evidenceItems,...openQuestionItems].some(record=>record.documentId!==item.id&&(record.proof?.includes(generated.id)||record.learningId===generated.id||record.learningIds?.includes(generated.id))) ||
        (typeof evolutionState!=='undefined'&&(evolutionState.validations||[]).some(validation=>validation.relationIds?.includes(generated.id)));
      if(otherSources.length||otherHistory.length||references)errors.push(`${generated.id} ya tiene otras aportaciones o referencias. Es necesario revisar su consolidación antes de sustituir esta decisión.`);
    }
    const question=openQuestionItems.find(record=>record.publicationOperationId===operationId);
    if(question&&typeof evolutionState!=='undefined'&&(evolutionState.questionUpdates||[]).some(update=>update.id===question.id))errors.push('Esta pregunta ya tiene una resolución relacionada. Revisa esa relación antes de sustituir su aportación.');
    // A matching title alone never grants ownership of a published contribution.
    if(['Reforzar learning','Reforzar learning existente','Ampliar learning','Contradice learning','Usar como evidencia'].includes(before.decision)&&before.learningId){
      const target=learnings.find(learning=>learning.id===before.learningId);
      if(target&&!target.publicationHistory?.some(entry=>entry.id===operationId))errors.push(`No se puede identificar con seguridad la aportación anterior de ${operation.name}. No se modificará el learning publicado.`);
      if(target?.publicationHistory?.some(entry=>entry.documentId!==item.id))errors.push(`${target.id} contiene aportaciones de otras fuentes. Hay que confirmar qué texto pertenece a esta revisión antes de sustituirlo.`);
    }
  }
  return errors;
}
function withdrawPreviousAnalysisContributions(item,plan) {
  const changed=new Set(plan.operations.map(operation=>operation.id));
  const remove=(collection,predicate)=>{for(let i=collection.length-1;i>=0;i--)if(predicate(collection[i]))collection.splice(i,1);};
  const beforeOperations=item.analysis.publication.operations.filter(operation=>changed.has(operation.id));
  for(const before of beforeOperations){
    const key=`PUB-${item.id}-${before.id}`,next=plan.operations.find(operation=>operation.id===before.id);
    const previousCopy=insightPublicationCopy(before),nextCopy=insightPublicationCopy(next);
    for(const collection of [learnings,patternItems,openQuestionItems,knowledgeUnits,evidenceItems,evolutionState.validations])for(const record of collection){
      if(record.insightContributions)record.insightContributions=record.insightContributions.filter(entry=>entry.id!==key);
    }
    if(['Crear restricción','Actualizar restricción existente'].includes(before.decision)){
      const restriction=evolutionState.validations.find(record=>record.publicationOperationId===key||record.id===before.decisionDetails?.targetId);
      const event=restriction?.history?.find(entry=>entry.publicationOperationId===key&&entry.previous);
      const continues=restriction&&(next.decision==='Crear restricción'||next.decision==='Actualizar restricción existente'&&next.decisionDetails?.targetId===restriction.id);
      if(restriction&&restriction.publicationOperationId===key&&!continues)remove(evolutionState.validations,record=>record===restriction);
      else if(restriction&&!continues&&event?.publicationOperationId===key&&event.previous){
        Object.assign(restriction,event.previous);
        restriction.history.push({at:plan.revisionAt,before:event.after,after:event.previous.technicalStatus,documentId:item.id,publicationOperationId:key,reason:'Sustitución explícita de la decisión anterior'});
      }
    }
    const target=learnings.find(learning=>learning.id===before.learningId);
    if(target&&target.publicationHistory?.some(entry=>entry.id===key)){
      target.publicationHistory=target.publicationHistory.filter(entry=>entry.id!==key);
      const field=before.decision==='Contradice learning'?'contrary':'forEvidence';
      const shared=(item.analysis.publication.operations||[]).some(other=>other.id!==before.id&&other.learningId===before.learningId&&insightPublicationCopy(other).synthesis===previousCopy.synthesis);
      if(!shared)target[field]=(target[field]||[]).filter(text=>text!==previousCopy.synthesis);
      if(!target.publicationHistory.some(entry=>entry.documentId===item.id)&&target.documentId!==item.id)target.sourceNames=(target.sourceNames||[]).filter(name=>name!==item.name);
    }
    const generated=learnings.find(learning=>learning.publicationOperationId===key);
    if(generated&&next.decision==='Crear nuevo learning'){
      Object.assign(generated,{title:nextCopy.title,text:nextCopy.synthesis,know:nextCopy.synthesis,forEvidence:[nextCopy.synthesis],noProof:nextCopy.noProof.length?nextCopy.noProof:['Este learning se ha consolidado desde una única fuente y debe aplicarse dentro de su contexto.'],applications:[nextCopy.scope||pathOf(insightPublicationContext(next))],confidence:nextCopy.confidence,tags:next.types,updatedAt:plan.revisionAt});
    }else if(generated)remove(learnings,learning=>learning===generated);
    const pattern=patternItems.find(record=>record.publicationOperationId===key);
    if(pattern&&next.decision==='Posible patrón')Object.assign(pattern,{title:nextCopy.title,description:nextCopy.synthesis,support:next.decisionDetails?.support||nextCopy.synthesis});
    else if(pattern)remove(patternItems,record=>record===pattern);
    const question=openQuestionItems.find(record=>record.publicationOperationId===key);
    if(question&&next.decision==='Crear pregunta abierta')Object.assign(question,{text:nextCopy.question,evidence:nextCopy.synthesis});
    else if(question)remove(openQuestionItems,record=>record===question);
    remove(knowledgeUnits,record=>record.id===key);
    if(next.decision==='Descartar'){
      const ids=new Set(before.unitIds||[]);
      remove(knowledgeUnits,record=>record.documentId===item.id&&ids.has(record.id));
      remove(evidenceItems,record=>record.documentId===item.id&&ids.has(record.unitId));
    }
    // Published raw evidence retains its original identity and literal content.
    [...knowledgeUnits,...evidenceItems].filter(record=>record.documentId===item.id&&record.clusterId===before.id).forEach(record=>{
      record.publicationCategory=next.decision;record.proposedClassification=next.proposedClassification||'';
    });
  }
}
function preservePreviousAnalysisPublication(item) {
  const analysis=item.analysis;
  analysis.publicationHistory=[...(analysis.publicationHistory||[]),{publication:cloneAnalysisValue(analysis.publication),insights:cloneAnalysisValue(publishedAnalysisInsights(item))}];
}
document.addEventListener('click',event=>{
  const decision=event.target.closest('[data-insight-decision]');
  if(decision){event.preventDefault();openInsightDecision(decision.dataset.insightDecision);}
  if(event.target.closest('[data-edit-analysis]')){
    if(!canEditDocumentReview(activeReviewDocument()))return;
    analysisMode='review';renderReview();
  }
  if(event.target.closest('[data-finish-analysis-edit]')){analysisMode='view';renderReview();}
});
document.addEventListener('change',event=>{
  const form=event.target.closest('#insight-decision-form');if(!form||!['decision','detail.targetKind'].includes(event.target.name))return;
  const item=activeReviewDocument(),insight=reviewInsightsForDocument(item).find(record=>record.id===form.dataset.insightId);if(!insight)return;
  const data=new FormData(form),decision=String(data.get('decision'));
  const values=event.target.name==='decision'?insightDecisionDetails({...insight,learningId:'',decisionDetails:{}}):{...insightDecisionDetails(insight),...Object.fromEntries(insightDecisionFields.filter(key=>data.has('detail.'+key)).map(key=>[key,String(data.get('detail.'+key))])),targetId:''};
  form.querySelector('#insight-decision-fields').innerHTML=insightDecisionFieldsMarkup(insight,item,decision,values);
});
document.addEventListener('submit',event=>{
  const form=event.target;if(form.id!=='insight-decision-form')return;event.preventDefault();
  const item=activeReviewDocument();if(!reviewCanEdit(item))return;
  const data=new FormData(form),details=Object.fromEntries(insightDecisionFields.filter(key=>data.has('detail.'+key)).map(key=>[key,String(data.get('detail.'+key)||'').trim()]));
  const patch={decision:String(data.get('decision')),decisionDetails:details,learningId:details.targetKind==='learning'?details.targetId||'':'',status:String(data.get('status')||'pending')};
  saveAnalysisEdit(item,form.dataset.insightId,patch).then(saved=>{if(!saved)return;closeDrawer();renderReview();showToast('Decisión guardada',pendingAnalysisChanges(item).length?'Cambios pendientes de publicar. La versión publicada no ha cambiado.':'El cambio se ha guardado en el análisis. No se ha publicado nada.');});
});
