// Empty active base. Reviewed Insight Registers are imported manually.
// The previous generated base is preserved in archive/content-before-excel-reset-2026-09-18.
var UXSimpleKnowledgeData = {
  version: 'simple-kb-1',
  schema: [
    'product','funnel','minifunnel','screen','component','element','recordType','insight','origin','evidence',
    'channelEnvironment','market','userState','platformSystem','uxImplication','result','implementation','confidence',
    'experimentPotential','source','observations'
  ],
  documents: [],
  records: []
};
