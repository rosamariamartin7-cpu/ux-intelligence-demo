// Read-only views for the document analysis module. Filters and pagination are
// transient UI state; no analysis, classification or persisted record is edited.
const auditPageSize = 10;
let documentAuditView = null;
let documentRecordQuery = {documentId:null,search:'',page:'',type:'',related:'',screen:'',component:'',chunk:1};
function auditText(value) { return String(value??''); }
function auditNormalize(value) { return auditText(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase('es'); }
function auditPresent(value) { return value!=null&&auditText(value).trim()!==''; }
function auditUnique(values) { return [...new Set(values.filter(auditPresent).map(auditText))]; }
function auditOriginalIds(unit) { return auditUnique([unit.id,...(unit.originalFindingIds||[]),...(unit.source?.originalFindingIds||[])]); }
function buildDocumentAuditView(item,interpretation,clusters) {
  const byOriginal=new Map();
  for(const cluster of clusters)for(const unit of cluster.findings||[])for(const id of auditOriginalIds(unit)){
    if(!byOriginal.has(id))byOriginal.set(id,new Map());
    byOriginal.get(id).set(cluster.id,cluster);
  }
  const records=(interpretation.originalRecords||[]).map((record,index)=>{
    const original=record.originalFinding||record,linked=[...(byOriginal.get(auditText(record.id))?.values()||[])];
    const page=Number(original.source?.page),type=record.type||original.type||'';
    const view={record,original,index,id:auditText(record.id),page:Number.isInteger(page)&&page>0?String(page):'',type,
      text:auditText(original.text),screen:auditText(record.screen),component:auditText(record.component),linked};
    view.searchable=auditNormalize([view.id,view.text,view.page,view.page?`página ${view.page} pág. ${view.page}`:'',type,humanKnowledgeLabel(type),...linked.flatMap(c=>[c.id,c.displayTitle])].join(' '));
    return view;
  });
  return {documentId:item.id,item,interpretation,clusters,records};
}
function auditStatsMarkup(stats) {
  return `<div class="audit-stats">${stats.filter(s=>s.value!=null).map(s=>`<div class="audit-stat"><strong>${escapeHtml(s.value)}</strong><span class="audit-stat-label ${s.tone||'neutral'}">${escapeHtml(s.label)}</span></div>`).join('')}</div>`;
}
function analysisModeHeader(title,description,icon) {
  return `<div class="analysis-mode-header"><span class="analysis-mode-icon analysis-mode-${icon}" aria-hidden="true"></span><div><h2>${escapeHtml(title)}</h2><p>${escapeHtml(description)}</p></div></div>`;
}
function auditFilterOptions(view) {
  const options=(key)=>auditUnique(view.records.map(r=>r[key])).sort((a,b)=>a.localeCompare(b,'es',{numeric:true})).map(value=>[value,key==='type'?humanKnowledgeLabel(value):value]);
  const related=new Map(view.records.flatMap(r=>r.linked.map(c=>[c.id,c.displayTitle])));
  return [['page','Página',options('page')],['type','Tipo',options('type')],['related','Relacionado con',[...related]],['screen','Pantalla',options('screen')],['component','Componente',options('component')]].filter(([, ,values])=>values.length);
}
function auditFilteredRecords(view,query) {
  const terms=auditNormalize(query.search).trim().split(/\s+/).filter(Boolean);
  return view.records.filter(r=>terms.every(term=>r.searchable.includes(term))&&['page','type','screen','component'].every(key=>!query[key]||r[key]===query[key])&&(!query.related||r.linked.some(c=>c.id===query.related)));
}
function auditRecordPage(view,query) {
  const filtered=auditFilteredRecords(view,query),pages=Math.max(1,Math.ceil(filtered.length/auditPageSize));
  const chunk=Math.min(Math.max(1,query.chunk||1),pages),start=(chunk-1)*auditPageSize;
  return {filtered,pages,chunk,start,records:filtered.slice(start,start+auditPageSize)};
}
function auditRecordDetail(view,entry) {
  const f=entry.record,raw=entry.original;
  const fact=(label,value)=>auditPresent(value)?`<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`:'';
  const relation=entry.linked.length?entry.linked.map(c=>`<li><button class="text-button" type="button" data-audit-insight="${escapeHtml(c.id)}">${escapeHtml(c.displayTitle)}</button><span>${escapeHtml(insightDecisionLabel(c.decision))} · ${escapeHtml(insightReviewLabel(c))}${c.decisionDetails?.targetId||c.learningId?` · ${escapeHtml(c.decisionDetails?.targetId||c.learningId)}`:''}</span></li>`).join(''):'<li>No consta una relación directa con una unidad de revisión.</li>';
  const units=(view.interpretation.units||[]).filter(u=>auditOriginalIds(u).includes(entry.id));
  return `<div class="audit-record-body"><h3>Texto original completo</h3><p class="audit-original-text">${escapeHtml(entry.text)}</p><dl class="audit-record-facts">${fact('ID',entry.id)}${fact('Página',entry.page||'No especificada')}${fact('Tipo de origen',raw.type)}${fact('Interpretación',humanKnowledgeLabel(f.type))}${fact('Sección',raw.source?.section)}${fact('Bloque',raw.source?.block)}${fact('Dónde aplica',pathOf(f))}${fact('Dispositivo',f.device)}${fact('Mercado',f.market)}${fact('Confianza',f.confidence)}${fact('Criterio de confianza',f.confidenceWhy)}${fact('Estado original',findingStatusLabel(f.status))}${fact('Tratamiento',f.semanticRole==='context'?'Contexto · no se consolida como hallazgo independiente':'Registro de conocimiento')}${fact('Criterio aplicado',f.interpretationReason)}${fact('Tags / dimensiones',(f.contextTags||[]).join(', '))}</dl><h3>Relacionado con</h3><ul class="audit-linked-list">${relation}</ul>${units.length?`<details class="audit-disclosure"><summary>Unidades y reconstrucciones vinculadas (${units.length})</summary>${units.map(unit=>`<section><h4>${escapeHtml(unit.id)}</h4><p>${escapeHtml(unit.text)}</p><p>${unit.derivedFromTable?'Fila reconstruida · ':''}Registros de origen: ${escapeHtml((unit.originalFindingIds||[]).join(', ')||'Referencia directa al documento')}</p>${unit.structure?`<pre>${escapeHtml(JSON.stringify(unit.structure,null,2))}</pre>`:''}</section>`).join('')}</details>`:''}<details class="audit-disclosure"><summary>Datos conservados del registro</summary><pre>${escapeHtml(JSON.stringify(raw,null,2))}</pre></details><p class="audit-record-source">${escapeHtml(view.item.name)} · ${escapeHtml(view.item.originalName||view.item.fileMeta?.name||'Archivo no disponible')} · ${escapeHtml(documentDate(view.item))} · ${escapeHtml(raw.source?.documentId||view.documentId)}<br>Solo lectura · Registros originales protegidos</p></div>`;
}
function auditRecordResultsMarkup(view,query) {
  const page=auditRecordPage(view,query);
  const range=page.filtered.length===1?'1 registro':page.filtered.length?`${page.start+1}–${page.start+page.records.length} de ${page.filtered.length} registros`:'0 registros';
  const rows=page.records.map(entry=>{
    const excerpt=entry.text.replace(/\s+/g,' ').trim(),short=excerpt.length>160?excerpt.slice(0,157)+'…':excerpt;
    const related=entry.linked[0]?.displayTitle||'Sin relación directa';
    return `<tr class="audit-record" data-audit-record="${escapeHtml(entry.id)}"><td data-label="ID"><strong>${escapeHtml(entry.id||`Registro ${entry.index+1}`)}</strong></td><td data-label="Página">${entry.page?`Pág. ${entry.page}`:'Sin página'}</td><td data-label="Tipo">${escapeHtml(humanKnowledgeLabel(entry.type)||'Sin tipo')}</td><td data-label="Extracto"><span class="audit-record-excerpt">${escapeHtml(short)}</span></td><td data-label="Relacionado con"><span class="audit-record-relation">${escapeHtml(related)}${entry.linked.length>1?` (+${entry.linked.length-1})`:''}</span></td><td data-label="Acción"><button class="view-link" type="button" data-audit-open="${escapeHtml(entry.id)}" aria-haspopup="dialog">Ver registro<span class="sr-only"> ${escapeHtml(entry.id)}</span></button></td></tr>`;
  }).join('');
  return `<p class="audit-result-count" role="status" aria-live="polite">${range}</p>${page.filtered.length?`<div class="table-shell audit-table-panel"><table class="data-table audit-record-table" aria-label="Registros originales"><thead><tr><th scope="col">ID</th><th scope="col">Página</th><th scope="col">Tipo</th><th scope="col">Extracto</th><th scope="col">Relacionado con</th><th scope="col"><span class="sr-only">Acción</span></th></tr></thead><tbody>${rows}</tbody></table>${paginationMarkup({page:page.chunk,total:page.filtered.length,size:auditPageSize,label:'registros',target:'records',controls:'audit-record-results'})}</div>`:'<div class="analysis-empty"><h3>No encontramos registros con estos filtros.</h3><button class="secondary-button" type="button" data-audit-clear>Limpiar filtros</button></div>'}`;
}
function openAuditRecord(id) {
  const entry=documentAuditView?.records.find(record=>record.id===id);if(!entry)return;
  const header=`<div class="drawer-kicker">Registro original</div><h2>${escapeHtml(entry.id)}</h2><p class="drawer-lead">${entry.page?`Página ${entry.page}`:'Página no especificada'} · ${escapeHtml(humanKnowledgeLabel(entry.type)||'Sin tipo')}</p>`;
  openDrawer(header,auditRecordDetail(documentAuditView,entry));
}
function documentRecordsMarkup(view) {
  const stats=[{value:view.records.length,label:'Registros conservados'},
    {value:auditUnique(view.records.map(r=>r.page)).length||null,label:'Páginas con registros'},
    {value:auditUnique(view.records.map(r=>r.type)).length||null,label:'Tipos de registro'},
    {value:view.records.some(r=>r.linked.length)?view.records.filter(r=>r.linked.length).length:null,label:'Relacionados'}];
  const query=documentRecordQuery.documentId===view.documentId?documentRecordQuery:{};
  const filters=auditFilterOptions(view).map(([key,label,options])=>`<label class="filter-field">${label}<select class="filter-select" data-audit-filter="${key}"><option value="">${key==='page'?'Todas las páginas':key==='type'?'Todos los tipos':key==='related'?'Todas las relaciones':key==='screen'?'Todas las pantallas':'Todos los componentes'}</option>${options.map(([value,text])=>`<option value="${escapeHtml(value)}" ${query[key]===value?'selected':''}>${escapeHtml(text)}</option>`).join('')}</select></label>`).join('');
  return `${analysisModeHeader('Registros originales','Comprueba el origen de una extracción o revisa un registro concreto.','records')}${auditStatsMarkup(stats)}<div class="audit-record-tools"><label class="filter-field audit-search">Buscar en registros<span class="audit-search-field"><span class="search-icon" aria-hidden="true"></span><input type="search" data-audit-search value="${escapeHtml(query.search||'')}" placeholder="Texto, página, tipo, ID o insight" aria-controls="audit-record-results" autocomplete="off"></span></label><div class="audit-record-filters">${filters}</div><button class="text-button" type="button" data-audit-clear>Limpiar filtros</button></div><div id="audit-record-results">${auditRecordResultsMarkup(view,query)}</div>`;
}
function auditCoverage(analysis) {
  const x=analysis.extraction||{},valid=n=>Number.isInteger(n)&&n>=0;
  const total=valid(x.detectedPages)?x.detectedPages:valid(analysis.pages)?analysis.pages:null;
  const read=valid(x.pagesRead)?x.pagesRead:valid(analysis.coverage?.pagesRead)?analysis.coverage.pagesRead:null;
  const failed=Array.isArray(x.failedPages)?x.failedPages:[],empty=Array.isArray(x.pagesWithoutText)?x.pagesWithoutText:[];
  const pageResults=Array.isArray(x.pageResults)?x.pageResults:[];
  const textPages=Array.isArray(analysis.extractedPages)?analysis.extractedPages:[];
  const pageSuccess=new Set(pageResults.filter(p=>(p.getTextContent?.ok||p.fallback?.ok)&&p.characters>0).map(p=>p.pageNumber));
  const textSuccess=new Set(textPages.filter(p=>typeof p.text==='string'&&p.text.trim()).map(p=>p.page));
  const allPages=total>0&&Array.from({length:total},(_,i)=>i+1).every(p=>pageSuccess.has(p)||textSuccess.has(p));
  const knownErrors=pageResults.some(p=>p.getTextContent?.ok===false&&!p.fallback?.ok);
  const partial=failed.length||empty.length||knownErrors||(total!=null&&read!=null&&read<total)||(valid(x.pagesWithText)&&total!=null&&x.pagesWithText<total);
  const complete=Boolean(total>0&&read===total&&allPages&&!partial);
  const title=complete?'Cobertura completa':partial?'Cobertura parcial':'Cobertura no confirmada';
  const message=complete?`Se han leído las ${total} páginas del documento y todas tienen texto extraído.`:partial?'Hay páginas sin lectura completa o sin texto extraíble. Consulta el detalle antes de dar por completo el análisis.':'Los datos conservados no permiten confirmar la lectura de todas las páginas.';
  return {total,read,failed,empty,complete,partial:Boolean(partial),title,message};
}
function documentCoverageMarkup(view,technicalMarkup) {
  const {item,interpretation,clusters}=view,analysis=item.analysis||{},coverage=auditCoverage(analysis);
  const discarded=Array.isArray(analysis.discarded)?analysis.discarded.length:Number.isInteger(analysis.coverage?.discarded)?analysis.coverage.discarded:null;
  const stats=[{value:coverage.read==null?null:coverage.total>0?`${coverage.read} / ${coverage.total}`:coverage.read,label:'Páginas analizadas'},
    {value:Array.isArray(analysis.findings)?analysis.findings.length:null,label:'Registros conservados'},
    {value:discarded,label:'Bloques descartados',tone:discarded?'system-pending':'neutral'},
    {value:Array.isArray(interpretation.tableRows)?interpretation.tableRows.length:null,label:'Filas reconstruidas'}];
  const types=Object.entries(interpretation.typeCounts||{}).filter(([,n])=>Number.isInteger(n)&&n>0);
  const reviewed=clusters.filter(insightIsReviewed).length,published=analysis.publication?.status==='published';
  const publication=published?(pendingAnalysisChanges(item).length?'Cambios pendientes de publicar':'Conocimiento publicado'):'Pendiente de publicar';
  const stages=[['Documento',item.originalName||item.fileMeta?.name||item.name],['Registros originales',`${view.records.length} registros originales`],['Insights / preguntas',`${clusters.length} unidades de revisión`],['Decisiones',`${reviewed} decisiones revisadas${reviewed<clusters.length?` · ${clusters.length-reviewed} pendientes`:''}`],['Publicación',publication]];
  const sections=Array.isArray(analysis.sections)?analysis.sections:[];
  const links=clusters.map(cluster=>{
    const related=view.records.filter(r=>r.linked.some(c=>c.id===cluster.id));
    return `<section class="audit-origin"><h4>${escapeHtml(cluster.displayTitle)}</h4><p>Páginas ${escapeHtml(formatPageRanges(cluster.pages||[]))} · ${related.length} registros originales vinculados · ${(cluster.findings||[]).length} unidades de conocimiento</p><p>${escapeHtml(insightDecisionLabel(cluster.decision))} · ${escapeHtml(insightReviewLabel(cluster))}${cluster.decisionDetails?.targetId||cluster.learningId?` · ${escapeHtml(cluster.decisionDetails?.targetId||cluster.learningId)}`:''}</p><div class="audit-origin-actions"><button class="text-button" type="button" data-audit-insight="${escapeHtml(cluster.id)}">Ver unidad de revisión</button>${related.length?`<button class="text-button" type="button" data-audit-related="${escapeHtml(cluster.id)}">Ver registros relacionados</button>`:''}</div><details class="audit-disclosure"><summary>Origen de las unidades</summary>${(cluster.findings||[]).map(unit=>`<p><strong>${escapeHtml(unit.id)}</strong> · pág. ${escapeHtml(unit.source?.page||'No disponible')}<br>${escapeHtml((unit.originalFindingIds||[]).length?`Registros: ${unit.originalFindingIds.join(', ')}`:view.records.some(r=>r.id===unit.id)?`Registro: ${unit.id}`:'Referencia directa a la fuente; sin ID de registro asociado.')}<br>${escapeHtml(unit.source?.excerpt||unit.text||'')}</p>`).join('')}</details></section>`;
  }).join('');
  const diagnostics=analysis.extraction?`<details class="audit-disclosure"><summary>Información de procesamiento conservada</summary><pre>${escapeHtml(JSON.stringify(analysis.extraction,null,2))}</pre></details>`:'';
  return `${analysisModeHeader('Cobertura y trazabilidad','Comprueba qué se ha analizado, qué se ha descartado y de dónde procede el contenido revisado.','coverage')}${auditStatsMarkup(stats)}<section class="audit-coverage-status ${coverage.complete?'audit-coverage-complete':'audit-coverage-warning'}" aria-label="Estado de cobertura"><h3>${coverage.title}</h3><p>${coverage.message}</p>${interpretation.tableDedup?.traceComplete===false?'<p>Hay unidades cuya trazabilidad necesita comprobación.</p>':''}${interpretation.tableDedup?.doubleCountedOriginalIds?.length?'<p>Hay referencias de tabla representadas más de una vez. Revisa el detalle técnico.</p>':''}</section><div class="audit-coverage-overview"><section><h3>Contenido detectado</h3>${types.length?`<p class="audit-caption">${types.reduce((sum,[,count])=>sum+count,0)} unidades de conocimiento</p><dl class="audit-type-counts">${types.map(([type,n])=>`<div><dt>${escapeHtml(humanKnowledgeLabel(type))}</dt><dd>${n}</dd></div>`).join('')}</dl>`:'<p>No hay un desglose de tipos conservado.</p>'}</section><section><h3>Trazabilidad</h3><ol class="audit-lineage">${stages.map(([label,value])=>`<li><span>${label}</span><strong>${escapeHtml(value)}</strong></li>`).join('')}</ol></section></div><div class="audit-detail-panel"><details class="audit-disclosure"><summary>Ver origen y destino (${clusters.length} unidades de revisión)</summary>${links}</details><details class="audit-disclosure"><summary>Ver secciones detectadas (${sections.length})</summary><ul>${sections.map(section=>`<li>${escapeHtml(section)}</li>`).join('')||'<li>No hay secciones conservadas.</li>'}</ul></details><details class="audit-disclosure audit-technical"><summary>Ver detalle técnico del análisis</summary>${technicalMarkup}${diagnostics}</details></div>`;
}
function mountDocumentAuditView(view) {
  documentAuditView=view;
  if(documentRecordQuery.documentId!==view.documentId)documentRecordQuery={documentId:view.documentId,search:'',page:'',type:'',related:'',screen:'',component:'',chunk:1};
}
function refreshAuditRecordResults(moveFocus=false) {
  const container=document.getElementById('audit-record-results');if(!container||!documentAuditView)return;
  documentRecordQuery.chunk=auditRecordPage(documentAuditView,documentRecordQuery).chunk;
  container.innerHTML=auditRecordResultsMarkup(documentAuditView,documentRecordQuery);
  if(moveFocus){const first=container.querySelector('.audit-result-count');first.tabIndex=-1;first.focus({preventScroll:true});first.scrollIntoView({block:'nearest'});}
}
function clearAuditRecordFilters() {
  if(!documentAuditView)return;
  documentRecordQuery={documentId:documentAuditView.documentId,search:'',page:'',type:'',related:'',screen:'',component:'',chunk:1};
  document.querySelectorAll('#review-pane-records [data-audit-filter],#review-pane-records [data-audit-search]').forEach(field=>field.value='');
  refreshAuditRecordResults();
}
document.addEventListener('input',event=>{
  if(!event.target.matches?.('#review-pane-records [data-audit-search]'))return;
  documentRecordQuery.search=event.target.value;documentRecordQuery.chunk=1;refreshAuditRecordResults();
});
document.addEventListener('change',event=>{
  const field=event.target.closest?.('#review-pane-records [data-audit-filter]');if(!field)return;
  documentRecordQuery[field.dataset.auditFilter]=field.value;documentRecordQuery.chunk=1;refreshAuditRecordResults();
});
document.addEventListener('click',event=>{
  const target=event.target.closest?.('#review [data-audit-clear],#review [data-audit-open],#review [data-audit-insight],#review [data-audit-related],#detail-drawer [data-audit-insight]');
  if(!target||!documentAuditView)return;
  if(target.hasAttribute('data-audit-clear')){clearAuditRecordFilters();document.querySelector('#review-pane-records [data-audit-search]')?.focus();return;}
  if(target.hasAttribute('data-audit-open')){openAuditRecord(target.dataset.auditOpen);return;}
  if(target.hasAttribute('data-audit-related')){
    clearAuditRecordFilters();documentRecordQuery.related=target.dataset.auditRelated;
    const field=document.querySelector('#review-pane-records [data-audit-filter="related"]');if(field)field.value=documentRecordQuery.related;
    activateReviewTab('findings',true);refreshAuditRecordResults(true);return;
  }
  const card=document.getElementById(`cluster-${target.dataset.auditInsight}`);if(!card)return;
  closeDrawer();activateReviewTab('clusters',true);card.open=true;
  const summary=card.querySelector('summary');summary.focus({preventScroll:true});summary.scrollIntoView({block:'center'});
});
