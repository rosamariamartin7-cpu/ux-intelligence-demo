// One presentation-only paginator for catalogues and original records.
// Filter values and current pages are transient, never written to project data.
const catalogPages = new Map();
const catalogPageTargets = {learning:'learning-list',evidence:'evidence-table',experiment:'experiment-table',pattern:'pattern-list',source:'source-table'};
function paginationNumbers(current,total) {
  if(total<=7)return Array.from({length:total},(_,i)=>i+1);
  const numbers=new Set([1,total,current-1,current,current+1]);
  if(current<=4)[2,3,4,5].forEach(n=>numbers.add(n));
  if(current>=total-3)[total-4,total-3,total-2,total-1].forEach(n=>numbers.add(n));
  const result=[];
  for(const n of [...numbers].filter(n=>n>0&&n<=total).sort((a,b)=>a-b)){
    const previous=result[result.length-1];
    if(previous&&n-previous===2)result.push(previous+1);
    else if(previous&&n-previous>2)result.push('…');
    result.push(n);
  }
  return result;
}
function paginationMarkup({page,total,size=10,label,target,controls}) {
  const pages=Math.max(1,Math.ceil(total/size));
  if(pages===1)return '';
  const current=Math.min(Math.max(1,page),pages),start=(current-1)*size+1,end=Math.min(current*size,total);
  const attrs=n=>`data-page-target="${escapeHtml(target)}" data-page="${n}" aria-controls="${escapeHtml(controls)}"`;
  return `<nav class="list-pagination" aria-label="Paginación de ${escapeHtml(label)}"><p class="pagination-range">${start}–${end} de ${total} ${escapeHtml(label)}</p><div class="pagination-controls"><button class="secondary-button pagination-previous" type="button" ${attrs(current-1)} ${current===1?'disabled':''} aria-label="Página anterior"><span aria-hidden="true">←</span><span class="pagination-word">Anterior</span></button><div class="pagination-numbers">${paginationNumbers(current,pages).map(n=>n==='…'?'<span class="pagination-ellipsis" aria-hidden="true">…</span>':`<button class="pagination-number" type="button" ${attrs(n)} aria-label="Página ${n}" ${n===current?'aria-current="page"':''}>${n}</button>`).join('')}</div><span class="pagination-mobile">Página ${current} de ${pages}</span><button class="secondary-button pagination-next" type="button" ${attrs(current+1)} ${current===pages?'disabled':''} aria-label="Página siguiente"><span class="pagination-word">Siguiente</span><span aria-hidden="true">→</span></button></div></nav>`;
}
function catalogPage(items,group,label) {
  const target=catalogPageTargets[group],fields=document.querySelectorAll(`[data-filter-group="${group}"] select,[data-filter-group="${group}"] input`);
  const signature=JSON.stringify([...fields].map(field=>[field.id,field.value]));
  const previous=catalogPages.get(group),page=previous?.signature===signature?previous.page:1;
  const current=Math.min(page,Math.max(1,Math.ceil(items.length/10)));
  catalogPages.set(group,{signature,page:current});
  const shell=document.getElementById(target)?.closest('.table-shell');
  if(shell){
    shell.querySelector('.list-pagination')?.remove();
    shell.insertAdjacentHTML('beforeend',paginationMarkup({page:current,total:items.length,label,target:group,controls:target}));
  }
  return items.slice((current-1)*10,current*10);
}
document.addEventListener('click',event=>{
  const button=event.target.closest?.('[data-page-target]');if(!button||button.disabled)return;
  const target=button.dataset.pageTarget,page=Number(button.dataset.page);
  if(target==='records'){
    documentRecordQuery.chunk=page;refreshAuditRecordResults(true);return;
  }
  const state=catalogPages.get(target);if(!state||!catalogPageTargets[target])return;
  state.page=page;renderers[target]();
  const first=document.getElementById(catalogPageTargets[target])?.querySelector('button,tr');
  first?.focus({preventScroll:true});first?.scrollIntoView({block:'nearest'});
});
