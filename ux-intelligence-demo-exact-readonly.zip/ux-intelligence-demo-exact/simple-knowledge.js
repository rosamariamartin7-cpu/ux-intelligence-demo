(function(){
  'use strict';
  const base=globalThis.UXSimpleKnowledgeData||{version:'simple-kb-1',documents:[],records:[]};
  const filterFields=[
    ['product','Producto','Todos los productos'],['funnel','Funnel','Todos los funnels'],['minifunnel','Minifunnel','Todos los minifunnels'],
    ['screen','Pantalla','Todas las pantallas'],['component','Componente','Todos los componentes'],['element','Elemento','Todos los elementos'],
    ['device','Dispositivo','Todos los dispositivos'],['market','Mercado','Todos los mercados'],['userState','Estado del usuario','Todos los estados']
  ];
  const state={query:'',documents:[],groups:[],eventsReady:false};
  const clean=value=>String(value??'').replace(/\s+/g,' ').trim();
  const fold=value=>clean(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const escape=value=>clean(value).replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
  const unique=values=>[...new Set(values.map(clean).filter(Boolean))];
  const hash=value=>{let result=2166136261;for(const char of value){result^=char.charCodeAt(0);result=Math.imul(result,16777619);}return (result>>>0).toString(36);};
  const contextKey=row=>['product','funnel','minifunnel','screen','component','element','device','market','userState','recordType'].map(key=>fold(row[key])).join('|');
  const groupKey=row=>`${contextKey(row)}|${fold(row.insight)}`;

  function normalizedRegisterRow(row,documentItem){
    return {
      id:`${documentItem.id}-${row.id||row.sourceRow}`,
      documentId:documentItem.id,
      workbook:documentItem.insightRegister?.file?.name||'',
      sourceRow:row.sourceRow||'',
      product:row.product||'',funnel:row.funnel||'',minifunnel:row.minifunnel||'',screen:row.screen||'',component:row.component||'',element:row.element||'',
      recordType:row.recordType||'',insight:row.insight||'',origin:row.origin||row.findingOrigin||'',device:row.channelEnvironment||row.device||'',market:row.market||'',region:row.region||'',userState:row.userState||row.segment||'',
      platformSystem:row.platformSystem||'',evidence:row.evidence||'',uxImplication:row.uxImplication||row.uxReading||'',status:row.result||row.status||row.resultStatus||'',implementation:row.implementation||'',confidence:row.confidence||'',impactUx:row.impactUx||'',experimentPotential:row.experimentPotential||'',recommendation:row.recommendation||'',openQuestion:row.openQuestion||'',uxLine:row.uxLine||'',source:row.source||documentItem.name||'',observations:row.observations||row.notes||''
    };
  }

  function allRecords(documents=[]){
    const dynamic=documents.filter(item=>item?.simpleKnowledgeActive===true&&item.insightRegister?.version==='insight-register-2')
      .flatMap(item=>(item.insightRegister.rows||[]).map(row=>normalizedRegisterRow(row,item)));
    const known=new Set(base.records.map(row=>`${row.workbook}|${row.sourceRow}`));
    return [...base.records,...dynamic.filter(row=>!known.has(`${row.workbook}|${row.sourceRow}`))];
  }

  function consolidate(records){
    const grouped=new Map();
    records.forEach(row=>{
      const key=groupKey(row);if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(row);
    });
    return [...grouped.entries()].map(([key,rows])=>{
      const first=rows[0],sources=unique(rows.map(row=>row.source)),origins=unique(rows.map(row=>row.origin)),devices=unique(rows.map(row=>row.device)),markets=unique(rows.map(row=>row.market)),userStates=unique(rows.map(row=>row.userState)),statuses=unique(rows.map(row=>row.status));
      return {id:`SK-${hash(key)}`,key,rows,first,sources,origins,devices,markets,userStates,statuses,contradictory:statuses.includes('Resultado mixto')||(['Resultado positivo','Resultado negativo','Resultado neutral'].filter(value=>statuses.includes(value)).length>1)};
    }).sort((a,b)=>a.first.insight.localeCompare(b.first.insight,'es'));
  }

  function currentGroups(){state.groups=consolidate(allRecords(state.documents));return state.groups;}
  function combined(values){const list=unique(values);if(list.length===2&&list.includes('Desktop')&&list.includes('Mobile'))return 'Desktop + Mobile';return list.join(' · ');}
  function statusClass(status){return fold(status).includes('positivo')?'simple-positive':fold(status).includes('mixto')?'simple-mixed':fold(status).includes('externa')?'simple-external':fold(status).includes('restric')?'simple-warning':'simple-neutral';}
  function relevantUserState(values){const list=unique(values);return list.length&&!(list.length===1&&fold(list[0])==='no especificado')?combined(list):'';}

  function renderOverview({documents=[]}={}){
    state.documents=documents;const records=allRecords(documents),groups=consolidate(records),documentsList=[...base.documents];
    const navCount=document.querySelector('[data-simple-knowledge-count]');if(navCount)navCount.textContent=groups.length;
    const stats=document.getElementById('simple-home-stats');
    if(stats)stats.innerHTML=[
      [groups.length,'Unidades consultables'],[records.length,'Registros del Excel'],[documentsList.length,'Fuentes estructuradas'],[unique(records.map(row=>row.recordType)).length,'Tipos de registro']
    ].map(([value,label])=>`<div class="simple-stat"><strong>${value}</strong><span>${label}</span></div>`).join('');
    const sourceList=document.getElementById('simple-source-list');
    if(sourceList)sourceList.innerHTML=documentsList.map(item=>`<div class="simple-source-row"><div><strong>${escape(item.title)}</strong><span>${escape(item.origins.join(' · '))}</span></div><span>${item.recordCount} registros</span></div>`).join('');
    const typeSummary=document.getElementById('simple-type-summary');
    if(typeSummary){const counts=unique(records.map(row=>row.recordType)).map(type=>[type,records.filter(row=>row.recordType===type).length]);typeSummary.innerHTML=counts.map(([type,count])=>`<div><strong>${count}</strong><span>${escape(type)}</span></div>`).join('');}
    ensureEvents();
  }

  function optionMarkup(values,allLabel){return `<option value="">${escape(allLabel)}</option>${unique(values).sort((a,b)=>a.localeCompare(b,'es')).map(value=>`<option value="${escape(value)}">${escape(value)}</option>`).join('')}`;}
  function filterValues(){const values={};filterFields.forEach(([key])=>values[key]=document.getElementById(`simple-${key}`)?.value||'');return values;}
  function visibleContext(group,filters){return ['product','funnel','minifunnel','screen','component','element'].map(key=>filters[key]?'':group.first[key]).filter(Boolean);}
  function rowMarkup(group,filters){
    const context=visibleContext(group,filters),userState=relevantUserState(group.userStates),status=group.contradictory?'Resultado mixto':combined(group.statuses);
    const meta=[`${group.sources.length} ${group.sources.length===1?'fuente':'fuentes'}`,combined(group.origins),combined(group.devices),userState,status,...context].filter(Boolean);
    return `<button class="simple-result-row" type="button" data-simple-record="${group.id}"><span class="simple-record-type">${escape(group.first.recordType)}</span><strong>${escape(group.first.insight)}</strong><span class="simple-result-meta">${meta.map(value=>`<span>${escape(value)}</span>`).join('')}</span><span class="simple-row-action">Ver detalle</span></button>`;
  }

  function renderExplore({documents=state.documents}={}){
    state.documents=documents;const records=allRecords(documents),all=consolidate(records);state.groups=all;
    const navCount=document.querySelector('[data-simple-knowledge-count]');if(navCount)navCount.textContent=all.length;
    filterFields.forEach(([key,,allLabel])=>{const select=document.getElementById(`simple-${key}`);if(!select)return;const current=select.value;select.innerHTML=optionMarkup(records.map(row=>row[key]),allLabel);if([...select.options].some(option=>option.value===current))select.value=current;});
    const filters=filterValues(),query=fold(document.getElementById('simple-query')?.value||state.query);state.query=query;
    const groups=all.filter(group=>Object.entries(filters).every(([key,value])=>!value||group.rows.some(row=>row[key]===value))).filter(group=>!query||group.rows.some(row=>fold(Object.values(row).join(' ')).includes(query)));
    const result=document.getElementById('simple-result-count');if(result)result.textContent=`${groups.length} ${groups.length===1?'resultado':'resultados'} · ${groups.reduce((sum,group)=>sum+group.rows.length,0)} registros`;
    const list=document.getElementById('simple-results');if(list)list.innerHTML=groups.length?groups.map(group=>rowMarkup(group,filters)).join(''):'<div class="simple-empty"><strong>No hay conocimiento para esta selección.</strong><span>Prueba a retirar algún filtro; no se crearán inferencias para rellenar el resultado.</span></div>';
    const active=document.getElementById('simple-active-filters');if(active){const chips=Object.entries(filters).filter(([,value])=>value).map(([key,value])=>{const label=filterFields.find(field=>field[0]===key)?.[1]||key;return `<button type="button" data-simple-remove-filter="${key}">${escape(label)}: ${escape(value)} <span aria-hidden="true">×</span></button>`;});active.hidden=!chips.length;active.innerHTML=chips.length?`<span>Filtros activos</span>${chips.join('')}<button type="button" class="simple-clear" data-simple-clear-filters>Limpiar todo</button>`:'';}
    ensureEvents();
  }

  function detailSection(title,items,render){if(!items.length)return '';return `<section class="drawer-section"><h3>${escape(title)}</h3>${items.map(render).join('')}</section>`;}
  function openById(id){
    const group=(state.groups.length?state.groups:currentGroups()).find(item=>item.id===id);if(!group)return;
    const first=group.first,status=group.contradictory?'Resultado mixto':combined(group.statuses),context=[['Producto',first.product],['Funnel',first.funnel],['Minifunnel',first.minifunnel],['Pantalla',first.screen],['Componente',first.component],['Elemento',first.element]].filter(([,value])=>value);
    const header=`<div class="drawer-kicker">${escape(first.recordType)}</div><h2>${escape(first.insight)}</h2><div class="drawer-tags"><span class="status-badge ${statusClass(status)}">${escape(status)}</span></div><div class="drawer-context">${context.map(([label,value])=>`<div><strong>${escape(label)}:</strong> ${escape(value)}</div>`).join('')}<div><strong>Dispositivo:</strong> ${escape(combined(group.devices))}</div><div><strong>Mercado:</strong> ${escape(combined(group.markets))}</div>${relevantUserState(group.userStates)?`<div><strong>Estado del usuario:</strong> ${escape(relevantUserState(group.userStates))}</div>`:''}</div>`;
    const evidenceVariants=new Map();group.rows.forEach(row=>{const key=[row.source,row.evidence,row.uxImplication,row.observations,row.status,row.experimentPotential].join('|');if(!evidenceVariants.has(key))evidenceVariants.set(key,{...row,devices:[]});evidenceVariants.get(key).devices.push(row.device);});
    const variants=[...evidenceVariants.values()];
    const body=`${detailSection('Evidencia / dato clave',variants,item=>`<div class="simple-detail-block"><strong>${escape(item.source)}</strong><span>${escape(item.origin)} · ${escape(combined(item.devices))}</span><p>${escape(item.evidence)}</p></div>`)}${detailSection('Implicación UX',unique(group.rows.map(row=>row.uxImplication)),item=>`<p>${escape(item)}</p>`)}<section class="drawer-section"><h3>Estado y potencial</h3><dl class="simple-detail-list"><div><dt>Estado / resultado</dt><dd>${escape(status)}</dd></div><div><dt>Potencial de experimentación</dt><dd>${escape(combined(group.rows.map(row=>row.experimentPotential)))}</dd></div></dl></section>${detailSection('Observaciones',unique(group.rows.map(row=>row.observations)),item=>`<p>${escape(item)}</p>`)}${detailSection('Fuentes y trazabilidad',variants,item=>`<div class="simple-source-reference"><strong>${escape(item.source)}</strong><span>${escape(item.workbook)} · ${escape(unique(group.rows.filter(row=>row.source===item.source).map(row=>`fila ${row.sourceRow}`)).join(' · '))}</span></div>`)}`;
    if(typeof globalThis.openDrawer==='function')globalThis.openDrawer(header,body);
  }

  function goToExplore(query=''){
    state.query=clean(query);document.querySelector('[data-panel="explore"]')?.click();requestAnimationFrame(()=>{const input=document.getElementById('simple-query');if(input){input.value=state.query;renderExplore();input.focus({preventScroll:true});}});
  }
  function searchGroups(query,{documents=state.documents}={}){state.documents=documents;const q=fold(query);if(q.length<2)return [];const items=consolidate(allRecords(documents)).filter(group=>group.rows.some(row=>fold(Object.values(row).join(' ')).includes(q))).slice(0,8);state.groups=consolidate(allRecords(documents));return items.length?[{label:'Conocimiento estructurado',kind:'simple-record',items,title:item=>item.first.insight,meta:item=>`${item.sources.length} ${item.sources.length===1?'fuente':'fuentes'} · ${combined(item.origins)} · ${combined(item.devices)}`}]:[];}

  function ensureEvents(){
    if(state.eventsReady)return;state.eventsReady=true;
    document.addEventListener('click',event=>{
      const record=event.target.closest?.('[data-simple-record]');if(record){openById(record.dataset.simpleRecord);return;}
      const open=event.target.closest?.('[data-simple-open-explore]');if(open){goToExplore(document.getElementById('simple-home-query')?.value||'');return;}
      const remove=event.target.closest?.('[data-simple-remove-filter]');if(remove){const select=document.getElementById(`simple-${remove.dataset.simpleRemoveFilter}`);if(select)select.value='';renderExplore();return;}
      if(event.target.closest?.('[data-simple-clear-filters]')){filterFields.forEach(([key])=>{const select=document.getElementById(`simple-${key}`);if(select)select.value='';});renderExplore();}
    });
    document.addEventListener('change',event=>{if(event.target.closest?.('#simple-filters'))renderExplore();});
    document.addEventListener('input',event=>{if(event.target.id==='simple-query'){state.query=event.target.value;renderExplore();}});
    document.addEventListener('keydown',event=>{if(event.key==='Enter'&&event.target.id==='simple-home-query'){event.preventDefault();goToExplore(event.target.value);}});
  }

  globalThis.UXSimpleKnowledge={version:base.version,filterFields,renderOverview,renderExplore,openById,goToExplore,searchGroups,allRecords,consolidate};
})();
