// Document-first analysis. Pure, serializable output; no storage or publication.
var UXDocumentAnalysis = (() => {
  const version='document-first-1';
  const norm=value=>String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const clean=value=>String(value||'').replace(/\s+/g,' ').trim();
  const unique=values=>[...new Set(values)];
  const synthesis=/^(resumen (?:de )?insights|conclusiones(?: finales)?|key findings|hallazgos principales|que aprendimos|recomendaciones finales)$/;
  const limitHeading=/^(que no demuestra|limites|limitaciones)(?:\b.*)?$/;
  const questionHeading=/^(preguntas abiertas|open questions|preguntas pendientes)$/;
  const stop=new Set('el la los las un una unos unas de del al y o a en por para con sin como que se su sus es son no si mas menos muy esta este estos estas puede pueden debe deben actual actualmente mismo misma dentro parte desde entre antes despues sobre cada cuando solo tambien tiene tienen'.split(' '));
  const broad=new Set(['header','navegacion','jerarquia','prioridad','accesos','contenido','contenidos','usuario','sistema','claridad']);
  const lexicon={labels:'naming',label:'naming',nombres:'naming',nombre:'naming',literales:'naming',literal:'naming',etiquetas:'naming',agrupacion:'agrupar',agrupaciones:'agrupar',mezcla:'agrupar',mezclan:'agrupar',conviven:'agrupar',convivir:'agrupar',complejidad:'complejo',compleja:'complejo',complejas:'complejo',simplicidad:'simple',simplifica:'simple',simplificacion:'simple',anticipacion:'anticipar',anticipa:'anticipar',anticipan:'anticipar'};
  const stem=word=>(lexicon[word]||word).replace(/(?:amientos?|imientos?|aciones?|idades?|mente)$/,'').replace(/s$/,'').replace(/[aeiou]$/,'').slice(0,8);
  function normalizeDataTree(value,path='analysis',ancestors=new WeakMap()){
    const type=typeof value;
    if(type==='undefined')return undefined;
    if(type==='function'||type==='symbol'||type==='bigint')throw new Error(`${path}: ${type} no persistible`);
    if(!value||type!=='object')return value;
    if(ancestors.has(value))throw new Error(`${path}: referencia circular con ${ancestors.get(value)}`);
    const prototype=Object.getPrototypeOf(value),plainObject=Object.prototype.toString.call(value)==='[object Object]'&&(prototype===null||value.constructor?.name==='Object');
    if(!Array.isArray(value)&&!plainObject)throw new Error(`${path}: ${value.constructor?.name||'objeto no plano'} no persistible`);
    ancestors.set(value,path);
    let clone;
    if(Array.isArray(value))clone=value.map((item,index)=>{
      if(typeof item==='undefined')throw new Error(`${path}.${index}: undefined en array`);
      return normalizeDataTree(item,`${path}.${index}`,ancestors);
    });
    else clone=Object.fromEntries(Object.entries(value).flatMap(([key,item])=>typeof item==='undefined'?[]:[[key,normalizeDataTree(item,`${path}.${key}`,ancestors)]]));
    ancestors.delete(value);
    return clone;
  }
  function inspectDataTree(value){
    const result={circularReferences:[],sharedReferences:[],unsupportedValues:[],undefinedValues:[]},active=new WeakMap(),firstPath=new WeakMap();
    const visit=(item,path,inArray=false)=>{
      const type=typeof item;
      if(type==='undefined'){result.undefinedValues.push(path);return;}
      if(type==='function'||type==='symbol'||type==='bigint'){result.unsupportedValues.push({path,type});return;}
      if(!item||type!=='object')return;
      if(active.has(item)){result.circularReferences.push({path,origin:active.get(item)});return;}
      if(firstPath.has(item)){result.sharedReferences.push({path,origin:firstPath.get(item)});return;}
      const prototype=Object.getPrototypeOf(item),plainObject=Object.prototype.toString.call(item)==='[object Object]'&&(prototype===null||item.constructor?.name==='Object');
      if(!Array.isArray(item)&&!plainObject){result.unsupportedValues.push({path,type:item.constructor?.name||'objeto no plano'});return;}
      firstPath.set(item,path);active.set(item,path);
      if(Array.isArray(item))item.forEach((child,index)=>visit(child,`${path}.${index}`,true));
      else Object.entries(item).forEach(([key,child])=>visit(child,`${path}.${key}`,false));
      active.delete(item);
    };
    visit(value,'analysis');
    result.total=result.circularReferences.length+result.sharedReferences.length+result.unsupportedValues.length+result.undefinedValues.length;
    return result;
  }
  function tokens(text){return unique(norm(text).match(/[a-z]+/g)?.filter(w=>w.length>3&&!stop.has(w)).map(stem)||[]);}
  function similarity(a,b){const x=tokens(a),y=new Set(tokens(b));return x.length&&y.size?2*x.filter(w=>y.has(w)).length/(x.length+y.size):0;}
  function pagesWithoutFurniture(pages){
    const count=new Map();
    pages.forEach(p=>unique(p.text.split('\n').map(clean).filter(Boolean)).forEach(line=>count.set(line,(count.get(line)||0)+1)));
    return pages.map(p=>({...p,lines:p.text.split('\n').map((text,index)=>({text:clean(text),line:index+1})).filter(l=>!/^\s*[→➜]/.test(l.text)&&!(count.get(l.text)>=Math.max(3,pages.length*.55)))}));
  }
  function paragraphs(lines){
    const groups=[];let buffer=[];
    const flush=()=>{if(buffer.length){groups.push({text:clean(buffer.map(l=>l.text).join(' ')),lines:buffer.map(l=>l.line)});buffer=[];}};
    lines.forEach(line=>{if(!line.text){flush();return;}buffer.push(line);if(/[.!?]$/.test(line.text))flush();});flush();return groups;
  }
  function scopeFrom(pages,document){
    const scope={included:[],excluded:[],screens:[],devices:[],component:'',products:[],sourcePages:[],explicit:false};
    for(const page of pages){
      const lines=page.lines.filter(l=>l.text),heading=lines.findIndex(l=>/^alcance (?:del |de |y )?(?:analisis|documento|estudio)/.test(norm(l.text)));
      if(heading<0)continue;
      const body=lines.slice(heading+1),text=clean(body.map(l=>l.text).join(' '));
      scope.component=/\bheader\b/i.test(text)?'Header':/\bbuscador\b/i.test(text)?'Buscador':document.component||'';
      scope.explicit=true;scope.sourcePages.push(page.page);
      let mode='';
      for(const line of body){
        const n=norm(line.text);
        if(/^(se revisan|se analiza[n]?|incluye|dentro del alcance)/.test(n)&&/:$/.test(n)){mode='included';continue;}
        if(/^(quedan? fuera|fuera de alcance|se excluye[n]?|no se analiza[n]?)/.test(n)&&/:$/.test(n)){mode='excluded';continue;}
        if(/^(la revision|este alcance|el analisis|la metodologia)/.test(n)){mode='';}
        if(mode)scope[mode].push(line.text.replace(/^[-•]\s*/,''));
        if(/la revision.*desktop|la revision.*mobile/.test(n)){if(/desktop/.test(n))scope.devices.push('Desktop');if(/mobile/.test(n))scope.devices.push('Mobile');}
      }
    }
    scope.included=unique(scope.included);scope.excluded=unique(scope.excluded);scope.devices=unique(scope.devices);
    scope.screens=scope.included.filter(s=>/home|pagina|pantalla/.test(norm(s)));
    if(!scope.component)scope.component=/\bheader\b/i.test(document.name)?'Header':/\bbuscador\b/i.test(document.name)?'Buscador':document.component||'';
    // An exclusion is not an inferred product assignment. Keep unknown unknown.
    scope.products=scope.included.filter(s=>/^(booking|check-in|mmb|suma)$/i.test(s));
    return scope;
  }
  function sourceFor(page,entry,findings,section){
    const text=norm(entry.text),words=tokens(text);
    const originalFindingIds=findings.filter(f=>{const other=tokens(f.text);return Number(f.source.page)===page.page&&(norm(f.text).includes(text)||words.filter(w=>other.includes(w)).length>=Math.max(3,Math.min(words.length,other.length)*.6));}).map(f=>f.id);
    return {page:page.page,section,lines:entry.lines,excerpt:entry.text,originalFindingIds};
  }
  function editorialTable(page,start,findings){
    const lines=page.lines.slice(start+1).filter(l=>l.text),header=lines.findIndex(l=>/^insights?\b/i.test(l.text)&&/observamos|observacion/i.test(l.text));
    if(header<0)return null;
    const stateStart=lines.findIndex((l,i)=>i>header&&/^(aplicado|implementado|no aplicado|pendiente)$/i.test(l.text));
    if(stateStart<0)return null;
    const cells=[];let buffer=[];
    const flush=()=>{if(buffer.length){cells.push({text:clean(buffer.map(l=>l.text).join(' ')),lines:buffer.map(l=>l.line)});buffer=[];}};
    for(const line of lines.slice(header+1,stateStart)){
      if(buffer.length&&/^[A-ZÁÉÍÓÚÑ¿]/.test(line.text)&&! /\b(y|de|del|la|el|con|para|por|en|una|un)$/i.test(buffer.at(-1).text))flush();
      buffer.push(line);if(/[.!?]$/.test(line.text))flush();
    }flush();
    const rows=[];
    // Accept adjacent title/observation cells only when their roles are unambiguous.
    for(let i=0;i<cells.length;i+=2){
      const pair=cells.slice(i,i+2),title=pair.filter(c=>!/[.!?]$/.test(c.text)),observation=pair.filter(c=>/[.!?]$/.test(c.text));
      if(title.length!==1||observation.length!==1)return {rows:[],warning:'La tabla de síntesis necesita comprobar la correspondencia entre celdas.'};
      const ref=sourceFor(page,{text:pair.map(c=>c.text).join(' '),lines:pair.flatMap(c=>c.lines)},findings,'Síntesis editorial · tabla');
      ref.originalFindingIds=unique(pair.flatMap(cell=>sourceFor(page,cell,findings,ref.section).originalFindingIds));
      rows.push({title:title[0].text,synthesis:observation[0].text,source:ref});
    }
    if(!rows.length)return null;
    const tailLines=lines.slice(stateStart),tail=tailLines.map(l=>l.text).join(' ');
    const matchedCells=pattern=>[...tail.matchAll(pattern)].map(match=>{
      let cursor=0;const sourceLines=tailLines.filter(line=>{const from=cursor;cursor+=line.text.length+1;return from<match.index+match[0].length&&cursor>match.index;}).map(l=>l.line);
      return {text:match[0],lines:sourceLines};
    });
    const states=matchedCells(/(?:Aplicado|Implementado|No aplicado|Pendiente)\s+actualmente/gi);
    const readings=matchedCells(/Fricción\s*\/\s*revisar|Adecuado\s+en unos\s+contextos,\s*mejorable\s+en otros/gi);
    const actionStart=lines.findIndex((l,i)=>i>=stateStart&&/^(Revisar |Reordenar |Validar |Diseñar |Investigar |Mantener )/.test(l.text));
    const actions=actionStart<0?[]:paragraphs(lines.slice(actionStart).filter(l=>!/^Estado actual\b/.test(l.text)));
    rows.forEach((row,i)=>{
      row.currentState={kind:'Hecho',description:states.length===rows.length?states[i].text:'No especificado',source:states.length===rows.length?sourceFor(page,states[i],findings,'Estado actual · tabla'):null};
      row.uxReading=readings.length===rows.length?readings[i].text:'Lectura del autor pendiente de correspondencia';
      row.uxReadingSource=readings.length===rows.length?sourceFor(page,readings[i],findings,'Lectura UX · tabla'):null;
      row.authorDecision=actions.length===rows.length?actions[i].text:'';
      row.authorDecisionSource=actions.length===rows.length?sourceFor(page,actions[i],findings,'Propuesta del autor · tabla'):null;
      const refs=[row.currentState.source,row.uxReadingSource,row.authorDecisionSource].filter(Boolean);
      row.source.originalFindingIds=unique([...row.source.originalFindingIds,...refs.flatMap(ref=>ref.originalFindingIds)]);
      row.source.lines=unique([...row.source.lines,...refs.flatMap(ref=>ref.lines)]).sort((a,b)=>a-b);
    });
    return {rows};
  }
  function readEditorial(pages,findings){
    const result={anchors:[],questions:[],limits:[],pages:[],warnings:[]};
    for(const page of pages){
      const lines=page.lines;
      for(let i=0;i<lines.length;i++){
        const heading=norm(lines[i].text);
        if(!synthesis.test(heading)&&!limitHeading.test(heading)&&!questionHeading.test(heading))continue;
        let end=i+1;while(end<lines.length&&!synthesis.test(norm(lines[end].text))&&!limitHeading.test(norm(lines[end].text))&&!questionHeading.test(norm(lines[end].text)))end++;
        const body=lines.slice(i+1,end);
        if(synthesis.test(heading)){
          const table=editorialTable(page,i,findings);
          if(table){result.anchors.push(...table.rows);if(table.warning)result.warnings.push(table.warning);}
          else {
            const entries=paragraphs(body);
            for(const entry of entries.filter(e=>e.text.length>35)){
              const text=entry.text.replace(/^(?:\d+[.)]\s*|[-•]\s*)/,'');
              result.anchors.push({title:text.split(/(?<=[.!?])\s+/)[0],synthesis:text,source:sourceFor(page,entry,findings,lines[i].text)});
            }
          }
        }else if(questionHeading.test(heading)){
          const joined=body.map(l=>l.text).join(' ');
          for(const match of joined.matchAll(/¿[^?]+\?/g))result.questions.push({text:clean(match[0]),source:sourceFor(page,{text:clean(match[0]),lines:body.filter(l=>l.text&&match[0].includes(l.text)).map(l=>l.line)},findings,lines[i].text)});
        }else paragraphs(body).forEach(entry=>result.limits.push({text:entry.text,source:sourceFor(page,entry,findings,lines[i].text)}));
        result.pages.push(page.page);i=end-1;
      }
    }
    result.pages=unique(result.pages);
    result.anchors=result.anchors.filter((a,i,all)=>all.findIndex(b=>norm(a.title)===norm(b.title))===i);
    return result;
  }
  function context(scope,text){
    const mobile=/\bmobile|movil\b/i.test(text),desktop=/\bdesktop\b/i.test(text);
    return {product:scope.products[0]||'No especificado',screen:scope.screens[0]||'No especificado',component:scope.component,element:'',
      device:mobile&&desktop?'Desktop + mobile':mobile?'Mobile':desktop?'Desktop':scope.devices.length===2?'Desktop + mobile':scope.devices[0]||'No especificado',market:'No especificado'};
  }
  function compareKnowledge(cluster,scope,kb){
    const candidates=kb.map(k=>{
      const score=similarity(`${cluster.displayTitle} ${cluster.displaySynthesis}`,`${k.title||''} ${k.know||k.text||''}`);
      const compatibleComponent=k.component===scope.component||k.components?.includes(scope.component);
      const excluded=scope.excluded.some(value=>norm(value)===norm(k.product));
      return {id:k.id,score,direct:compatibleComponent&&!excluded&&scope.products.includes(k.product),reason:excluded?'Producto fuera del alcance directo':!compatibleComponent?'Componente distinto':'Contexto por confirmar'};
    }).filter(c=>c.score>=.15).sort((a,b)=>b.score-a.score);
    const direct=candidates.find(c=>c.direct&&c.score>=.55);
    if(cluster.kind==='question')return {decision:'Crear pregunta abierta',learningId:'',candidates};
    if(cluster.kind!=='author')return {decision:'Mantener solo como evidencia',learningId:'',candidates};
    if(cluster.possibleContradictions?.length)return {decision:'Crear pregunta abierta',learningId:'',candidates};
    if(/recomendaciones/.test(norm(cluster.source.section)))return {decision:'Posible oportunidad',learningId:'',candidates};
    // A human conclusion is a proposal, not validation or proof of effectiveness.
    if(!cluster.supportingUnitIds.length)return {decision:'Mantener solo como evidencia',learningId:'',candidates};
    return {decision:direct?'Ampliar learning':'Crear nuevo learning',learningId:direct?.id||'',candidates};
  }
  function prepare(analysis,document,pages,kb){
    const cleaned=pagesWithoutFurniture(pages),scope=scopeFrom(cleaned,document),editorial=readEditorial(cleaned,analysis.findings);
    const units=[],clusters=[],contextIds=[],assigned=new Set(),summaryPages=new Set(editorial.pages);
    const limits=editorial.limits.map(l=>l.text).join(' ');
    const source=(ref,id)=>({documentId:document.id,name:document.name,page:ref.page,section:ref.section,block:id,lines:ref.lines,excerpt:ref.excerpt});
    const makeUnit=(id,text,ref,type,extra={})=>({id,text,type,...context(scope,text),confidence:type==='Hipótesis'?'Baja':'Media',confidenceWhy:'Afirmación documental; no implica validación de eficacia.',source:source(ref,id),status:'pending',semanticRole:'finding',contextTags:[],originalFindingIds:ref.originalFindingIds||[],...extra});
    editorial.anchors.forEach((anchor,i)=>{
      const id=`${document.id}-AUTHOR-P${anchor.source.page}-${i+1}`,unit=makeUnit(id,`${anchor.title}. ${anchor.synthesis}`,anchor.source,'Insight del autor',{currentState:anchor.currentState,uxReading:anchor.uxReading,authorDecision:anchor.authorDecision,validation:{status:'No demostrada',limits:editorial.limits},derivedFromTable:anchor.source.section.includes('tabla')});units.push(unit);
      clusters.push({id:`author-p${anchor.source.page}-${i+1}`,kind:'author',displayTitle:anchor.title,displaySynthesis:anchor.synthesis,nuance:[anchor.currentState?.description?`Estado actual: ${anchor.currentState.description}. Lectura UX: ${anchor.uxReading}.`:'',anchor.authorDecision,limits].filter(Boolean).join(' '),unitIds:[id],supportingUnitIds:[],currentState:anchor.currentState,uxReading:anchor.uxReading,authorDecision:anchor.authorDecision,source:anchor.source});
    });
    editorial.questions.forEach((question,i)=>{
      const id=`${document.id}-QUESTION-P${question.source.page}-${i+1}`;units.push(makeUnit(id,question.text,question.source,'Hipótesis'));
      clusters.push({id:`question-p${question.source.page}-${i+1}`,kind:'question',displayTitle:question.text,displaySynthesis:question.text,nuance:limits,unitIds:[id],supportingUnitIds:[],decisionDetails:{question:question.text},source:question.source});
    });
    const bodyUnits=[];
    for(const finding of analysis.findings){
      const page=cleaned.find(p=>p.page===Number(finding.source.page)),body=page?.lines.map(l=>l.text).join(' ')||'';
      const n=norm(finding.text);
      const inventory=/etiqueta/i.test(page?.text||'')&&/nivel/i.test(page?.text||'');
      const cover=Number(finding.source.page)===1&&!/[.!?]/.test(finding.text);
      const excludedContext=scope.excluded.filter(s=>s.split(/\s+/).length<3).some(s=>n.includes(norm(s)));
      const foreignComponent=scope.component==='Header'&&/\b(el buscador|el calendario|cta buscar vuelos)\b/.test(n)&&! /\bheader\b/.test(n);
      if(summaryPages.has(Number(finding.source.page))||scope.sourcePages.includes(Number(finding.source.page))||inventory||cover||excludedContext||foreignComponent||/\bobjetivo\b|enfoque de trabajo|que se analizara/.test(norm(body))||/\[[^\]]+\]/.test(finding.text)||finding.text.length<45){contextIds.push(finding.id);continue;}
      const type=/aplicado actualmente|implementado actualmente/.test(n)?'Hecho':/\?$/.test(n)?'Hipótesis':/\b(parece|puede|podria|no siempre|conviene|deberia|se mezclan)\b/.test(n)?'Inferencia':finding.type;
      bodyUnits.push({...finding,...context(scope,finding.text),type,semanticRole:'finding',contextTags:[],originalFindingIds:[finding.id],confidence:['Hipótesis','Oportunidad'].includes(type)?'Baja':'Media',currentState:/aplicado actualmente/.test(n)?{kind:'Hecho',description:'Aplicado actualmente'}:undefined,validation:{status:'No demostrada',limits:editorial.limits}});
    }
    const author=clusters.filter(c=>c.kind==='author'),frequencies=new Map();
    author.forEach(c=>tokens(`${c.displayTitle} ${c.displaySynthesis}`).forEach(t=>frequencies.set(t,(frequencies.get(t)||0)+1)));
    for(const unit of bodyUnits){
      const words=new Set(tokens(unit.text));
      const contradiction=author.find(c=>similarity(c.displayTitle,unit.text)>.8&&/\b(no|nunca)\b/.test(norm(c.displayTitle))!==/\b(no|nunca)\b/.test(norm(unit.text)));
      if(contradiction){contradiction.possibleContradictions=[...(contradiction.possibleContradictions||[]),unit.id];contradiction.unitIds.push(unit.id);assigned.add(unit.id);units.push(unit);continue;}
      const ranked=author.map(c=>{
        const keys=tokens(`${c.displayTitle} ${c.displaySynthesis}`),shared=keys.filter(t=>words.has(t));
        const weight=t=>[...broad].some(b=>stem(b)===t)?0.1:1/(frequencies.get(t)||1);
        const distinct=shared.filter(t=>weight(t)>=.5).length;
        const deviceConflict=/mobile/i.test(c.displayTitle)&&!/mobile|movil/i.test(unit.text);
        const score=shared.reduce((sum,t)=>sum+weight(t),0)/Math.max(1,keys.reduce((sum,t)=>sum+weight(t),0));
        return {cluster:c,score,eligible:distinct>=2&&!deviceConflict&&!['Experimento','Resultado','Evidencia externa','Hipótesis'].includes(unit.type)};
      }).filter(r=>r.eligible).sort((a,b)=>b.score-a.score);
      const best=ranked[0];
      if(best&&best.score>=.2&&best.score-(ranked[1]?.score||0)>=.04){best.cluster.unitIds.push(unit.id);best.cluster.supportingUnitIds.push(unit.id);assigned.add(unit.id);}
      units.push(unit);
    }
    // Uncertain matches remain separate, traceable evidence; never forced into a seed.
    const unassignedEvidence=bodyUnits.filter(u=>!assigned.has(u.id)).map(u=>({unitId:u.id,reason:'Sin correspondencia inequívoca con la síntesis; conservado para contraste, sin reforzar ningún cluster.'}));
    for(const unit of bodyUnits.filter(u=>!assigned.has(u.id)&&!author.length)){
      clusters.push({id:`body-${unit.id}`,kind:'body',displayTitle:unit.text.split(/(?<=[.!?])\s+/)[0],displaySynthesis:unit.text,nuance:limits,unitIds:[unit.id],supportingUnitIds:[],source:unit.source});
    }
    for(const cluster of clusters){
      const proposal=compareKnowledge(cluster,scope,kb);Object.assign(cluster,proposal);
      cluster.confidence=cluster.kind==='question'||cluster.kind==='author'&&!cluster.supportingUnitIds.length?'Baja':'Media';
      if(cluster.possibleContradictions?.length){cluster.confidence='Baja';cluster.nuance=`Posible contradicción entre la síntesis y el cuerpo; requiere revisión humana. ${cluster.nuance}`;}
      cluster.validation={status:'No demostrada',limits:editorial.limits};
      cluster.editorialContext={context:scope.included.join(' · '),limits,notDemonstrated:limits};
      if(cluster.kind==='author'&&!cluster.supportingUnitIds.length)cluster.nuance=`No se ha identificado soporte inequívoco en el cuerpo; requiere contraste humano. ${cluster.nuance}`;
    }
    const clusteredIds=new Set(clusters.flatMap(c=>c.unitIds)),contextEvidence=units.filter(u=>!clusteredIds.has(u.id));
    contextIds.push(...contextEvidence.flatMap(u=>u.originalFindingIds||[]));
    analysis.documentEditorial={version,scope,synthesis:editorial,units:units.filter(u=>clusteredIds.has(u.id)),clusters,contextIds:unique(contextIds),contextEvidence,unassignedEvidence};
    analysis.relations=clusters.map(c=>({id:`R-${c.id}`,clusterId:c.id,findingIds:c.unitIds,learningId:c.learningId,decision:c.decision,suggestion:c.decision,status:'pending',candidates:c.candidates}));
    analysis.metadata={...analysis.metadata,initiative:scope.component||document.initiative||'No especificado',products:scope.products,screens:scope.screens,components:[scope.component].filter(Boolean),devices:scope.devices,scope};
    // The editorial builders intentionally combine the same source material in
    // several views. Close that graph at the model boundary so persistence owns
    // a complete data tree: repeated source/scope values are copied, while a
    // genuine parent cycle or runtime object still fails loudly.
    const persistibleAnalysis=normalizeDataTree(analysis);
    const treeIssues=inspectDataTree(persistibleAnalysis);
    if(treeIssues.total)throw new Error(`El análisis no es un árbol persistible: ${JSON.stringify(treeIssues)}`);
    return persistibleAnalysis;
  }
  function interpretation(analysis){
    const model=analysis.documentEditorial,units=model.units,representedOriginalIds=unique(units.filter(u=>u.derivedFromTable).flatMap(u=>u.originalFindingIds));
    const originalRecords=analysis.findings.map((f,i)=>({...f,...context(model.scope,f.text),originalFinding:f,originalIndex:i+1,semanticRole:model.contextIds.includes(f.id)?'context':'finding',contextTags:[],type:f.type}));
    const traceComplete=units.every(u=>u.source.page&&u.source.documentId&&(u.originalFindingIds.length||u.source.excerpt)&&(u.originalFindingIds||[]).every(id=>analysis.findings.some(f=>f.id===id)));
    return {version:model.version,originalRecords,units,tableRows:units.filter(u=>u.derivedFromTable),validOriginals:originalRecords.filter(r=>r.semanticRole==='finding').length,contextRecords:model.contextIds.length,typeCounts:units.reduce((counts,u)=>(counts[u.type]=(counts[u.type]||0)+1,counts),{}),tableDedup:{representedOriginalIds,doubleCountedOriginalIds:units.filter(u=>representedOriginalIds.includes(u.id)).map(u=>u.id),traceComplete},documentScope:model.scope,editorial:model.synthesis};
  }
  function clusters(analysis,kb){
    const model=analysis.documentEditorial;
    return model.clusters.map(c=>{
      const findings=model.units.filter(u=>c.unitIds.includes(u.id));
      return {...c,name:c.displayTitle,synthesis:c.displaySynthesis,findings,pages:unique(findings.map(f=>f.source.page)),devices:unique(findings.map(f=>f.device)),types:unique(findings.map(f=>f.type)),contextTags:[],learning:kb.find(k=>k.id===c.learningId)||null,hasLowConfidence:c.confidence==='Baja',hasContradiction:Boolean(c.possibleContradictions?.length),needsDecision:c.decision!=='Mantener solo como evidencia'||c.confidence==='Baja',reviewStatus:'pending'};
    });
  }
  return {prepare,interpretation,clusters,readEditorial,pagesWithoutFurniture,scopeFrom,inspectDataTree};
})();
