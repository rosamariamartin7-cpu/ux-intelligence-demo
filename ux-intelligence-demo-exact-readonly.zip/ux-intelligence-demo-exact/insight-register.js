// Optional editorial layer attached to one logical document.
// The binary workbook remains in IndexedDB; this module only returns a
// serializable, auditable representation of the curated rows.
var UXInsightRegister = (() => {
  const version='insight-register-2';
  const clean=value=>String(value??'').replace(/\s+/g,' ').trim();
  const norm=value=>clean(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const clone=value=>JSON.parse(JSON.stringify(value));
  const fields={
    product:['producto'],funnel:['funnel'],minifunnel:['minifunnel'],screen:['pantalla'],component:['componente'],element:['elemento'],recordType:['tipo de registro','tipo registro','tipo'],
    insight:['insight / hallazgo','insight','hallazgo'],origin:['origen del hallazgo','origen'],evidence:['evidencia / dato clave','evidencia'],uxImplication:['implicacion ux','implicación ux','lectura ux','interpretacion ux','interpretación ux'],
    channelEnvironment:['canal / entorno','canal','entorno','dispositivo','device'],market:['mercado'],region:['region','región'],userState:['estado usuario','estado del usuario'],platformSystem:['sistema / plataforma','sistema','plataforma'],
    result:['resultado','estado / resultado'],implementation:['implementacion','implementación'],confidence:['confianza'],impactUx:['impacto ux','impacto de ux','impacto'],experimentPotential:['potencial de experimentacion','potencial de experimentación'],source:['fuente'],observations:['observaciones','observacion','observación'],
    recommendation:['recomendacion / oportunidad','recomendación / oportunidad','recomendacion','recomendación','oportunidad'],
    openQuestion:['pregunta abierta'],evidenceSource:['fuente de evidencia'],evidenceNature:['naturaleza de evidencia'],device:[],
    segment:['segmento / estado usuario','segmento'],commercialContext:['ruta / tarifa / contexto comercial','ruta','tarifa'],
    uxLine:['linea ux / agrupacion','línea ux / agrupación','linea ux','línea ux','agrupacion','agrupación'],priorRelation:['antecedente / relacion previa','antecedente / relación previa','antecedente','relacion previa','relación previa'],
    solutionState:['estado de la solucion','estado de la solución'],restriction:['restriccion / dependencia','restricción / dependencia','restriccion','restricción','dependencia'],
    kpi:['kpi / objetivo afectado','kpi','objetivo afectado'],contradiction:['evidencia contradictoria / matiz','evidencia contradictoria','matiz'],
    specificLimit:['limite especifico','límite específico'],notes:['notas']
  };
  const aliasIndex=new Map(Object.entries(fields).flatMap(([field,aliases])=>aliases.map(alias=>[norm(alias),field])));
  const documentProfileFields=['title','analysisType','date','initiative','primaryProduct','scope','outOfScope','devices','markets','segments','evidenceSources','generalRestrictions','documentLimits','reviewedByUx','associatedFiles'];
  const analysisTypes=['Auditoría UX','Test de usuarios','Análisis Quantum Metric','Test A/B / CRO','Benchmark','Desk research','Análisis heurístico','Análisis de datos','CSAT','Síntesis UX','Otro'];
  const recordTypes=['Insight','Hipótesis','Oportunidad','Restricción'];
  const resultStatuses=['Hallazgo interno','Evidencia externa','Resultado positivo','Resultado neutral','Resultado negativo','Resultado mixto','No aplica'];
  const experimentPotentials=['Alto','Medio','Bajo','No aplica'];
  const impactLevels=['Alto','Medio','Bajo'];
  const evidenceNatures=['Interna','Externa','Mixta'];
  const solutionStates=['Observada actualmente','Propuesta','Recomendada','Testada','Implementada','Implementación desconocida'];

  function documentProfile(document,overrides={}){
    const existing=document?.documentProfile||{};
    const sourceFile=document?.originalName||document?.fileMeta?.name||'';
    const profile={
      title:document?.name||'',analysisType:document?.type||'',date:document?.exactDate||'',initiative:document?.initiative||'',
      primaryProduct:document?.product||'',scope:existing.scope||document?.scope||'',outOfScope:existing.outOfScope||'',
      devices:existing.devices||document?.analysis?.metadata?.devices||[],markets:existing.markets||[],segments:existing.segments||[],
      evidenceSources:existing.evidenceSources||[],generalRestrictions:existing.generalRestrictions||[],documentLimits:existing.documentLimits||document?.analysis?.documentFirstV2?.publicationPlan?.documentLimits||[],
      reviewedByUx:Boolean(existing.reviewedByUx),associatedFiles:{source:sourceFile?{name:sourceFile,available:Boolean(document?.fileMeta),role:'source'}:null,insightRegister:document?.insightRegister?.file||null}
    };
    return {...profile,...clone(overrides),associatedFiles:{...profile.associatedFiles,...clone(overrides.associatedFiles||{})}};
  }

  function exportModel(){
    return {version:'knowledge-export-1',direction:'output',entities:['learnings','evidence','experiments','patterns','recommendations','openQuestions','restrictions','documents'],filters:['initiative','product','screen','component','element','device','market','region','segment','evidenceType','source','date','impactUx','implementationStatus'],traceability:['documentId','sourceRecordId','page','publicationHistory'],note:'Insight Register es input de un documento; esta exportación es output transversal de la Knowledge Base.'};
  }

  function parseDelimited(text,separator){
    const rows=[];let row=[],cell='',quoted=false;
    for(let index=0;index<text.length;index++){
      const char=text[index],next=text[index+1];
      if(char==='"'&&quoted&&next==='"'){cell+='"';index++;continue;}
      if(char==='"'){quoted=!quoted;continue;}
      if(char===separator&&!quoted){row.push(cell);cell='';continue;}
      if((char==='\n'||char==='\r')&&!quoted){if(char==='\r'&&next==='\n')index++;row.push(cell);rows.push(row);row=[];cell='';continue;}
      cell+=char;
    }
    row.push(cell);if(row.some(value=>clean(value)))rows.push(row);return rows;
  }

  async function unzipEntries(buffer){
    const bytes=new Uint8Array(buffer),view=new DataView(buffer);let end=-1;
    for(let index=Math.max(0,bytes.length-65557);index<=bytes.length-22;index++)if(view.getUint32(index,true)===0x06054b50)end=index;
    if(end<0)throw new Error('El archivo XLSX no contiene un directorio ZIP válido.');
    const count=view.getUint16(end+10,true),offset=view.getUint32(end+16,true),decoder=new TextDecoder(),entries=new Map();let cursor=offset;
    for(let index=0;index<count;index++){
      if(view.getUint32(cursor,true)!==0x02014b50)throw new Error('El directorio del XLSX está dañado.');
      const method=view.getUint16(cursor+10,true),size=view.getUint32(cursor+20,true),nameLength=view.getUint16(cursor+28,true),extraLength=view.getUint16(cursor+30,true),commentLength=view.getUint16(cursor+32,true),localOffset=view.getUint32(cursor+42,true);
      const name=decoder.decode(bytes.slice(cursor+46,cursor+46+nameLength)),localNameLength=view.getUint16(localOffset+26,true),localExtraLength=view.getUint16(localOffset+28,true),start=localOffset+30+localNameLength+localExtraLength;
      const compressed=bytes.slice(start,start+size);let data;
      if(method===0)data=compressed;
      else if(method===8){const stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate-raw'));data=new Uint8Array(await new Response(stream).arrayBuffer());}
      else throw new Error(`El XLSX usa un método de compresión no compatible (${method}).`);
      entries.set(name,data);cursor+=46+nameLength+extraLength+commentLength;
    }
    return entries;
  }

  const xmlText=(entries,path)=>{const data=entries.get(path);return data?new TextDecoder().decode(data):'';};
  const parseXml=text=>{const xml=new DOMParser().parseFromString(text,'application/xml');if(xml.querySelector('parsererror'))throw new Error('No se ha podido interpretar la estructura XML del XLSX.');return xml;};
  const cellColumn=reference=>{let value=0;for(const char of String(reference||'').match(/[A-Z]+/)?.[0]||'')value=value*26+char.charCodeAt(0)-64;return Math.max(0,value-1);};
  async function parseXlsx(buffer){
    const entries=await unzipEntries(buffer),workbook=parseXml(xmlText(entries,'xl/workbook.xml')),rels=parseXml(xmlText(entries,'xl/_rels/workbook.xml.rels'));
    const firstSheet=workbook.querySelector('sheet');if(!firstSheet)throw new Error('El XLSX no contiene hojas.');
    const relationshipId=firstSheet.getAttribute('r:id')||firstSheet.getAttributeNS('http://schemas.openxmlformats.org/officeDocument/2006/relationships','id');
    const relationship=[...rels.querySelectorAll('Relationship')].find(node=>node.getAttribute('Id')===relationshipId),target=relationship?.getAttribute('Target')||'worksheets/sheet1.xml';
    const sheetPath=target.startsWith('/')?target.slice(1):`xl/${target.replace(/^\.\//,'')}`.replace(/\/[^/]+\/\.\.\//g,'/');
    const sharedXml=xmlText(entries,'xl/sharedStrings.xml'),shared=sharedXml?[...parseXml(sharedXml).querySelectorAll('si')].map(node=>[...node.querySelectorAll('t')].map(text=>text.textContent||'').join('')):[];
    const sheet=parseXml(xmlText(entries,sheetPath)),matrix=[];
    for(const rowNode of sheet.querySelectorAll('sheetData > row')){
      const row=[];for(const cell of rowNode.querySelectorAll('c')){
        const column=cellColumn(cell.getAttribute('r')),type=cell.getAttribute('t'),raw=cell.querySelector('v')?.textContent??'',inline=[...cell.querySelectorAll('is t')].map(node=>node.textContent||'').join('');
        row[column]=type==='s'?shared[Number(raw)]??'':type==='inlineStr'?inline:raw;
      }matrix.push(row.map(value=>value??''));
    }
    return {matrix,sheetName:firstSheet.getAttribute('name')||'Hoja 1'};
  }

  function buildRegister(matrix,fileMeta={}){
    if(!Array.isArray(matrix)||!matrix.length)throw new Error('El Insight Register está vacío.');
    const candidates=matrix.map((row,index)=>{const headers=(row||[]).map(clean),mapped=headers.map(header=>aliasIndex.get(norm(header))||null);return {index,headers,mapped,recognized:mapped.filter(Boolean).length};});
    const best=candidates.sort((a,b)=>b.recognized-a.recognized||a.index-b.index)[0];
    if(!best||!best.recognized)throw new Error('No se ha reconocido ninguna fila de cabeceras del modelo de Insight Register.');
    const headerIndex=best.index,headers=best.headers,mapped=best.mapped,recognized=best.recognized;
    const rows=[];
    matrix.slice(headerIndex+1).forEach((sourceRow,index)=>{
      if(!sourceRow.some(value=>clean(value)))return;const row={id:`IR-${index+1}`,sourceRow:headerIndex+index+2};
      mapped.forEach((field,column)=>{if(field)row[field]=clean(sourceRow[column]);});
      const extraFields={};headers.forEach((header,column)=>{if(header&&!mapped[column]&&clean(sourceRow[column]))extraFields[header]=clean(sourceRow[column]);});
      if(Object.keys(extraFields).length)row.extraFields=extraFields;rows.push(row);
    });
    return {version,status:'attached-primary-source',reviewedByUx:false,file:{name:fileMeta.name||'',size:fileMeta.size||0,type:fileMeta.type||'',lastModified:fileMeta.lastModified||0,role:'insight-register'},headers,recognizedFields:[...new Set(mapped.filter(Boolean))],rows,history:[],attachedAt:new Date().toISOString(),analysisVersion:null};
  }

  async function parseFile(file){
    const name=String(file?.name||''),extension=name.split('.').pop().toLowerCase();let matrix=[],sheetName='';
    if(['csv','tsv'].includes(extension)){const text=await file.text(),separator=extension==='tsv'?'\t':(text.split('\n')[0].split(';').length>text.split('\n')[0].split(',').length?';':',');matrix=parseDelimited(text,separator);sheetName='Datos';}
    else if(extension==='xlsx'){const parsed=await parseXlsx(await file.arrayBuffer());matrix=parsed.matrix;sheetName=parsed.sheetName;}
    else throw new Error('Formato no compatible. Utiliza XLSX, CSV o TSV.');
    const register=buildRegister(matrix,{name:file.name,size:file.size,type:file.type,lastModified:file.lastModified});register.sheetName=sheetName;return register;
  }

  function validate(register){
    const errors=[];if(register?.version!==version)errors.push('Versión de Insight Register no reconocida.');if(!Array.isArray(register?.rows))errors.push('Las filas curadas no son válidas.');
    // Modelo editorial vigente: los Excel revisados por fase son la fuente primaria.
    // Funnel, Minifunnel y otros metadatos pueden incorporarse cuando apliquen, pero no se inventan si el Excel no los contiene.
    const required=['product','screen','component','element','recordType','insight','evidence','uxImplication','recommendation','openQuestion','origin','market','uxLine','observations'];
    const recognized=new Set(register?.recognizedFields||[]);required.filter(field=>!recognized.has(field)).forEach(field=>errors.push(`Falta una columna del Excel revisado: ${field}.`));
    if(!recognized.has('channelEnvironment')&&!recognized.has('device'))errors.push('Falta una columna del Excel revisado: dispositivo / canal.');
    const ids=new Set();for(const row of register?.rows||[]){if(ids.has(row.id))errors.push(`ID de fila duplicado: ${row.id}`);ids.add(row.id);if(!Object.values(row).some(value=>typeof value==='string'&&clean(value)))errors.push(`Fila ${row.sourceRow||row.id} vacía.`);}
    return {valid:!errors.length,errors};
  }

  return {version,fields:clone(fields),documentProfileFields:[...documentProfileFields],analysisTypes:[...analysisTypes],recordTypes:[...recordTypes],resultStatuses:[...resultStatuses],experimentPotentials:[...experimentPotentials],impactLevels:[...impactLevels],evidenceNatures:[...evidenceNatures],solutionStates:[...solutionStates],documentProfile,exportModel,parseFile,buildRegister,validate};
})();
