// Document-first V2 transformer.
// New ingests use the conservative generic path. Existing documents stay on V1
// unless an explicit, reviewed migration artifact is attached to that document.
var UXDocumentAnalysisV2 = (() => {
  const version='document-first-2';
  const clean=value=>String(value||'').replace(/\s+/g,' ').trim();
  const norm=value=>clean(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  const unique=values=>[...new Set((values||[]).filter(value=>value!==undefined&&value!==null&&value!==''))];
  const clone=value=>JSON.parse(JSON.stringify(value));
  const pageOf=finding=>Number(finding?.source?.page||0);
  const findingId=finding=>String(finding?.id||'');
  const textOf=value=>clean([value?.displayTitle,value?.displaySynthesis,value?.text].filter(Boolean).join(' '));

  const groupDefinitions=[
    {
      id:'reservation-access',name:'Acceso a gestionar la reserva',object:'Gestionar reserva / Mis reservas',criterion:'Un único acceso reconocible evita dividir la atención entre entradas equivalentes.',
      pageTerms:/gestionar reserva|mis reservas|cambiar vuelo|anadir extras/,titleTerms:/gestionar reserva|mis reservas|duplicidad de accesos|unico acceso/,context:'Header · gestión del viaje',
      learning:{title:'La gestión de la reserva debe concentrarse en un acceso único y reconocible',proposal:'Reforzar o ampliar conocimiento existente',reason:'Existe conocimiento sobre el peso del autoservicio, pero este documento añade evidencia específica sobre la duplicidad de accesos.'},
      recommendation:'Mantener un único acceso claro y fuerte a Gestionar reserva o Mis reservas.',relations:[['L-02','Amplía con evidencia sobre duplicidad'],['E-05','Refuerza la evidencia histórica de arquitectura y naming']]
    },
    {
      id:'checkin-direct',name:'Acceso directo a Check-in',object:'Check-in',criterion:'Una tarea urgente y diferenciada debe conservar una entrada directa y visible.',
      pageTerms:/check-in|tarjeta de embarque/,titleTerms:/check-in|tarjeta de embarque|urgencia propia/,context:'Header · gestión del vuelo',
      learning:{title:'Check-in debe mantener un acceso directo y visible como tarea operativa diferenciada',proposal:'Crear nuevo learning',reason:'El conocimiento existente es contextual, pero no formula de manera explícita el criterio de acceso directo para Check-in.'},
      recommendation:'Mantener Check-in como acceso directo, sin esconderlo dentro de Gestionar reserva.',relations:[['E-05','Refuerza la evidencia histórica del Test de usuarios'],['P-02','Aporta contexto para comprobar el patrón por dispositivo']]
    },
    {
      id:'preflight-naming',name:'Naming de Antes de volar',object:'Categoría “Antes de volar”',criterion:'El nombre debe permitir anticipar contenidos críticos antes de navegar.',
      pageTerms:/antes de volar|visados|pasaportes|documentacion/,titleTerms:/antes de volar|etiqueta|naming|nombre funciona mejor/,context:'Header · información previa al viaje',
      learning:{title:'El naming de las categorías del Header debe anticipar el contenido que agrupan',proposal:'Reforzar learning existente',reason:'La evidencia converge directamente con L-10 y añade datos de encontrabilidad para “Antes de volar”.'},
      recommendation:'Revisar el naming; las alternativas siguen pendientes de validación.',relations:[['L-10','Refuerzo directo con evidencia de usuarios']]
    },
    {
      id:'baggage-findability',name:'Encontrabilidad de equipaje',object:'Equipaje de mano, facturado y especial',criterion:'La visibilidad debe corresponderse con la relevancia operativa y la frecuencia de consulta.',
      pageTerms:/equipaje de mano|equipaje facturado|equipaje especial|declaracion de valor/,titleTerms:/equipaje|visibilidad de estos contenidos/,context:'Header · preparación del viaje',
      learning:{title:'Los contenidos de equipaje deben ser visibles y predecibles por su alta relevancia operativa',proposal:'Crear nuevo learning',reason:'L-11 es una base transversal, pero no conserva el criterio específico ni la fuerza de la evidencia sobre equipaje.'},
      recommendation:'Dar mayor visibilidad al equipaje y revisar su ubicación y naming.',relations:[['L-11','Especializa el criterio general de agrupación']]
    },
    {
      id:'assistance-findability',name:'Encontrabilidad de asistencia y necesidades especiales',object:'Mascotas, menores, embarazo y asistencia especial',criterion:'Necesidades especiales de alto valor no deben quedar ocultas bajo categorías genéricas.',
      pageTerms:/mascota|menores|embaraz|asistencia especial|pasajeros/,titleTerms:/asistencia|necesidades especiales|baja encontrabilidad|visibilidad de estos contenidos/,context:'Header · preparación del viaje',
      learning:{title:'Las necesidades especiales deben agruparse bajo una categoría explícita y fácil de anticipar',proposal:'Crear nuevo learning',reason:'Comparte principios con L-11, pero el objeto, el contexto y la conclusión son específicos y no deben fundirse con equipaje.'},
      recommendation:'Crear una agrupación reconocible de asistencia o necesidades especiales y enlazarla desde Ayuda.',relations:[['L-11','Especializa el criterio general de agrupación']]
    },
    {
      id:'help-rescue',name:'Ayuda como vía de rescate',object:'Ayuda / Contacto',criterion:'El uso de Ayuda para tareas ajenas señala problemas de naming o arquitectura en otras áreas.',
      pageTerms:/ayuda|contacto|via de rescate|pago rechazado|error de pago/,titleTerms:/ayuda|via de rescate|desvios/,context:'Header · soporte y recuperación',
      learning:{title:'Ayuda no debe compensar problemas de naming y agrupación del resto del Header',proposal:'Reforzar o ampliar knowledge existente',reason:'La evidencia amplía L-11 mostrando una consecuencia observable de una arquitectura poco predecible.'},
      recommendation:'Simplificar Ayuda y revisar a la vez la arquitectura que provoca esos desvíos.',relations:[['L-11','Añade el uso de Ayuda como señal de fallo de arquitectura']]
    },
    {
      id:'operational-priority',name:'Prioridad operativa del primer nivel',object:'Jerarquía global del Header',criterion:'El primer nivel debe priorizar necesidades inmediatas del viaje frente a contenido corporativo o secundario.',
      pageTerms:/experiencia air europa|contenido comercial|flota|alianzas|corporativ|necesidades operativas|primer nivel|arquitectura/,titleTerms:/experiencia air europa|operativo|corporativo|comercial|primer nivel|priorizar reserva|necesidades inmediatas|redisenar solo la estetica/,context:'Header · jerarquía global',
      learning:{title:'El primer nivel del Header debe priorizar tareas operativas del viaje',proposal:'Reforzar o ampliar knowledge existente',reason:'Converge con L-09 y L-11, pero añade una prioridad explícita y límites sobre el contenido comercial.'},
      recommendation:'Priorizar reserva, Check-in, equipaje, documentación, ayuda, asistencia y cuenta; revisar por separado el valor comercial.',relations:[['L-09','Amplía la lectura de simplicidad visible'],['L-11','Refuerza la jerarquía basada en tareas']]
    },
    {
      id:'account-loyalty',name:'Integración de SUMA y Mi cuenta',object:'SUMA / Mi cuenta',criterion:'La ubicación debe responder al modelo mental del usuario sin ignorar el valor comercial del programa.',
      pageTerms:/suma|mi cuenta|puntos|programa de fidelizacion/,titleTerms:/suma|mi cuenta/,context:'Header · cuenta y fidelización',
      learning:null,recommendation:'Valorar la integración de SUMA en Mi cuenta y conservar la decisión como hipótesis hasta validarla.',relations:[]
    },
    {
      id:'navigation-presentation',name:'Presentación de la navegación',object:'Patrones visuales de navegación',criterion:'La presentación puede mejorar el escaneo, pero el benchmark no demuestra su eficacia en Air Europa.',
      pageTerms:/benchmark|iconos|menu desplegable|mega menu|cards|columnas/,titleTerms:/desktop y mobile|arquitectura mejora realmente/,context:'Header · presentación y responsive',
      learning:null,recommendation:'Explorar una presentación más escaneable y específica por dispositivo, manteniéndola como recomendación pendiente de validación.',relations:[['P-02','Referencia contextual para una navegación específica por device']]
    }
  ];

  function knowledgeIndex(knowledge){
    const collections=['learningState','evidenceState','patternState','knowledgeUnits','openQuestionItems'];
    return new Map(collections.flatMap(key=>(knowledge?.[key]||[]).map(item=>[item.id,{...item,collection:key}])));
  }

  function isSynthesisPage(text){return /resumen (?:de )?insights|\n\s*conclusiones\s*\n|preguntas abiertas|que no demuestra/i.test(text);}
  function isContextPage(page,text){return page<=3||/metodologia|objetivo del estudio|enfoque de trabajo/i.test(text);}
  function score(definition,text){
    const n=norm(text);let value=0;
    if(definition.pageTerms.test(n))value+=3;
    if(definition.titleTerms.test(n))value+=2;
    return value;
  }
  function bestGroups(text,minimum=2){
    const ranked=groupDefinitions.map(definition=>({definition,score:score(definition,text)})).filter(item=>item.score>=minimum).sort((a,b)=>b.score-a.score);
    if(!ranked.length)return [];
    const best=ranked[0].score;
    return ranked.filter(item=>item.score>=best-1).map(item=>item.definition.id);
  }
  function semanticRole(finding){
    const text=norm(finding.text);
    if(/\?$/.test(text))return 'question';
    if(/^(mantener|revisar|priorizar|dar mayor|simplificar|agrupar|crear|valorar|explorar)\b/.test(text)||/\bdeberia\b/.test(text))return 'recommendation';
    if(/\b(parece|indica|sugiere|compensa|el problema|eso demuestra|urgencia propia|no funciona como nombre|no orienta|no tiene suficiente aroma|estan escondidos|no todo tiene el mismo valor|no se corresponde|reconoce como)\b/.test(text))return 'interpretation';
    return /\d+[%/,]|\busuarios?\b|\bresultado\b/.test(text)?'evidence':'observation';
  }

  function classifyOriginalEvidence(analysis){
    const extracted=analysis.extractedPages||[],lineFrequency=new Map();
    extracted.forEach(page=>unique(String(page.text||'').split('\n').map(clean).filter(Boolean)).forEach(line=>lineFrequency.set(line,(lineFrequency.get(line)||0)+1)));
    const pages=new Map(extracted.map(page=>{
      const bodyLines=String(page.text||'').split('\n').map(clean).filter(line=>line&&(lineFrequency.get(line)||0)<Math.max(4,extracted.length*.45));
      const heading=bodyLines.find(line=>/^\d+\./.test(line))||bodyLines.find(line=>!/^(principales datos|area cx)/i.test(line))||'';
      const synthesis=bodyLines.some(line=>/^(conclusiones|resumen (?:de )?insights|que no demuestra este estudio|preguntas abiertas)$/i.test(line));
      return [Number(page.page),{full:clean(page.text),body:bodyLines.join(' '),heading,synthesis}];
    }));
    const assigned=new Map(groupDefinitions.map(definition=>[definition.id,[]])),pageRoles=[];
    pages.forEach((pageText,page)=>pageRoles.push({page,role:isContextPage(page,pageText.full)?'contexto/metodología':pageText.synthesis?(page===16?'preguntas y límites':'síntesis editorial'):'cuerpo de evidencia'}));
    const preserved=[];
    for(const finding of analysis.findings||[]){
      const page=pageOf(finding),pageText=pages.get(page)||{full:'',body:''},semantic=semanticRole(finding);
      if(isContextPage(page,pageText.full)){preserved.push({findingId:findingId(finding),role:'document-context',page});continue;}
      if(pageText.synthesis||isSynthesisPage(`\n${pageText.body}\n`)){preserved.push({findingId:findingId(finding),role:'editorial-synthesis',page});continue;}
      // The page establishes the primary object. A mention of Ayuda inside a page
      // about “Antes de volar”, for example, is evidence about that category and
      // is not duplicated into a second group merely because the term appears.
      const groups=(bestGroups(pageText.heading,1).length?bestGroups(pageText.heading,1):bestGroups(pageText.body)).slice(0,1);
      if(!groups.length){preserved.push({findingId:findingId(finding),role:'unassigned-evidence',page});continue;}
      groups.forEach(groupId=>assigned.get(groupId).push({findingId:findingId(finding),page,role:semantic,text:clean(finding.text)}));
    }
    return {assigned,preserved,pageRoles:pageRoles.sort((a,b)=>a.page-b.page)};
  }

  function manualSnapshot(cluster,review){
    return {decision:review?.decision||cluster.decision||'',status:review?.status||'pending',learningId:review?.learningId||cluster.learningId||'',editorialTitle:review?.editorialTitle||'',editorialSynthesis:review?.editorialSynthesis||''};
  }
  function mapV1Cluster(cluster,review){
    const sourceText=textOf(cluster),manualText=clean([review?.editorialTitle,review?.editorialSynthesis].filter(Boolean).join(' '));
    const sourceGroups=bestGroups(sourceText),manualGroups=manualText?bestGroups(manualText):[];
    let groups=manualGroups.length?manualGroups:sourceGroups;
    if(cluster.kind==='question')groups=bestGroups(sourceText,1);
    if(!groups.length&&cluster.kind==='question')groups=['operational-priority'];
    if(!groups.length)groups=['operational-priority'];
    const sourceMixed=sourceGroups.length>1||manualGroups.length&&sourceGroups.some(id=>!manualGroups.includes(id));
    const destination=cluster.kind==='question'?'Pregunta abierta':groups.map(id=>{
      const definition=groupDefinitions.find(item=>item.id===id);
      return definition?.learning?'Candidato a learning':'Recomendación / evidencia';
    }).join(' + ');
    return {groupIds:unique(groups),sourceGroupIds:unique(sourceGroups),destination,sourceMixed,requiresHumanReview:sourceMixed||groups.length>1};
  }

  function explicitDocumentLimits(analysis){
    const limits=analysis.documentEditorial?.synthesis?.limits||[];
    return unique(limits.map(item=>clean(item.text||item)).filter(Boolean));
  }
  function questionsFromV1(clusters,review){
    return clusters.filter(cluster=>cluster.kind==='question').map(cluster=>({
      id:`V2-Q-${cluster.id}`,text:clean(cluster.displayTitle),relatedGroupIds:mapV1Cluster(cluster,review?.[cluster.id]).groupIds,
      source:{v1ProposalId:cluster.id,page:Number(cluster.source?.page||0)},requiresHumanReview:false
    }));
  }
  function groupSpecificLimits(groupId,documentLimits){
    const common={
      'reservation-access':['No demuestra que una arquitectura concreta sea la solución definitiva ni su impacto en conversión.'],
      'checkin-direct':['No demuestra qué presentación concreta funciona mejor por dispositivo.'],
      'preflight-naming':['No valida qué nombre concreto funciona mejor para sustituir “Antes de volar”.'],
      'baggage-findability':['No valida la ubicación final ni que todos los contenidos de equipaje deban compartir el mismo nivel.'],
      'assistance-findability':['No valida el naming ni la agrupación final de mascotas, menores y asistencia especial.'],
      'help-rescue':['El uso de Ayuda sugiere un problema de arquitectura, pero no identifica por sí solo una única causa.'],
      'operational-priority':['No demuestra que todo el contenido comercial deba desaparecer del Header.'],
      'account-loyalty':['No resuelve el equilibrio entre el modelo mental del usuario y el valor comercial de SUMA.'],
      'navigation-presentation':['El benchmark aporta patrones externos, pero no demuestra que produzcan el mismo resultado en Air Europa.']
    };
    return (common[groupId]||[]).filter(limit=>!documentLimits.some(documentLimit=>norm(documentLimit)===norm(limit)));
  }

  function transform({analysis,document,knowledge,v1Clusters,manualDecisions,canonicalContext={}}){
    const inputAnalysis=clone(analysis),clusters=clone(v1Clusters||analysis.documentEditorial?.clusters||[]),review=clone(manualDecisions||analysis.clusterReview||{});
    const originalFingerprint=JSON.stringify({analysis,document,knowledge,v1Clusters,manualDecisions});
    const kb=knowledgeIndex(knowledge),classified=classifyOriginalEvidence(inputAnalysis),documentLimits=explicitDocumentLimits(inputAnalysis);
    const correspondence=clusters.map(cluster=>{
      const mapping=mapV1Cluster(cluster,review[cluster.id]);
      return {v1ProposalId:cluster.id,v1Title:cluster.displayTitle,v2GroupIds:mapping.groupIds,v2SemanticDestination:mapping.destination,humanDecision:manualSnapshot(cluster,review[cluster.id]),mappingStatus:mapping.sourceMixed?'requires-review':mapping.groupIds.length===1?'exact':'split',requiresHumanReview:mapping.requiresHumanReview,note:mapping.sourceMixed?'La fuente V1 mezcla más de un objeto; la decisión humana se conserva, pero no se transfiere automáticamente a otra idea.':''};
    });
    const v1ByGroup=new Map(groupDefinitions.map(definition=>[definition.id,correspondence.filter(row=>row.v2GroupIds.includes(definition.id))]));
    const groups=groupDefinitions.map(definition=>{
      const evidence=classified.assigned.get(definition.id)||[],rows=v1ByGroup.get(definition.id)||[];
      const roles=Object.fromEntries(['evidence','observation','interpretation','recommendation'].map(role=>[role,evidence.filter(item=>item.role===role)]));
      const related=definition.relations.map(([id,nature])=>kb.has(id)?{id,nature,title:kb.get(id).title||kb.get(id).name||kb.get(id).know||id,collection:kb.get(id).collection}:null).filter(Boolean);
      const mixedRows=rows.filter(row=>row.requiresHumanReview);
      const isNew=definition.learning?.proposal==='Crear nuevo learning';
      return {
        id:definition.id,name:definition.name,object:definition.object,criterion:definition.criterion,context:{...canonicalContext,journey:definition.context},
        evidenceRefs:unique(evidence.map(item=>item.findingId)),pages:unique(evidence.map(item=>item.page)).sort((a,b)=>a-b),evidenceByRole:roles,
        interpretation:roles.interpretation.map(item=>item.text),recommendation:definition.recommendation,
        learningCandidate:definition.learning?{formulation:definition.learning.title,proposal:definition.learning.proposal,reason:definition.learning.reason,supportingEvidenceRefs:unique(evidence.filter(item=>['evidence','observation'].includes(item.role)).map(item=>item.findingId)),interpretationRefs:unique(roles.interpretation.map(item=>item.findingId)),relatedRecommendation:definition.recommendation,context:{...canonicalContext,journey:definition.context},limits:groupSpecificLimits(definition.id,documentLimits),relatedKnowledge:related}:null,
        relatedKnowledge:related,specificLimits:groupSpecificLimits(definition.id,documentLimits),v1ProposalIds:rows.map(row=>row.v1ProposalId),
        requiresHumanReview:Boolean(mixedRows.length||isNew||!definition.learning),reviewReasons:unique([mixedRows.length?'V1 mezcló objetos o conclusiones que V2 separa.':'',isNew?'La creación de un learning nuevo requiere decisión humana.':'',!definition.learning?'No se propone learning automático: revisar recomendación, evidencia o pregunta.':''])
      };
    }).filter(group=>group.evidenceRefs.length||group.v1ProposalIds.length);
    const questions=questionsFromV1(clusters,review);
    const semanticStructure={
      documentSections:classified.pageRoles,
      rule:'La sección orienta la clasificación, pero el destino semántico se decide por contenido, objeto, contexto y criterio UX.',
      evidenceGroupRule:'Solo se agrupa cuando coinciden tema, objeto, contexto y conclusión o criterio UX; el número de grupos no responde a una cuota.'
    };
    const result={
      version,mode:'parallel-dry-run',activated:false,sourceDocument:{id:document.id,name:document.name,file:document.originalName,pages:inputAnalysis.pages,originalFindings:(inputAnalysis.findings||[]).length},
      semanticStructure,groups,learningCandidates:groups.filter(group=>group.learningCandidate).map(group=>({groupId:group.id,...group.learningCandidate})),
      recommendations:groups.map(group=>({groupId:group.id,text:group.recommendation,sourceEvidenceRefs:group.evidenceRefs})),openQuestions:questions,
      documentLimits,specificLimits:groups.map(group=>({groupId:group.id,limits:group.specificLimits})).filter(item=>item.limits.length),
      suggestedRelations:groups.flatMap(group=>group.relatedKnowledge.map(relation=>({groupId:group.id,...relation}))),
      requiresHumanReview:groups.filter(group=>group.requiresHumanReview).map(group=>({groupId:group.id,reasons:group.reviewReasons,v1ProposalIds:group.v1ProposalIds})),
      correspondence,traceability:{originalFindings:(inputAnalysis.findings||[]).map(finding=>findingId(finding)),preservedOutsideGroups:classified.preserved,orphanedV1Proposals:correspondence.filter(row=>!row.v2GroupIds.length).map(row=>row.v1ProposalId),orphanedHumanDecisions:correspondence.filter(row=>!row.humanDecision.decision).map(row=>row.v1ProposalId)},
      totals:{v1Proposals:clusters.length,v2Groups:groups.length,learningCandidates:groups.filter(group=>group.learningCandidate).length,recommendations:groups.length,openQuestions:questions.length,suggestedRelations:groups.reduce((sum,group)=>sum+group.relatedKnowledge.length,0),requiresHumanReview:groups.filter(group=>group.requiresHumanReview).length}
    };
    if(JSON.stringify({analysis,document,knowledge,v1Clusters,manualDecisions})!==originalFingerprint)throw new Error('document-first-2 modificó un input de la prueba en seco.');
    JSON.stringify(result);
    return result;
  }

  function genericSemanticDestination(cluster){
    const text=norm(textOf(cluster));
    if(cluster.kind==='question'||/\?$/.test(text))return 'Pregunta abierta';
    if(/\b(recomend|mantener|revisar|priorizar|simplificar|agrupar|crear|valorar|explorar)\b/.test(text))return 'Recomendación';
    return 'Evidencia / candidato editorial';
  }

  // V2 deliberately starts conservatively for an unseen document: it preserves
  // every structural proposal as a separate group and never invents a relation
  // from textual similarity. Human review can consolidate groups afterwards.
  function prepareNewIngest({analysis,document,knowledge,canonicalContext={}}){
    const prepared=clone(analysis),clusters=clone(prepared.documentEditorial?.clusters||[]),previousRelations=clone(prepared.relations||[]);
    const context={product:canonicalContext.product||document.product||'',screen:canonicalContext.screen||document.screen||'',component:canonicalContext.component||document.component||'',device:canonicalContext.device||'',market:canonicalContext.market||''};
    const groups=clusters.map(cluster=>{
      const destination=genericSemanticDestination(cluster),findingIds=unique((cluster.findings||[]).map(finding=>findingId(finding))),pages=unique((cluster.findings||[]).map(pageOf).filter(Boolean)).sort((a,b)=>a-b);
      return {id:`V2-${cluster.id}`,name:clean(cluster.displayTitle||cluster.title||cluster.name),object:clean(cluster.object||cluster.component||document.component||'Objeto pendiente de confirmar'),context,criterion:clean(cluster.displaySynthesis||cluster.synthesis||''),semanticDestination:destination,evidenceRefs:findingIds,pages,requiresHumanReview:true,reviewReasons:['Confirmar objeto, contexto y conclusión antes de consolidar o relacionar conocimiento.'],sourceV1ProposalIds:[cluster.id]};
    });
    const questions=groups.filter(group=>group.semanticDestination==='Pregunta abierta').map(group=>({id:`Q-${group.id}`,text:group.name,relatedGroupIds:[group.id],sourceEvidenceRefs:group.evidenceRefs,requiresHumanReview:true}));
    const recommendations=groups.filter(group=>group.semanticDestination==='Recomendación').map(group=>({id:`R-${group.id}`,groupId:group.id,text:group.name,sourceEvidenceRefs:group.evidenceRefs,requiresHumanReview:true}));
    const originalFindingIds=(prepared.findings||[]).map(findingId);
    prepared.documentFirst1Compatibility={version:'document-first-1',relations:previousRelations,clusterReview:clone(prepared.clusterReview||{}),preservedAt:new Date().toISOString()};
    prepared.relations=[];
    if(prepared.documentEditorial?.clusters)prepared.documentEditorial.clusters=prepared.documentEditorial.clusters.map(cluster=>({...cluster,learningId:'',learning:null,relation:null}));
    prepared.documentFirstV2={version,mode:'active-new-ingest',activated:true,migratedExplicitly:false,createdAt:new Date().toISOString(),sourceDocument:{id:document.id,name:document.name,file:document.originalName,pages:prepared.pages,originalFindings:originalFindingIds.length},semanticStructure:{rule:'La sección orienta, pero no determina la clasificación.',evidenceGroupRule:'Solo se consolidan unidades cuando comparten objeto, contexto y una misma conclusión o criterio UX. No existe una cuota de learnings.'},groups,recommendations,openQuestions:questions,documentLimits:explicitDocumentLimits(prepared),suggestedRelations:[],requiresHumanReview:groups.map(group=>({groupId:group.id,reasons:group.reviewReasons})),traceability:{originalFindings:originalFindingIds,sourceV1ProposalIds:clusters.map(cluster=>cluster.id),orphanedOriginalFindings:[],orphanedHumanDecisions:[]},totals:{v1Proposals:clusters.length,v2Groups:groups.length,learningCandidates:groups.filter(group=>group.semanticDestination==='Evidencia / candidato editorial').length,recommendations:recommendations.length,openQuestions:questions.length,suggestedRelations:0,requiresHumanReview:groups.length}};
    prepared.metadata={...(prepared.metadata||{}),analysisEngine:version};
    prepared.review={...(prepared.review||{}),engine:version,status:'Pendiente de revisión'};
    JSON.stringify(prepared);
    return prepared;
  }

  function prepareWithInsightRegister({analysis,document,register,canonicalContext={}}){
    if(!register?.rows?.length)throw new Error('El Insight Register no contiene filas curadas.');
    const prepared=clone(analysis),context={product:canonicalContext.product||document.product||'',screen:canonicalContext.screen||document.screen||'',component:canonicalContext.component||document.component||'',element:canonicalContext.element||document.element||''};
    const rows=clone(register.rows),groupIndex=new Map();
    rows.forEach(row=>{
      const rowContext={product:row.product||context.product,screen:row.screen||context.screen,component:row.component||context.component,element:row.element||context.element,device:row.device||'',market:row.market||'',segment:row.segment||''};
      const object=clean([row.element,row.component,row.uxLine].find(Boolean)||'Objeto pendiente de confirmar'),line=clean(row.uxLine||object),key=JSON.stringify([norm(line),norm(object),norm(rowContext.product),norm(rowContext.screen),norm(rowContext.component),norm(rowContext.element)]);
      if(!groupIndex.has(key))groupIndex.set(key,{id:`IR-G-${groupIndex.size+1}`,name:line,object,context:rowContext,rowIds:[],records:[],evidence:[],interpretations:[],recommendations:[],questions:[],restrictions:[],contradictions:[],specificLimits:[],priorRelations:[],requiresHumanReview:true,reviewReasons:[]});
      const group=groupIndex.get(key);group.rowIds.push(row.id);group.records.push(row);
      if(row.evidence)group.evidence.push(row.evidence);if(row.uxReading)group.interpretations.push(row.uxReading);if(row.recommendation)group.recommendations.push(row.recommendation);if(row.openQuestion)group.questions.push(row.openQuestion);if(row.restriction)group.restrictions.push(row.restriction);if(row.contradiction)group.contradictions.push(row.contradiction);if(row.specificLimit)group.specificLimits.push(row.specificLimit);if(row.priorRelation)group.priorRelations.push(row.priorRelation);
    });
    const groups=[...groupIndex.values()].map(group=>{
      group.evidence=unique(group.evidence);group.interpretations=unique(group.interpretations);group.recommendations=unique(group.recommendations);group.questions=unique(group.questions);group.restrictions=unique(group.restrictions);group.contradictions=unique(group.contradictions);group.specificLimits=unique(group.specificLimits);group.priorRelations=unique(group.priorRelations);
      if(group.records.some(row=>['Insight UX','Hipótesis','Inferencia','Oportunidad'].includes(row.recordType)))group.reviewReasons.push('Confirmar el destino semántico y si el criterio es reutilizable antes de crear o relacionar un learning.');
      if(group.priorRelations.length)group.reviewReasons.push('Validar manualmente las relaciones declaradas; no se reconstruyen por similitud textual.');
      if(group.contradictions.length)group.reviewReasons.push('Existe evidencia contradictoria o un matiz que requiere criterio humano.');
      if(!group.reviewReasons.length)group.reviewReasons.push('Confirmar la consolidación editorial antes de publicar conocimiento.');
      return group;
    });
    const originalFindingIds=(prepared.findings||[]).map(findingId);
    prepared.documentFirstV2={version,mode:'insight-register-primary',activated:true,migratedExplicitly:false,createdAt:new Date().toISOString(),sourceDocument:{id:document.id,name:document.name,file:document.originalName,pages:prepared.pages,originalFindings:originalFindingIds.length},editorialSource:{type:'insight-register',file:clone(register.file),rows:rows.length,reviewedByUx:Boolean(register.reviewedByUx),registerVersion:register.version},semanticStructure:{rule:'El Insight Register es la capa editorial prioritaria; el documento original conserva metodología, métricas, alcance, límites y trazabilidad.',evidenceGroupRule:'Las filas no equivalen a learnings. Solo se agrupan cuando comparten línea, objeto y contexto; toda consolidación queda en revisión humana.'},groups,recommendations:groups.flatMap(group=>group.recommendations.map((text,index)=>({id:`IR-R-${group.id}-${index+1}`,groupId:group.id,text,sourceRowIds:group.rowIds,requiresHumanReview:true}))),openQuestions:groups.flatMap(group=>group.questions.map((text,index)=>({id:`IR-Q-${group.id}-${index+1}`,groupId:group.id,text,sourceRowIds:group.rowIds,requiresHumanReview:true}))),documentLimits:unique([...(prepared.documentFirstV2?.documentLimits||[]),...(prepared.documentEditorial?.synthesis?.limits||[]).map(item=>clean(item.text||item))]),suggestedRelations:groups.flatMap(group=>group.priorRelations.map(relation=>({groupId:group.id,declaredRelation:relation,status:'requires-human-review'}))),requiresHumanReview:groups.map(group=>({groupId:group.id,reasons:group.reviewReasons})),traceability:{originalFindings:originalFindingIds,insightRegisterRows:rows.map(row=>row.id),orphanedOriginalFindings:[],orphanedRegisterRows:[],orphanedHumanDecisions:[]},totals:{v1Proposals:prepared.documentEditorial?.clusters?.length||0,v2Groups:groups.length,learningCandidates:groups.filter(group=>group.records.some(row=>row.recordType==='Insight UX')).length,recommendations:groups.reduce((total,group)=>total+group.recommendations.length,0),openQuestions:groups.reduce((total,group)=>total+group.questions.length,0),suggestedRelations:groups.reduce((total,group)=>total+group.priorRelations.length,0),requiresHumanReview:groups.length}};
    prepared.insightRegisterSnapshot={version:register.version,file:clone(register.file),rowIds:rows.map(row=>row.id),rowCount:rows.length,analyzedAt:new Date().toISOString()};
    prepared.metadata={...(prepared.metadata||{}),analysisEngine:version,editorialSource:'Insight Register'};
    prepared.review={...(prepared.review||{}),engine:version,status:'Pendiente de revisión'};
    prepared.pendingPublication=null;
    JSON.stringify(prepared);return prepared;
  }

  const approvedS05Decisions={
    'reservation-access':{decision:'Crear nuevo learning',title:'La gestión de la reserva debe concentrarse en un acceso único y reconocible.',relations:[{id:'L-02',nature:'Contextual/complementaria; no ampliar'},{id:'E-05',nature:'Evidencia histórica relacionada'}]},
    'checkin-direct':{decision:'Crear nuevo learning',title:'Check-in requiere un acceso directo y visible como tarea operativa diferenciada.',relations:[{id:'E-05',nature:'Evidencia relacionada'},{id:'P-02',nature:'Relación contextual; no valida una solución concreta por dispositivo'}]},
    'preflight-naming':{decision:'Reforzar learning existente',learningId:'L-10',relations:[{id:'L-10',nature:'Refuerzo directo con evidencia interna de S-05'}]},
    'baggage-findability':{decision:'Solo contexto / evidencia documental',relations:[{id:'L-11',nature:'Evidencia para arquitectura y agrupación'},{id:'L-10',nature:'Solo naming de “Declaración de valor”'}]},
    'assistance-findability':{decision:'Solo contexto / evidencia documental',relations:[{id:'L-10',nature:'Naming de “Pasajeros”'},{id:'L-11',nature:'Agrupación y encontrabilidad'}]},
    'help-rescue':{decision:'Ampliar learning',learningId:'L-11',title:'Ayuda como señal diagnóstica de problemas de naming, agrupación o encontrabilidad',nuance:'Cuando los usuarios recurren a Ayuda para localizar contenidos que pertenecen a otras áreas, ese comportamiento puede señalar problemas de naming, agrupación o encontrabilidad.',relations:[{id:'L-11',nature:'Ampliación explícita'},{id:'L-10',nature:'Relación contextual cuando el desvío se asocia a naming'}]},
    'operational-priority':{decision:'Crear nuevo learning',title:'El primer nivel del Header debe priorizar las necesidades operativas del pasajero.',relations:[{id:'L-09',nature:'Complementaria; no modificar'},{id:'L-11',nature:'Complementaria; no sustituye el nuevo learning'}]},
    'account-loyalty':{decision:'Solo contexto / evidencia documental',relations:[{id:'L-09',nature:'Contextual; no modificar'}]},
    'navigation-presentation':{decision:'Solo contexto / evidencia documental',relations:[{id:'P-02',nature:'Contextual; no valida la solución'},{id:'L-13',nature:'Contextual sobre device; no modificar'},{id:'L-11',nature:'Contextual sobre arquitectura'}]}
  };

  function approvedS05({analysis,document,knowledge,canonicalContext={product:'Home',screen:'Home',component:'Header'}}){
    if(document?.id!=='S-05')throw new Error('La migración aprobada document-first-2 solo puede aplicarse a S-05.');
    const original=clone(analysis),dry=transform({analysis:original,document,knowledge,v1Clusters:original.documentEditorial?.clusters||[],manualDecisions:original.clusterReview||{},canonicalContext});
    const findingById=new Map((original.findings||[]).map(finding=>[findingId(finding),finding]));
    const canonicalFinding=id=>{const finding=findingById.get(id);return finding?{...clone(finding),product:'Home',screen:'Home',component:'Header'}:null;};
    const allOriginalIds=(original.findings||[]).map(findingId),assigned=new Set(),operations=[];
    const addOperation=(operation)=>{operation.evidenceRefs=unique(operation.evidenceRefs||[]);operation.evidenceRefs.forEach(id=>assigned.add(id));operations.push(operation);};
    dry.groups.forEach(group=>{
      const approved=approvedS05Decisions[group.id];if(!approved)return;
      addOperation({id:`V2-G-${group.id}`,kind:'knowledge-decision',groupId:group.id,name:approved.title||group.name,synthesis:group.criterion||group.interpretation.join(' ')||group.name,nuance:approved.nuance||'',decision:approved.decision,learningId:approved.learningId||'',context:{...canonicalContext},specificLimits:clone(group.specificLimits||[]),evidenceRefs:group.evidenceRefs,relations:clone(approved.relations||[]),status:'approved'});
      addOperation({id:`V2-R-${group.id}`,kind:'recommendation',groupId:group.id,name:group.name,synthesis:group.recommendation,decision:'Recomendación de sistema',learningId:'',context:{...canonicalContext},specificLimits:[],evidenceRefs:group.evidenceRefs,relations:[],status:'approved'});
    });
    dry.openQuestions.slice(0,6).forEach((question,index)=>addOperation({id:`V2-Q-${index+1}`,kind:'question',groupId:question.relatedGroupIds?.[0]||'',name:question.text,synthesis:question.text,decision:'Crear pregunta abierta',learningId:'',context:{...canonicalContext},specificLimits:[],evidenceRefs:unique([question.source?.v1ProposalId, ...(question.source?.originalFindingIds||[])]).filter(id=>findingById.has(id)),relations:[],status:'approved'}));
    const unassigned=allOriginalIds.filter(id=>!assigned.has(id));
    addOperation({id:'V2-E-DOCUMENT-CONTEXT',kind:'evidence-context',groupId:'document-context',name:'Contexto, síntesis y trazabilidad documental',synthesis:'Registros originales, contexto metodológico, síntesis del autor, benchmark y propuesta de arquitectura conservados sin elevarlos automáticamente a learning.',decision:'Solo contexto / evidencia documental',learningId:'',context:{...canonicalContext},specificLimits:[],evidenceRefs:unassigned,relations:[],status:'approved'});
    const seen=new Set(),duplicates=[];
    operations.forEach(operation=>operation.evidenceRefs.forEach(id=>{const key=`${operation.id}:${id}`;if(seen.has(key))duplicates.push(key);seen.add(key);}));
    const plan={status:'approved',approvedAt:new Date().toISOString(),publicationRequired:true,automaticPublication:false,operations,canonicalContext:{...canonicalContext},documentLimits:clone(dry.documentLimits),finalRelations:unique(operations.flatMap(operation=>operation.relations.map(relation=>JSON.stringify({...relation,operationId:operation.id})))).map(value=>JSON.parse(value)),trace:{originalRecords:allOriginalIds.length,preservedEvidenceIds:allOriginalIds,unassignedOriginalIds:allOriginalIds.filter(id=>!operations.some(operation=>operation.evidenceRefs.includes(id))),duplicateOperationEvidenceRefs:duplicates,legacyProposalIds:(original.documentEditorial?.clusters||[]).map(cluster=>cluster.id),legacyHumanDecisionIds:Object.keys(original.clusterReview||{}),otherDocumentIdsTouched:[]}};
    const artifact={...dry,mode:'explicit-approved-migration',activated:true,migratedExplicitly:true,approvedAt:new Date().toISOString(),approvalSource:'Revisión editorial humana de los grupos 1–9',historicalClassification:{document:{product:document.product||'',screen:document.screen||'',component:document.component||'',initiative:document.initiative||''},metadata:clone(original.metadata||{})},groups:dry.groups.map(group=>({...group,approvedDecision:clone(approvedS05Decisions[group.id]||null),requiresHumanReview:false,reviewReasons:[]})),publicationPlan:plan,suggestedRelations:clone(plan.finalRelations),requiresHumanReview:[],totals:{...dry.totals,learningCandidates:3,recommendations:9,openQuestions:6,suggestedRelations:plan.finalRelations.length,requiresHumanReview:0}};
    const migrated=clone(original);
    migrated.documentFirstV2=artifact;
    migrated.metadata={...(migrated.metadata||{}),analysisEngine:version,detectedType:'Test de usuarios',products:['Home'],screens:['Home'],components:['Header']};
    migrated.review={...(migrated.review||{}),engine:version,status:'Pendiente de publicación',updatedAt:new Date().toISOString()};
    migrated.pendingPublication={engine:version,status:'ready',automatic:false,approvedOperations:operations.length,createdAt:new Date().toISOString()};
    JSON.stringify(migrated);
    return migrated;
  }

  return {version,transform,prepareNewIngest,prepareWithInsightRegister,approvedS05,approvedS05Decisions:clone(approvedS05Decisions),groupDefinitions:clone(groupDefinitions)};
})();
