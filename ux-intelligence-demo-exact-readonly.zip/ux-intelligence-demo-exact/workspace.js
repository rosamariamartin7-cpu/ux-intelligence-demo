// Controlled extension: document consultation, contextual exploration and project history.
let analysisMode = 'view';
let evolutionState = { validations: [], questionUpdates: [], equivalences: [], events: [], selections: {} };
let projectHistory = { revision: null, snapshot: null, ready: false, error: '', saved: false, conflicts: [] };
let projectSaveQueue = Promise.resolve();
let lastProjectContent = '';

function humanKnowledgeLabel(value) {
  return ({ Inferencia: 'Interpretación UX', 'Inferencia experta': 'Análisis UX', 'Interna + inferencia': 'Datos + análisis UX' })[value] || value;
}
function reviewCanEdit(item) { return canEditDocumentReview(item); }
function consultDocument(id) { openDocumentReview(id); }
function documentInterpretation(item) {
  if (hasRecoveredDocumentAnalysis(item)) return item.archivedReview.interpretation;
  return isDocumentPublished(item)&&item.archivedReview?.publicationStamp===item.analysis.publication.publishedAt ? item.archivedReview.interpretation : buildReviewInterpretation(item?.analysis);
}
function publicationRollbackSnapshot(item) {
  return JSON.parse(JSON.stringify({ analysis:item.analysis, archivedReview:item.archivedReview||null, status:item.status, learnings, evidenceItems, patternItems, knowledgeUnits, openQuestionItems, evolutionState }));
}
function restorePublicationRollback(item, backup) {
  item.analysis=backup.analysis;item.archivedReview=backup.archivedReview;item.status=backup.status;
  [[learnings,'learnings'],[evidenceItems,'evidenceItems'],[patternItems,'patternItems'],[knowledgeUnits,'knowledgeUnits'],[openQuestionItems,'openQuestionItems']].forEach(([collection,key])=>collection.splice(0,collection.length,...backup[key]));
  evolutionState=backup.evolutionState;
}

function serialDocument(item) {
  const { analysisHydration, archivedReview, ...document } = item;
  return JSON.parse(JSON.stringify(document));
}
function restoreInterruptedSourceUpdateView(item) {
  const revision=(item?.sourceHistory||[]).at(-1),sourceUpdate=item?.analysis?.sourceUpdate;
  const recoverable=Boolean(item?.status==='Analizando'&&sourceUpdate?.mode==='linked-existing-record'&&sourceUpdate.documentId===item.id&&
    sourceUpdate.automaticKnowledgeChanges===false&&sourceUpdate.publicationRequired===true&&revision?.id===sourceUpdate.previousRevisionId&&revision?.analysis?.available===false);
  if(!recoverable)return false;
  Object.assign(item,revision.classification||{});
  item.status=revision.status||'Procesado';item.originalName=revision.originalName||'';item.fileMeta=revision.fileMeta||null;
  item.analysis=null;item.archivedReview=null;item.hasAnalysis=false;item.analysisSummary=null;item.processing=null;
  item.analysisError='';item.analysisStack='';item.analysisFailure=null;
  item.sourceUpdateFailure={phase:'interrupted_source_update',message:'La actualización anterior no llegó a guardarse completa. Se ha recuperado el registro histórico para poder reintentarlo.',timestamp:new Date().toISOString()};
  console.warn('[UX Intel fuente documental] Actualización incompleta recuperada',{documentId:item.id,previousRevisionId:revision.id});
  return true;
}
function documentAnalysisSnapshot(item) {
  return { ...serialDocument(item), archivedReview: hasDocumentAnalysis(item) ? {
    interpretation: documentInterpretation(item), insights:isDocumentPublished(item)?publishedAnalysisInsights(item):reviewInsightsForDocument(item), publicationStamp:item.analysis.publication?.publishedAt || null
  } : item.archivedReview || null };
}
function projectSnapshot() {
  return {
    schemaVersion: 1,
    capabilities: {
      documentFirst2: { newIngestsOnly:true, historicalMigration:'explicit' },
      insightRegister: { version:typeof UXInsightRegister==='undefined'?null:UXInsightRegister.version, role:'optional-document-input', sameDocumentId:true },
      knowledgeExport: typeof UXInsightRegister==='undefined'?null:UXInsightRegister.exportModel()
    },
    documents: sourceItems.map(documentAnalysisSnapshot),
    knowledge: { learningState: learnings, evidenceState: evidenceItems, patternState: patternItems, knowledgeUnits, openQuestionItems },
    evolution: evolutionState
  };
}
function projectHistoryMessage() {
  if (projectHistory.error) return `<div class="detail-note"><strong>Histórico del proyecto no guardado.</strong> ${escapeHtml(projectHistory.error)} No se ha borrado el análisis del navegador.</div>`;
  return projectHistory.saved ? '<p>Histórico guardado en el proyecto. Los PDF originales se gestionan en el navegador y no se copian al histórico.</p>' : '<p>Guardando histórico en el proyecto…</p>';
}
function updateHistoryDiagnostic() {
  let node = document.getElementById('project-history-diagnostic');
  if (!node) { node = document.createElement('output'); node.id = 'project-history-diagnostic'; node.hidden = true; document.body.appendChild(node); }
  node.textContent = JSON.stringify({ revision: projectHistory.revision, saved: projectHistory.saved, error: projectHistory.error, documents: sourceItems.filter(hasDocumentAnalysis).map(item => ({ id:item.id, pages:item.analysis.pages, records:item.analysis.findings.length, reviewed:Object.keys(item.analysis.clusterReview||{}).length, published:isDocumentPublished(item) })) });
}
async function restoreProjectHistory() {
  try {
    const response = await fetch('/api/history', { cache:'no-store' });
    if (!response.ok) throw Error('El servidor actual no permite guardar el histórico. Inicia UX Intel con server.py.');
    const data = await response.json();
    projectHistory.revision = data.revision; projectHistory.snapshot = data.snapshot;
    if (data.snapshot) {
      const saved = data.snapshot;
      // Preflight every document before selecting any project revision. Nothing is merged.
      const projectAnalyses = new Set(),conflictedDocuments=new Map();
      for (const historical of saved.documents || []) {
        const local = sourceItems.find(item => item.id === historical.id);
        const browserAnalysis = await getDocumentAnalysis(historical.id);
        if (browserAnalysis && historical.analysis && !sameAnalysisValue(browserAnalysis, historical.analysis)) {
          const check = projectReviewSubsumesLocal(local?.id, historical, browserAnalysis);
          console.info('[UX Intel restauración]', JSON.stringify({documentId:historical.id, ...check}));
          if (!check.subsumed) {conflictedDocuments.set(historical.id,`Hay dos revisiones distintas de ${historical.name}. No se ha sobrescrito ninguna; hay que elegir qué revisión continuar.`);continue;}
          projectAnalyses.add(historical.id);
        }
        if (!browserAnalysis && historical.analysis) projectAnalyses.add(historical.id);
      }
      for (const historical of saved.documents || []) {
        const local = sourceItems.find(item => item.id === historical.id);
        if(conflictedDocuments.has(historical.id))continue;
        if (local) {
          Object.assign(local, historical);
          if (projectAnalyses.has(historical.id)) local.analysisHydration = { storage:'Proyecto/history' };
          local.archivedReview = historical.archivedReview;
          restoreInterruptedSourceUpdateView(local);
        } else sourceItems.push({...historical, ...(projectAnalyses.has(historical.id) ? {analysisHydration:{storage:'Proyecto/history'}} : {})});
      }
      // A recovered project is authoritative, including an empty collection.
      // Never publish default catalog seeds over a project snapshot from another origin.
      const collections = [[learnings,'learningState'],[evidenceItems,'evidenceState'],[patternItems,'patternState'],[knowledgeUnits,'knowledgeUnits'],[openQuestionItems,'openQuestionItems']];
      collections.forEach(([collection,key])=>{if(saved.knowledge?.[key])collection.splice(0,collection.length,...saved.knowledge[key]);});
      evolutionState = saved.evolution || evolutionState;
      projectHistory.saved = true;
      projectHistory.conflicts=[...conflictedDocuments.entries()].map(([documentId,message])=>({documentId,message}));
      projectHistory.error=projectHistory.conflicts.length?`${projectHistory.conflicts.length} documento(s) conservan dos revisiones. Se mantienen sin sobrescribir y el guardado global queda bloqueado hasta resolverlos.`:'';
      renderLearnings();renderEvidence();renderPatterns();
    }
    projectHistory.ready = true;
  } catch (error) { projectHistory.error = error.message; console.error('[UX Intel histórico]', error); }
  updateHistoryDiagnostic();
}

// Exact data comparison, independent of object key order. Arrays retain their order.
function sameAnalysisValue(left, right) {
  if (left === right) return true;
  if (!left || !right || typeof left !== 'object' || typeof right !== 'object' || Array.isArray(left) !== Array.isArray(right)) return false;
  const keys = Object.keys(left);
  return keys.length === Object.keys(right).length && keys.every(key => Object.hasOwn(right,key) && sameAnalysisValue(left[key],right[key]));
}
function projectReviewSubsumesLocal(documentId, historical, local) {
  const project = historical?.analysis;
  const fail = reason => ({subsumed:false, reason});
  const omit = (value, keys) => Object.fromEntries(Object.entries(value || {}).filter(([key]) => !keys.includes(key)));
  if (!documentId || historical?.id !== documentId || !local || !project) return fail('Identidad de documento no comprobada');
  if (!local.findings?.length || !local.findings.every(record => record.source?.documentId === documentId)) return fail('Registros sin identidad de fuente comprobada');
  const v2Migration=project.documentFirstV2?.mode==='explicit-approved-migration'&&!local.documentFirstV2;
  if(v2Migration){
    const comparable=['pages','findings','relations','discarded','typeCounts','coverage','documentEditorial','clusterReview','extraction','extractedPages','extractedText'];
    const basePreserved=comparable.every(key=>sameAnalysisValue(local[key],project[key]));
    const trace=project.documentFirstV2?.publicationPlan?.trace;
    const decisionsPreserved=trace?.legacyHumanDecisionIds?.length===Object.keys(local.clusterReview||{}).length&&trace.legacyHumanDecisionIds.every(id=>Object.hasOwn(local.clusterReview||{},id));
    if(basePreserved&&decisionsPreserved)return {subsumed:true,reason:'Migración document-first-2 explícita: base V1 y decisiones humanas conservadas íntegramente'};
    return fail('La migración V2 no conserva exactamente la base V1 local');
  }
  const metadataClosure=project.documentFirstV2?.metadataCorrection?.id==='S-05-analysis-type-test-users'&&!project.documentFirstV2?.relationsCorrection&&local.documentFirstV2?.mode==='explicit-approved-migration';
  if(metadataClosure){
    const comparable=JSON.parse(JSON.stringify(project));
    comparable.metadata={...(comparable.metadata||{}),detectedType:local.metadata?.detectedType};
    delete comparable.documentFirstV2.metadataCorrection;
    if(sameAnalysisValue(comparable,local))return {subsumed:true,reason:'Cierre controlado S-05: solo corrige el tipo documental y conserva íntegro el análisis aprobado'};
    return fail('El cierre de metadata S-05 contiene cambios adicionales');
  }
  const relationsClosure=project.documentFirstV2?.relationsCorrection?.id==='S-05-approved-relations'&&local.documentFirstV2?.mode==='explicit-approved-migration';
  if(relationsClosure){
    const comparable=JSON.parse(JSON.stringify(project));
    comparable.documentFirstV2.suggestedRelations=JSON.parse(JSON.stringify(local.documentFirstV2?.suggestedRelations||[]));
    delete comparable.documentFirstV2.relationsCorrection;
    if(sameAnalysisValue(comparable,local))return {subsumed:true,reason:'Cierre controlado S-05: alinea las relaciones sugeridas con las decisiones editoriales aprobadas'};
    return fail('El cierre de relaciones de S-05 contiene cambios adicionales');
  }
  // A published project revision safely supersedes an untouched browser copy
  // when their complete source/base is identical. The older browser artifact
  // remains in IndexedDB and is never rewritten during project hydration.
  const publishedSuccessor=project.publication?.status==='published'&&!local.publication&&
    Object.keys(local.clusterReview||{}).length===0&&['','Pendiente de revisión'].includes(local.review?.status||'');
  if(publishedSuccessor){
    const baseKeys=['clusterReview','review','publication'];
    const basePreserved=sameAnalysisValue(omit(local,baseKeys),omit(project,baseKeys));
    const projectReview=Object.values(project.clusterReview||{});
    const publicationComplete=projectReview.length>0&&projectReview.every(value=>['approved','reviewed','validated','published','discarded'].includes(value?.status));
    if(basePreserved&&publicationComplete)return {subsumed:true,reason:'La revisión publicada conserva íntegra la base local sin decisiones y añade el historial de revisión y publicación'};
    return fail('La revisión publicada no demuestra una sucesión íntegra de la copia local');
  }
  // Includes raw records, extraction, source metadata, units, titles, relations and publication.
  // Unknown fields are compared too: an exclusive local field must never disappear.
  const baseLocal = omit(local,['clusterReview','review']), baseProject = omit(project,['clusterReview','review']);
  if (!sameAnalysisValue(baseLocal,baseProject)) return fail('La base del análisis contiene diferencias');
  if (!sameAnalysisValue(omit(local.review,['updatedAt']),omit(project.review,['updatedAt']))) return fail('El estado de revisión contiene diferencias');
  const previous = local.clusterReview || {}, next = project.clusterReview || {};
  if (!Object.entries(previous).every(([id,decision]) => Object.hasOwn(next,id) && sameAnalysisValue(decision,next[id]))) return fail('Hay edición o decisión local no conservada íntegramente');
  const reviewed = value => ['approved','reviewed','validated','published','discarded'].includes(value?.status);
  if (!Object.entries(next).some(([id,decision]) => !Object.hasOwn(previous,id) && reviewed(decision))) return fail('No se ha demostrado progreso humano adicional');
  return {subsumed:true, reason:'Base idéntica y todas las ediciones locales conservadas; el proyecto añade revisión humana'};
}

function finishProjectRestoration() {
  // Loading an existing revision is not a new edit. Do not manufacture a snapshot
  // from derived presentation/metadata during hydration; explicit saves still work.
  if (projectHistory.ready && projectHistory.saved && !projectHistory.error) {
    lastProjectContent = JSON.stringify(projectSnapshot());
    return Promise.resolve(true);
  }
  return queueProjectHistory();
}
function queueProjectHistory() {
  if (!projectHistory.ready || projectHistory.error || !documentHydrationComplete) return Promise.resolve(false);
  const snapshot = projectSnapshot(), serialized = JSON.stringify(snapshot);
  projectSaveQueue = projectSaveQueue.catch(()=>false).then(async () => {
    if (lastProjectContent === serialized) return true;
    try {
      const response = await fetch('/api/history', { method:'POST', headers:{'Content-Type':'application/json','X-UX-Intel':'project-history'}, body:JSON.stringify({ expectedRevision:projectHistory.revision, snapshot }) });
      const result = await response.json();
      if (!response.ok) throw Error(result.error || 'No se pudo guardar el histórico');
      projectHistory.revision = result.revision; projectHistory.snapshot = snapshot; projectHistory.saved = true; lastProjectContent = serialized;
      updateHistoryDiagnostic(); return true;
    } catch(error) { projectHistory.saved = false; projectHistory.error = error.message; updateHistoryDiagnostic(); showToast('No se ha guardado el histórico del proyecto', error.message); console.error('[UX Intel histórico]',error); return false; }
  });
  return projectSaveQueue;
}

// Analysis completion and edits commit one document, not a stale copy of the KB.
// Await the versioned project file and read it back before acknowledging success.
function persistDocumentAnalysis(item, expectedAnalysis, options={}) {
  const document = JSON.parse(JSON.stringify(documentAnalysisSnapshot(item)));
  const expected = JSON.stringify(expectedAnalysis || null);
  projectSaveQueue = projectSaveQueue.catch(()=>false).then(async () => {
    let phase = 'project_read';
    const request = async options => {
      const response = await fetch('/api/history', options || {cache:'no-store'});
      const result = await response.json();
      if (!response.ok) throw Object.assign(Error(result.error || `Error de guardado (${response.status})`), {httpStatus:response.status});
      return result;
    };
    try {
      if (!hasDocumentAnalysis(document)) throw Error('No existe un análisis válido para guardar.');
      const current = await request();
      const snapshot = current.snapshot || {schemaVersion:1,documents:[],knowledge:{},evolution:{}};
      const index = snapshot.documents.findIndex(saved=>saved.id===document.id);
      const currentDocument = index < 0 ? null : snapshot.documents[index];
      const previous = currentDocument?.analysis || null;
      const interruptedRevisionId=currentDocument?.analysis?.sourceUpdate?.previousRevisionId;
      const interruptedLinkedUpdate=Boolean(options.allowInterruptedSourceUpdate&&currentDocument?.status==='Analizando'&&
        currentDocument?.analysis?.sourceUpdate?.mode==='linked-existing-record'&&currentDocument.analysis.sourceUpdate.documentId===document.id&&
        currentDocument?.analysis?.sourceUpdate?.automaticKnowledgeChanges===false&&currentDocument?.analysis?.sourceUpdate?.publicationRequired===true&&
        interruptedRevisionId&&(currentDocument.sourceHistory||[]).some(revision=>revision.id===interruptedRevisionId)&&
        (document.sourceHistory||[]).some(revision=>revision.id===interruptedRevisionId));
      // An unrelated revision can be rebased safely; a divergent analysis cannot.
      if (JSON.stringify(previous)!==expected && JSON.stringify(previous)!==JSON.stringify(document.analysis) && !interruptedLinkedUpdate) {
        throw Error('El análisis ha cambiado en otra pestaña. Recarga antes de guardar; no se ha sobrescrito ninguna revisión.');
      }
      if (index < 0) snapshot.documents.push(document); else snapshot.documents[index]=document;
      phase = 'project_write';
      const result = await request({method:'POST',headers:{'Content-Type':'application/json','X-UX-Intel':'project-history'},body:JSON.stringify({expectedRevision:current.revision,snapshot})});
      phase = 'project_readback';
      const restored = await request();
      const saved = restored.snapshot?.documents?.find(saved=>saved.id===document.id);
      if (!saved || JSON.stringify(saved.analysis)!==JSON.stringify(document.analysis) || saved.status!==document.status || JSON.stringify(saved.archivedReview)!==JSON.stringify(document.archivedReview)) {
        throw Error('El análisis no ha superado la comprobación de guardado en el proyecto.');
      }
      // Do not grant stale global state permission to overwrite another tab's KB.
      if (current.revision===projectHistory.revision && restored.revision===result.revision) {
        projectHistory.revision=result.revision;projectHistory.snapshot=snapshot;
        projectHistory.ready=true;projectHistory.error='';lastProjectContent=JSON.stringify(snapshot);
      }
      projectHistory.saved=true;
      updateHistoryDiagnostic();
      console.info('[UX Intel análisis guardado]',{documentId:document.id,revision:result.revision,pages:saved.analysis.pages,records:saved.analysis.findings.length,insights:saved.archivedReview.insights.length,status:saved.status});
      return true;
    } catch (error) {
      error.phase=phase;projectHistory.saved=false;projectHistory.error=error.message;
      updateHistoryDiagnostic();
      console.error('[UX Intel persistencia del análisis]',{documentId:document.id,phase,message:error.message,stack:error.stack,error});
      throw error;
    }
  });
  return projectSaveQueue;
}

function evidenceRecords() {
  return evidenceItems.map(item => {const unit=knowledgeUnits.find(unit=>unit.id===item.unitId);return { ...unit,...item, sources:catalogSources(item).map(source=>({ id:source.id, name:source.name, page:unit?.source?.page || item.source?.page, recordId:item.unitId || item.id })) };});
}
function consolidatedEvidence(items=evidenceRecords()) { return UXKnowledge.consolidate(items, evolutionState.equivalences); }
function displayEvidenceItems(items) {
  return consolidatedEvidence(items.map(item=>({...item,sources:catalogSources(item).map(source=>({id:source.id,name:source.name,recordId:item.unitId||item.id}))}))).map(group=>({...group.representative, consolidation:group}));
}
function editorialCopy(value) { return String(value??'').replace(/;\s*/g, '. ').replace(/\. ([a-záéíóúñ])/g,(_,letter)=>'. '+letter.toUpperCase()); }
function knownMetadata(value) { return value!==undefined&&value!==null&&String(value).trim()!==''&&!/^(no especificad[oa]|no informad[oa]|desconocid[oa]|sin clasificar|—)$/i.test(String(value)); }
function evidencePeriod(item) { return item.measurementPeriod||item.period||String(item.source||'').match(/\d{2}\/\d{2}[–-]\d{2}\/\d{2}\/\d{4}/)?.[0]; }
function evidenceMetadata(item) {
  const context=[item.product,item.screen,...componentsOf(item),item.element].filter(knownMetadata);
  const measurement=evidencePeriod(item);
  const explicitDate=[item.evidenceDate,item.documentDate].find(value=>typeof value==='string'&&knownMetadata(value));
  const sourceDate=catalogSources(item).map(documentDate).find(knownMetadata);
  const date=measurement||explicitDate||(sourceDate?`Documento: ${sourceDate}`:'');
  return [...new Set([...context,humanKnowledgeLabel(item.kind),date].filter(knownMetadata))].join(' · ');
}
function provenanceNote(item,type) {
  if(catalogSources(item).length)return '';
  const nature=type==='pattern'?`Patrón · ${item.status||'Propuesto'}`:type==='learning'?'Learning sin respaldo vinculado':humanKnowledgeLabel(item.type||item.kind||'Referencia');
  const linked=learnings.filter(learning=>item.proof?.includes(learning.id)||(item.learningIds||[]).includes(learning.id));
  if(linked.length)return `${nature}. Respaldo a través de ${linked.map(learning=>learning.id).join(', ')}. Sin fuente directa vinculada.`;
  return `${nature}. Sin fuente vinculada${item.proof?'. El respaldo citado no identifica documentos concretos':''}.`;
}
function evidenceExplanation(item) {
  // Editorial expansion is separate from source data. Numbers and claims remain untouched.
  const editorial = {
    'E-01': 'Los datos muestran cómo se reparte la interacción entre campos del buscador, Buscar vuelos, accesos de autogestión y promoción. Permiten comparar qué zonas de Home se utilizan.',
    'E-06': 'Los datos internos registran el uso de los accesos a gestión de reserva, cuenta y Check-in. Ayudan a valorar qué accesos operativos deben seguir siendo fáciles de encontrar.',
    'E-07': 'El desk research reúne principios de simplicidad, diseño desde mobile, flexibilidad, edición y accesibilidad en la reserva de vuelos. Sirven como criterios para revisar el buscador, no como resultados medidos en Air Europa.',
    'E-08': 'El benchmark compara cómo otras aerolíneas organizan la búsqueda, los calendarios, el autoservicio y la promoción. Permite contrastar alternativas de diseño, sin demostrar que funcionarán igual en Air Europa.',
    'E-09': 'El benchmark compara la navegación global de otros referentes y plantea hipótesis para el Header. El resumen disponible no detalla resultados concretos, por lo que hay que contrastar esas hipótesis con el research interno.',
    'E-10': 'El análisis de Quantum Metric relaciona las zonas que concentran interacción con la prioridad del buscador y los accesos de autogestión. Es una interpretación UX de los datos, no una prueba de causalidad.',
    'E-11': 'El análisis aplica principios de comprensión, atención y control para revisar qué se muestra primero y qué puede aparecer después. Ofrece una lectura UX, no una validación del comportamiento real.',
    'E-12': 'La auditoría revisa la densidad y jerarquía de Home, su adaptación entre dispositivos y los condicionantes de SEO y Magnolia. Señala qué decisiones de diseño necesitan revisión.',
    'E-13': 'La síntesis de los tests distingue la mejora del autoservicio del efecto sobre Buscar, que varía entre mobile y desktop. Orienta a revisar la integración visual del Header sin atribuir el resultado a un cambio aislado.',
  };
  return editorialCopy(item.authorSynthesis || editorial[item.id] || item.contribution || item.text || '');
}
function evidenceUxMeaning(item) {
  if (item.uxMeaning) return item.uxMeaning;
  const implications={
    'E-01':'Comparar la atención que reciben la búsqueda, los accesos operativos y la promoción antes de cambiar su jerarquía. El volumen de interacción no demuestra por sí solo cuál es la mejor composición.',
    'E-02':'Revisar el paso a Disponibilidad por dispositivo, especialmente en mobile. La diferencia de abandono señala dónde investigar, pero no identifica qué elemento provoca la salida.',
    'E-03':'Mantener la mejora de acceso al autoservicio como referencia para mobile, sin extrapolar el resultado a desktop ni dar por confirmada su implementación.',
    'E-04':'Revisar cómo conviven los accesos de autoservicio y Buscar en desktop. La mejora de una tarea no basta para dar por cerrada la composición del Header.',
    'E-05':'Conservar un acceso reconocible a Gestionar reserva y un acceso propio a Check-in. El research respalda su comprensión, no garantiza un efecto en conversión.',
    'E-06':'Tener en cuenta gestión, cuenta y Check-in al priorizar accesos. Su uso operativo debe contrastarse con el espacio disponible y el contexto de cada dispositivo.',
    'E-07':'Revisar si el buscador se entiende, permite corregir datos y funciona en mobile con accesibilidad. Son criterios de evaluación, no una solución ya validada.',
    'E-08':'Comparar alternativas de calendario, secuencia y jerarquía antes de diseñar. La presencia de un patrón en otra aerolínea no demuestra su eficacia aquí.',
    'E-09':'El resumen no permite elegir una solución de navegación concreta. Es necesario consultar los ejemplos y contrastarlos con el research antes de tomar esa decisión.',
    'E-10':'Usar el reparto de interacción como punto de partida para revisar jerarquía y accesos. Las oportunidades identificadas por el análisis UX siguen necesitando validación.',
    'E-11':'Revisar qué información recibe atención primero y cuándo ofrecer opciones secundarias, manteniendo el control del usuario. Comprobar después la propuesta con uso real.',
    'E-12':'Contrastar densidad, jerarquía y adaptación por dispositivo antes de iterar el buscador. Las decisiones de SEO y Magnolia requieren comprobar sus condicionantes concretos.',
    'E-13':'Separar la decisión sobre arquitectura de la decisión sobre composición visual. Revisar cada dispositivo y conservar los límites del test antes de reutilizar la solución.'
  };
  if(implications[item.id])return implications[item.id];
  const related = learnings.filter(learning=>catalogSources(learning).some(source=>catalogSources(item).some(other=>other.id===source.id)));
  return related.length ? `Ayuda a revisar las decisiones recogidas en los learnings relacionados. Consulta su contexto y sus límites antes de aplicarlas.` : 'No hay una implicación de diseño adicional documentada para esta evidencia.';
}
function evidenceFactsMarkup(rows,metrics=false) {
  const present=rows.filter(([,value])=>knownMetadata(value)&&['string','number'].includes(typeof value));
  return present.length?`<dl class="evidence-facts ${metrics?'evidence-metrics':''}">${present.map(([label,value])=>`<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(editorialCopy(value))}</dd></div>`).join('')}</dl>`:'';
}
function evidenceRelationship(item,target,sharedSources) {
  const unitIds=[item.unitId,item.id].filter(Boolean);
  const explicit=[...(target.insightContributions||[]),...(target.publicationHistory||[])].find(entry=>entry.unitIds?.some(id=>unitIds.includes(id)));
  const labels={'Reforzar learning':'Refuerza','Reforzar learning existente':'Refuerza','Ampliar learning':'Amplía','Contradice learning':'Contradice','Usar como evidencia':'Contextualiza'};
  if(explicit&&labels[explicit.decision])return {label:explicit.relationNature||labels[explicit.decision],text:explicit.text||`Esta evidencia forma parte de la aportación revisada a este conocimiento. ${explicit.sourceName||''}`};
  const sources=catalogSources(target).filter(source=>sharedSources.some(other=>other.id===source.id));
  return {label:sources.length?'Fuente compartida':'Relación indirecta',text:sources.length?`Comparte con esta evidencia ${sources.length===1?'la fuente':'las fuentes'}: ${sources.map(source=>source.name).join(', ')}.`:'Está relacionado a través de los learnings que citan esta evidencia. No hay una relación de refuerzo o contradicción registrada.'};
}
function relatedEvidenceDrawer(id) {
  const group=consolidatedEvidence().find(group=>group.members.some(item=>item.id===id));if(!group)return;
  const item=group.representative,sources=[...new Map(group.sources.map(source=>[source.id,source])).values()];
  const sharesSource=record=>catalogSources(record).some(source=>sources.some(other=>other.id===source.id));
  const related=learnings.filter(sharesSource),tests=experiments.filter(sharesSource);
  const patterns=patternItems.filter(pattern=>sharesSource(pattern)||related.some(learning=>pattern.proof?.includes(learning.id)));
  const others=consolidatedEvidence().filter(other=>other.id!==group.id&&other.members.some(sharesSource));
  const exactTests=item.kind==='Test A/B'?tests.filter(test=>test.device===item.device):[];
  const exactTest=exactTests.length===1?exactTests[0]:null;
  const metadata=[['Procedencia',typeof UXKnowledge==='undefined'?'No especificada':UXKnowledge.evidenceOrigin(item)],['Mercado',item.market],['Segmento',item.segment]];
  const metrics=[['Periodo de medición',evidencePeriod(item)],['Duración',item.duration||String(item.context||'').match(/\b\d+ días\b/)?.[0]||exactTest?.duration],
    ['Muestra',item.sample||item.sampleSize],['Participantes',item.participants],['Referentes',item.referenceCount],['Métrica',item.metric||item.kpi],['Uplift relativo',item.uplift],['Chance to win',item.chanceToWin],['Significancia',item.significance],['Resultado',item.result||exactTest?.outcome],
    ...(Array.isArray(item.metrics)?item.metrics:exactTest?.metrics||[]).map(metric=>[metric.label,metric.value])];
  const section=(label,html,css='')=>html?`<section class="drawer-section ${css}"><h3>${label}</h3>${html}</section>`:'';
  const paragraph=text=>text?`<p>${escapeHtml(editorialCopy(text))}</p>`:'';
  const displayContext=typeof taxonomyPresentation==='function'?taxonomyPresentation(item,'evidence'):item;
  const contextPath=[displayContext.product,displayContext.screen,...(displayContext.components||componentsOf(item))].filter(knownMetadata);
  const header=`<div class="evidence-reader-header"><div class="drawer-kicker">Evidencia · ${escapeHtml(humanKnowledgeLabel(item.kind))}</div><h2>${escapeHtml(editorialCopy(item.name))}</h2><div class="drawer-tags">${knownMetadata(item.device)?`<span class="status-badge neutral">${escapeHtml(item.device)}</span>`:''}<span class="status-badge ${confidenceClass(item.confidence)}">Confianza ${escapeHtml(item.confidence)}</span>${sources.length?`<span class="status-badge neutral">${sources.length} ${sources.length===1?'fuente':'fuentes'}</span>`:''}</div></div>`;
  const relationRow=(record,type,label,explanation)=>{
    const action=type==='learning'?`data-learning="${escapeHtml(record.id)}"`:`data-detail="${type}" data-id="${escapeHtml(record.id)}"`;
    const actionLabel=type==='learning'?'Ver learning':type==='pattern'?'Ver patrón':type==='experiment'?'Ver test':'Ver evidencia';
    return `<article class="evidence-relation"><small>${escapeHtml(label)}</small><h4>${escapeHtml(editorialCopy(record.title||record.name))}</h4>${paragraph(explanation)}<button class="view-link" type="button" ${action}>${actionLabel}</button></article>`;
  };
  const knowledge=related.map(learning=>{const relation=evidenceRelationship(item,learning,sources);return relationRow(learning,'learning',`Learning · ${relation.label}`,relation.text);}).join('')+
    patterns.map(pattern=>{const relation=evidenceRelationship(item,pattern,sources);return relationRow(pattern,'pattern',`Patrón · ${relation.label}`,relation.text);}).join('');
  const sourceLinks=sources.map(source=>{
    const catalog=sourceItems.find(record=>record.id===source.id)||source,date=catalog.documentDate||catalog.date?documentDate(catalog):'';
    return `<div class="evidence-source"><button class="text-button" data-open-source-detail="${escapeHtml(source.id)}">${escapeHtml(source.name)}</button>${knownMetadata(date)?paragraph('Fecha del documento: '+date):''}${catalog.originalName?paragraph('Archivo: '+catalog.originalName):''}</div>`;
  }).join('');
  const traceRows=[['Fecha de la evidencia',typeof item.evidenceDate==='string'?item.evidenceDate:''],['Sección',typeof item.source==='object'?item.source?.section:item.section],['Página',typeof item.source==='object'?item.source?.page:item.page]];
  const traces=group.sources.filter(source=>source.page||source.recordId).map(source=>paragraph(`${source.id}${source.page?` · pág. ${source.page}`:''}${source.recordId?` · registro ${source.recordId}`:''}`)).join('');
  const body=(typeof taxonomyLegacyDisclosure==='function'?taxonomyLegacyDisclosure(item,'evidence'):'')+
    section('Qué encontramos',paragraph(evidenceExplanation(item)),'evidence-primary')+
    section('Qué significa para UX',paragraph(evidenceUxMeaning(item)),'evidence-primary')+
    section('Qué no demuestra',paragraph(evidenceLimit(item))+(group.limits.length?list(group.limits.map(editorialCopy)):''),'evidence-limit')+
    section('Matices',group.nuances.length?list(group.nuances.map(editorialCopy)):'')+
    section('Evidencia contradictoria',group.contradictions.length?list(group.contradictions.map(editorialCopy)):'')+
    section('Dónde aplica',`<p class="evidence-path">${escapeHtml(contextPath.join(' → '))}</p>${item.element?paragraph(item.element):''}${evidenceFactsMarkup(metadata)}`)+
    section('Datos clave',evidenceFactsMarkup(metrics,true))+
    section('Qué conocimiento respalda',knowledge)+
    section('Test A/B relacionados',tests.map(test=>relationRow(test,'experiment','Test A/B · fuente compartida',`La evidencia y este test proceden de la misma fuente. ${test.result||''}`)).join(''))+
    section('Evidencias relacionadas',others.map(other=>relationRow(other.representative,'evidence','Evidencia · fuente compartida',evidenceRelationship(item,other.representative,sources).text)).join(''))+
    section('Fuente y trazabilidad',(sourceLinks||paragraph(provenanceNote(item,'evidence')))+evidenceFactsMarkup(traceRows)+
      (typeof item.source==='string'?paragraph('Referencia: '+item.source):'')+
      (traces?`<details><summary>Páginas y registros de origen</summary>${traces}</details>`:'')+
      (group.members.length>1?`<details><summary>Ver ${group.members.length} formulaciones originales</summary>${group.members.map(member=>paragraph(member.contribution||member.text)).join('')}</details>`:''));
  openDrawer(header,`<div class="evidence-reader">${body}</div>`);
}

function documentKnowledgeRelations(item) {
  const linked=records=>records.filter(record=>catalogSources(record).some(source=>source.id===item.id));
  const learningSet=linked(learnings);
  const patternSet=patternItems.filter(pattern=>catalogSources(pattern).some(source=>source.id===item.id)||
    (String(pattern.proof||'').match(/\bL-\d+\b/g)||[]).some(id=>learningSet.some(learning=>learning.id===id)));
  return {learnings:learningSet,evidence:linked(evidenceItems),tests:linked(experiments),patterns:patternSet,
    units:linked(knowledgeUnits),questions:linked(openQuestionItems)};
}

function documentUploadIdentity(value) {
  return String(value || '')
    .replace(/([a-záéíóúñ])([A-ZÁÉÍÓÚÑ])/g,'$1 $2')
    .replace(/\.[^.]+$/,'')
    .replace(/^\s*\d+(?:[._-]\d+)*[._-]*/,'')
    .normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()
    .replace(/[^a-z0-9]+/g,' ').trim();
}
function documentUploadTokens(value) {
  const ignored=new Set(['de','del','la','el','los','las','y','documento','informe','final','revisado','revision','version','v']);
  return [...new Set(documentUploadIdentity(value).split(/\s+/).filter(token=>token.length>1&&!ignored.has(token)))];
}
function documentUploadMatchScore(file,item) {
  const fileName=typeof file==='string'?file:file?.name||'',fileText=documentUploadIdentity(fileName),fileTokens=documentUploadTokens(fileName);
  if(!fileText||!fileTokens.length)return 0;
  const names=[item?.originalName,item?.fileMeta?.name,item?.name,String(item?.name||'').split('·').pop()].filter(Boolean);
  return Math.max(0,...names.map(name=>{
    const text=documentUploadIdentity(name),tokens=documentUploadTokens(name);
    if(!text||!tokens.length)return 0;
    if(text===fileText)return 1;
    const shared=fileTokens.filter(token=>tokens.includes(token)).length;
    if(!shared)return 0;
    const coverage=shared/Math.max(fileTokens.length,tokens.length),contains=fileText.includes(text)||text.includes(fileText);
    return Math.min(.99,coverage+(contains ? .16 : 0)+(shared>=2&&shared===Math.min(fileTokens.length,tokens.length) ? .12 : 0));
  }));
}
function documentUploadCandidates(file,items=sourceItems) {
  return items.map(item=>({item,score:documentUploadMatchScore(file,item)})).filter(match=>match.score>=.72).sort((a,b)=>b.score-a.score||String(a.item.id).localeCompare(String(b.item.id)));
}
function documentSourceUpdateSnapshot(item,related=documentKnowledgeRelations(item)) {
  const copy=value=>value==null?value:JSON.parse(JSON.stringify(value));
  return {
    id:`${item.id}-SOURCE-${Date.now()}`,recordedAt:new Date().toISOString(),reason:'Actualización de fuente documental',status:item.status,
    originalName:item.originalName||'',fileMeta:copy(item.fileMeta||null),
    classification:copy({product:item.product,screen:item.screen,component:item.component,components:item.components||[],element:item.element,initiative:item.initiative,initiatives:item.initiatives||[],zone:item.zone||'',scope:item.scope||'',market:item.market||'',type:item.type,exactDate:item.exactDate,documentDate:item.documentDate||null}),
    analysis:hasDocumentAnalysis(item)?{available:true,createdAt:item.analysis.createdAt||'',pages:item.analysis.pages||0,findings:item.analysis.findings?.length||0,reviewStatus:item.analysis.review?.status||'',publicationStatus:item.analysis.publication?.status||''}:{available:false},
    relatedKnowledge:{learnings:related.learnings.map(record=>record.id),evidence:related.evidence.map(record=>record.id),tests:related.tests.map(record=>record.id),patterns:related.patterns.map(record=>record.id),units:related.units.map(record=>record.id),questions:related.questions.map(record=>record.id)},
    projectRevision:projectHistory?.revision||null
  };
}
function documentSourceUpdateBaseline(item) {
  const related=documentKnowledgeRelations(item);
  return {revision:documentSourceUpdateSnapshot(item,related),knowledge:{learnings:related.learnings.map(record=>record.id),evidence:related.evidence.map(record=>record.id),tests:related.tests.map(record=>record.id),patterns:related.patterns.map(record=>record.id),units:related.units.map(record=>record.id),questions:related.questions.map(record=>record.id)}};
}
function annotateSourceUpdateAnalysis(analysis,item,baseline) {
  if(!analysis||!baseline)return analysis;
  const historicalLearnings=new Set(baseline.knowledge.learnings),historicalIds=new Set(Object.values(baseline.knowledge).flat());
  (analysis.relations||[]).forEach(relation=>{
    const candidateIds=(relation.candidates||[]).map(candidate=>candidate.id);
    relation.sourceUpdateComparison={historicalKnowledge:Boolean(relation.learningId&&historicalLearnings.has(relation.learningId)||candidateIds.some(id=>historicalIds.has(id))),possibleDuplicate:Boolean(relation.duplicate),requiresHumanReview:true};
  });
  analysis.sourceUpdate={mode:'linked-existing-record',documentId:item.id,previousRevisionId:baseline.revision.id,comparedAt:new Date().toISOString(),existingKnowledge:baseline.knowledge,automaticKnowledgeChanges:false,publicationRequired:true};
  return analysis;
}
function documentSourceHistoryMarkup(item) {
  const revisions=item.sourceHistory||[];if(!revisions.length)return '';
  const latest=revisions.at(-1),classification=latest.classification||{},current={product:item.product,screen:item.screen,component:item.component,initiative:item.initiative,type:item.type,exactDate:item.exactDate};
  const labels={product:'Producto',screen:'Pantalla',component:'Componente',initiative:'Iniciativa',type:'Tipo',exactDate:'Fecha'};
  const changes=Object.entries(labels).filter(([key])=>String(classification[key]||'')!==String(current[key]||''));
  const rows=changes.length?changes.map(([key,label])=>`<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(classification[key]||'No especificado')}</dd></div>`).join(''):'<div><dt>Clasificación</dt><dd>Coincide con la actual</dd></div>';
  return `<details class="knowledge-state-disclosure"><summary>Registro histórico anterior</summary><p>Se conserva la clasificación y el estado anteriores a la actualización de la fuente.</p><dl>${rows}<div><dt>Estado</dt><dd>${escapeHtml(latest.status||'No especificado')}</dd></div><div><dt>Archivo</dt><dd>${escapeHtml(latest.originalName||'No disponible')}</dd></div></dl></details>`;
}
function documentKnowledgeOverview(item) {
  const related=documentKnowledgeRelations(item),incorporated=[
    [related.learnings.length,'learning','learnings'],[related.evidence.length,'evidencia','evidencias'],
    [related.tests.length,'test A/B','tests A/B'],[related.patterns.length,'patrón','patrones'],
    [related.questions.length,'pregunta abierta','preguntas abiertas']
  ].filter(([count])=>count);
  if(incorporated.length)return {kind:'incorporated',text:incorporated.map(([count,one,many])=>`${count} ${count===1?one:many}`).join(' · ')};
  if(typeof hasDocumentAnalysis==='function'&&hasDocumentAnalysis(item)){
    const units=reviewInsightsForDocument(item),questions=units.filter(unit=>unit.kind==='question'||(!unit.kind&&unit.decision==='Crear pregunta abierta')).length,insights=units.length-questions;
    const parts=[[insights,'insight','insights'],[questions,'pregunta abierta','preguntas abiertas']].filter(([count])=>count).map(([count,one,many])=>`${count} ${count===1?one:many}`);
    return {kind:isDocumentPublished(item)?'incorporated':'pending',text:`${parts.join(' · ')||'Análisis disponible'}${isDocumentPublished(item)?'':' · sin publicar'}`};
  }
  return {kind:'empty',text:'Sin conocimiento incorporado'};
}
function documentSourceGenealogyMarkup(item) {
  const provenance=UXKnowledge.documentProvenance(item);
  if(!provenance.sourceDocumentIds.length)return '';
  const sources=provenance.sourceDocumentIds.map(id=>sourceItems.find(source=>source.id===id)).filter(Boolean);
  return `<section class="drawer-section related-section"><h3>Fuentes utilizadas</h3><p>Este documento conserva una relación explícita con ${sources.length||provenance.sourceDocumentIds.length} ${provenance.sourceDocumentIds.length===1?'fuente':'fuentes'}.</p>${sources.map(source=>`<p><button class="text-button" data-open-source-detail="${escapeHtml(source.id)}">${escapeHtml(source.name)}</button></p>`).join('')}</section>`;
}
function hasRelatedDocumentKnowledge(item) {
  return Object.values(documentKnowledgeRelations(item)).some(records=>records.length>0);
}
function openDocumentKnowledge(id) {
  const item=sourceItems.find(record=>record.id===id);if(!item)return;
  const related=documentKnowledgeRelations(item);
  const section=(title,content)=>content?`<section class="drawer-section"><h3>${title}</h3>${content}</section>`:'';
  const links=(records,type)=>records.map(record=>explorationLink(record,type)).join('');
  const patterns=related.patterns.map(pattern=>{
    const direct=catalogSources(pattern).some(source=>source.id===item.id);
    const via=related.learnings.filter(learning=>(String(pattern.proof||'').match(/\bL-\d+\b/g)||[]).includes(learning.id));
    return explorationLink(pattern,'pattern')+(!direct&&via.length?`<p class="sub">A través de ${via.map(learning=>escapeHtml(learning.id)).join(', ')}.</p>`:'');
  }).join('');
  const body=section('Learnings relacionados',links(related.learnings,'learning'))+
    section('Evidencias relacionadas',links(related.evidence,'evidence'))+
    section('Test A/B relacionados',links(related.tests,'experiment'))+section('Patrones relacionados',patterns)+
    section('Conocimiento revisado',related.units.map(unit=>`<p><button class="text-button" data-document-unit="${escapeHtml(unit.id)}">${escapeHtml(unit.text)}</button></p>`).join(''))+
    section('Preguntas abiertas',related.questions.length?list(related.questions.map(question=>question.text)):'');
  openDrawer(`<div class="drawer-kicker">Conocimiento relacionado</div><h2>${escapeHtml(item.name)}</h2><p class="drawer-lead">${escapeHtml(pathOf(item))}</p>`,body||'<p>No hay conocimiento vinculado a esta fuente.</p>');
}
function documentExtraRelations(item) {
  const linked = collection=>collection.filter(record=>catalogSources(record).some(source=>source.id===item.id));
  const sections = [
    ['Evidencias relacionadas',linked(evidenceItems),'evidence'],['Test A/B relacionados',linked(experiments),'experiment'],['Patrones relacionados',linked(patternItems),'pattern']
  ].filter(([,records])=>records.length).map(([label,records,type])=>`<section class="drawer-section"><h3>${label}</h3>${records.map(record=>`<p><button class="text-button" data-detail="${type}" data-id="${record.id}">${escapeHtml(record.name||record.title)}</button></p>`).join('')}</section>`).join('');
  const events = evolutionState.events.filter(event=>event.documentId===item.id);
  const questionList = openQuestionItems.filter(question=>question.documentId===item.id).map(question=>({...question,status:evolutionState.questionUpdates.some(update=>update.id===question.id)?'Resuelta':question.status||'Abierta'}));
  const history = [
    item.analysis?.createdAt || item.analysis?.analyzedAt || item.ingestedAt ? {label:'Analizado',date:item.analysis?.createdAt||item.analysis?.analyzedAt||item.ingestedAt} : null,
    item.analysis?.review?.updatedAt?{label:'Revisado',date:item.analysis.review.updatedAt}:null,
    item.analysis?.publication?.publishedAt?{label:'Publicado',date:item.analysis.publication.publishedAt}:null
  ].filter(Boolean);
  return sections+(questionList.length?`<section class="drawer-section"><h3>Preguntas relacionadas</h3>${list(questionList.map(question=>`${question.text} · ${question.status}`))}</section>`:'')+(events.length?`<section class="drawer-section"><h3>Qué actualizó esta fuente</h3>${list(events.map(event=>`${event.before} → ${event.after} · ${formatDateEs(event.at)}`))}</section>`:'')+`<section class="drawer-section"><h3>Historial</h3>${history.length?list(history.map(event=>`${event.label} · ${formatDateEs(event.date)}`)):'<p>No hay fechas de análisis, revisión o publicación registradas.</p>'}${projectHistoryMessage()}</section>`;
}

function explorationQuestions() {
  return [...openQuestionItems, ...learnings.flatMap(learning=>(learning.open||[]).map((text,index)=>({...learning,id:`${learning.id}:question:${index}`,text,learningId:learning.id})))].map(question=>({...question,status:evolutionState.questionUpdates.some(update=>update.id===question.id)?'Resuelta':question.status||'Abierta'}));
}
function explorationLink(item,type) {
  const attribute=type==='learning'?`data-learning="${item.id}"`:type==='source'?`data-open-source-detail="${item.id}"`:`data-detail="${type}" data-id="${item.id}"`;
  return `<p><button class="text-button" ${attribute}>${escapeHtml(editorialCopy(item.title||item.name))}</button></p>`;
}
function exploreUnique(items) {
  const seen=new Set();return items.filter(item=>{const key=item.id||normalizeText(item.title||item.name||item.text||item.summary);if(!key||seen.has(key))return false;seen.add(key);return true;});
}
function exploreSourceTypes(item) {
  return [...new Set(catalogSources(item).map(source=>humanKnowledgeLabel(source.type)).filter(knownMetadata))];
}
function exploreRow(item,{title,summary='',meta=[],action='',actionLabel='Ver detalle'}={}) {
  const safeMeta=[...new Set(meta.filter(knownMetadata))];
  return `<article class="knowledge-row"><div class="knowledge-row-copy"><strong>${escapeHtml(editorialCopy(title||item.title||item.name||item.text))}</strong>${summary?`<p>${escapeHtml(editorialCopy(summary))}</p>`:''}${safeMeta.length?`<div class="knowledge-row-meta">${safeMeta.map(value=>`<span>${escapeHtml(value)}</span>`).join('')}</div>`:''}</div>${action?`<button class="relation-action knowledge-row-action" type="button" ${action}>${escapeHtml(actionLabel)}</button>`:''}</article>`;
}
function explorePanel({title,description='',items=[],row,visible=4,className=''}) {
  if(!items.length)return '';
  const first=items.slice(0,visible),rest=items.slice(visible);
  return `<section class="explore-section-panel ${className}"><header class="explore-section-head"><div><h3>${escapeHtml(title)}</h3>${description?`<p>${escapeHtml(description)}</p>`:''}</div><span class="explore-section-count" aria-label="${items.length} elementos">${items.length}</span></header>${first.map(row).join('')}${rest.length?`<details class="explore-more"><summary>Ver ${rest.length} ${rest.length===1?'elemento más':'elementos más'}</summary>${rest.map(row).join('')}</details>`:''}</section>`;
}
function openExplorationQuestion(id) {
  const item=explorationQuestions().find(question=>question.id===id);if(!item)return;
  const sources=catalogSources(item),related=item.learningId?learnings.find(learning=>learning.id===item.learningId):null;
  const header=`<div class="drawer-kicker">Pregunta abierta</div><h2>${escapeHtml(editorialCopy(item.text))}</h2><div class="drawer-tags"><span class="status-badge system-pending">${escapeHtml(item.status||'Abierta')}</span></div><div class="drawer-context"><div><strong>Dónde aplica:</strong> ${escapeHtml(pathOf(item)||'Contexto no especificado')}</div></div>`;
  const body=`${item.evidence?`<section class="drawer-section"><h3>Por qué está abierta</h3><p>${escapeHtml(editorialCopy(item.evidence))}</p></section>`:''}${related?`<section class="drawer-section"><h3>Learning relacionado</h3>${explorationLink(related,'learning')}</section>`:''}<section class="drawer-section"><h3>Fuentes</h3>${sources.length?sources.map(source=>explorationLink(source,'source')).join(''):'<p>No hay una fuente directa adicional vinculada.</p>'}</section>`;
  openDrawer(header,body);
}
function renderExplore() {
  if(globalThis.UXSimpleKnowledge)return globalThis.UXSimpleKnowledge.renderExplore({documents:typeof sourceItems==='undefined'?[]:sourceItems});
  const result=document.getElementById('explore-content'); if(!result)return;
  const contextSelected=['product','screen','component','element'].some(key=>document.getElementById(`explore-${key}`).value!=='Todos');
  const product=document.getElementById('explore-product').value;
  if(!contextSelected||product==='Todos'){result.innerHTML='';document.getElementById('explore-result').textContent='';return;}
  const control=(id,all='Todos')=>document.getElementById(id)?.value||all;
  const device=control('explore-device'),market=control('explore-market'),segment=control('explore-segment'),login=control('explore-login'),evidenceKind=control('explore-evidence-kind'),date=control('explore-date'),confidence=control('explore-confidence','Todas');
  const all=value=>value==='Todos'||value==='Todas';
  const sourceDateMatches=item=>all(date)||documentDate(item)===date||catalogSources(item).some(source=>documentDate(source)===date);
  const secondaryMatches=item=>matches(item.device,device)&&matches(item.market,market)&&matches(item.segment,segment)&&matches(item.loginStatus||item.login,login)&&(all(confidence)||item.confidence===confidence)&&sourceDateMatches(item);
  const evidenceKindMatches=item=>{
    if(all(evidenceKind))return true;
    if(matches(humanKnowledgeLabel(item.kind||item.type),evidenceKind))return true;
    const sources=catalogSources(item);if(!sources.length)return false;
    return evidenceRecords().some(evidence=>matches(humanKnowledgeLabel(evidence.kind||evidence.type),evidenceKind)&&catalogSources(evidence).some(source=>sources.some(other=>other.id===source.id)));
  };
  const filtered=items=>hierarchyFilter(items,'explore').filter(secondaryMatches).filter(evidenceKindMatches);
  const selectedScreen=control('explore-screen'),selectedComponent=control('explore-component');
  const legacyComponentMatch=item=>!all(selectedComponent)&&componentsOf(item).includes(selectedComponent)&&(all(selectedScreen)||item.screen===selectedScreen)&&secondaryMatches(item)&&evidenceKindMatches(item);
  const learningSet=filtered(learnings),evidenceSet=displayEvidenceItems(filtered(evidenceRecords()));
  const testSet=exploreUnique([...filtered(experiments),...experiments.filter(legacyComponentMatch)]);
  const patternSet=exploreUnique([...filtered(patternItems),...patternItems.filter(legacyComponentMatch)]);
  const documentSet=exploreUnique([...filtered(sourceItems),...sourceItems.filter(legacyComponentMatch)]);
  const validationSet=filtered(evolutionState.validations);
  const questionSet=exploreUnique(filtered(explorationQuestions()).filter(question=>question.status!=='Resuelta'));
  const opportunitySet=exploreUnique(filtered(knowledgeUnits).filter(item=>['Oportunidad','Hipótesis','Recomendación','Recomendación de sistema'].includes(item.type)));
  const records=[...learningSet,...evidenceSet,...testSet,...patternSet,...opportunitySet];
  if(!records.length&&!documentSet.length&&!validationSet.length&&!questionSet.length){result.innerHTML='<div class="analysis-empty"><h2>Todavía no hay conocimiento para este contexto</h2><p>La taxonomía está disponible, pero no hay fuentes relacionadas con esta selección. No significa que no existan problemas o restricciones.</p></div>';document.getElementById('explore-result').textContent='Sin contenido relacionado';return;}

  const selected={product,screen:selectedScreen,component:selectedComponent,element:control('explore-element')};
  const path=[selected.product,selected.screen,selected.component,selected.element].filter(value=>!all(value));
  const contextName=[selected.element,selected.component,selected.screen,selected.product].find(value=>value&&!all(value))||selected.product;
  const sourceLabel=item=>exploreSourceTypes(item).slice(0,2).join(' + ')||humanKnowledgeLabel(item.kind||item.type||'Fuente no especificada');
  const contextMeta=item=>pathOf(item)&&pathOf(item)!==path.join(' / ')?pathOf(item):'';
  const learningRow=item=>exploreRow(item,{summary:item.know||item.text,meta:[`Confianza ${String(item.confidence||'no especificada').toLowerCase()}`,sourceLabel(item),contextMeta(item)],action:`data-learning="${escapeHtml(item.id)}"`,actionLabel:'Ver learning'});
  const evidenceRow=item=>exploreRow(item,{summary:evidenceExplanation(item),meta:[humanKnowledgeLabel(item.kind||item.type),item.confidence?`Confianza ${String(item.confidence).toLowerCase()}`:'',evidenceMetadata(item)],action:`data-detail="evidence" data-id="${escapeHtml(item.id)}"`,actionLabel:'Ver evidencia'});
  const experimentRow=item=>exploreRow(item,{summary:item.interpretation||item.result,meta:[`Resultado ${String(item.outcome||'no especificado').toLowerCase()}`,item.device,contextMeta(item)],action:`data-detail="experiment" data-id="${escapeHtml(item.id)}"`,actionLabel:'Ver test'});
  const patternRow=item=>exploreRow(item,{summary:item.description||item.do,meta:['Patrón',item.confidence?`Confianza ${String(item.confidence).toLowerCase()}`:'',contextMeta(item)],action:`data-detail="pattern" data-id="${escapeHtml(item.id)}"`,actionLabel:'Ver patrón'});
  const opportunityRow=item=>exploreRow(item,{title:item.text||item.name,summary:item.confidenceWhy||'',meta:[humanKnowledgeLabel(item.type),item.confidence?`Confianza ${String(item.confidence).toLowerCase()}`:'',contextMeta(item)],action:`data-document-unit="${escapeHtml(item.id)}"`,actionLabel:'Ver detalle'});
  const questionRow=item=>exploreRow(item,{title:item.text,summary:item.evidence||'',meta:['Pregunta abierta',contextMeta(item)],action:`data-question-detail="${escapeHtml(item.id)}"`,actionLabel:'Ver contexto'});

  const benchmarkEvidence=evidenceSet.filter(item=>/benchmark/i.test(`${item.kind||''} ${item.type||''} ${item.name||''}`));
  const principleEvidence=evidenceSet.filter(item=>!benchmarkEvidence.includes(item)&&(/extern|desk research|conductual|cognitiv|psicolog|sesgo|principio/i.test(`${item.kind||''} ${item.type||''} ${item.name||''} ${item.contribution||''}`)||catalogSources(item).some(source=>/extern|desk research|conductual|cognitiv|psicolog|sesgo/i.test(`${source.type||''} ${source.name||''}`))));
  const observedEvidence=evidenceSet.filter(item=>!benchmarkEvidence.includes(item)&&!principleEvidence.includes(item)&&!/test a\/?b|experimento/i.test(`${item.kind||''} ${item.type||''}`));
  const outcomeOrder=['Positivo','Neutral','Negativo','Mixto'];
  const outcomes=outcomeOrder.map(outcome=>({outcome,items:testSet.filter(item=>item.outcome===outcome)})).filter(group=>group.items.length);
  const testPanel=outcomes.length?`<section class="explore-section-panel"><header class="explore-section-head"><div><h3>Qué hemos probado</h3><p>Resultados y aprendizaje derivado de cada test, incluidos los resultados neutrales, negativos o mixtos.</p></div><span class="explore-section-count" aria-label="${testSet.length} tests">${testSet.length}</span></header><div class="explore-outcome-groups">${outcomes.map(group=>`<div class="explore-outcome-group"><h4 class="explore-outcome-title"><span class="explore-outcome-dot ${normalizeText(group.outcome)}"></span>${escapeHtml(group.outcome)}</h4>${group.items.map(experimentRow).join('')}</div>`).join('')}</div></section>`:'';
  const avoidItems=[];
  patternSet.forEach(item=>{if(item.avoid)avoidItems.push({id:`avoid-${item.id}`,title:item.avoid,summary:`Riesgo documentado en ${item.title}.`,meta:['Patrón'],action:`data-detail="pattern" data-id="${escapeHtml(item.id)}"`,label:'Ver patrón'});});
  learningSet.forEach(item=>(item.contrary||[]).forEach((text,index)=>avoidItems.push({id:`contrary-${item.id}-${index}`,title:text,summary:`Matiz o evidencia que no coincide con ${item.title}.`,meta:['Contradicción o límite'],action:`data-learning="${escapeHtml(item.id)}"`,label:'Ver learning'})));
  testSet.filter(item=>['Neutral','Negativo','Mixto'].includes(item.outcome)).forEach(item=>avoidItems.push({id:`test-${item.id}`,title:item.interpretation||item.result,summary:item.title,meta:[`Resultado ${String(item.outcome).toLowerCase()}`],action:`data-detail="experiment" data-id="${escapeHtml(item.id)}"`,label:'Ver test'}));
  validationSet.forEach(item=>avoidItems.push({id:`validation-${item.id}`,title:item.text,summary:item.technicalStatus||item.solutionStatus||'',meta:['Restricción conocida'],action:`data-validation-detail="${escapeHtml(item.id)}"`,label:'Ver restricción'}));
  const avoidSet=exploreUnique(avoidItems);
  const avoidRow=item=>exploreRow(item,{title:item.title,summary:item.summary,meta:item.meta,action:item.action,actionLabel:item.label});
  const sourceRow=item=>exploreRow(item,{summary:`${humanKnowledgeLabel(item.type)} · ${documentDate(item)}`,meta:[pathOf(item),documentStatusLabel(item.status)],action:`data-open-source-detail="${escapeHtml(item.id)}"`,actionLabel:'Ver fuente'});

  const knowledgePanel=explorePanel({title:'Qué sabemos',description:'Learnings consolidados más relevantes para este contexto.',items:learningSet,row:learningRow,visible:4,className:'explore-primary-knowledge'});
  const observedPanel=explorePanel({title:'Qué hemos observado en Air Europa',description:'Research, comportamiento y datos internos. Una observación no demuestra por sí sola causalidad.',items:observedEvidence,row:evidenceRow,visible:5});
  const principles=exploreUnique([...patternSet,...principleEvidence]);
  const principleRow=item=>patternSet.includes(item)?patternRow(item):evidenceRow(item);
  const principlePanel=explorePanel({title:'Principios y buenas prácticas respaldadas',description:'Patrones o evidencia externa relevantes. No equivalen a una aplicación validada en Air Europa.',items:principles,row:principleRow,visible:4});
  const benchmarkPanel=explorePanel({title:'Patrones de benchmark',description:'Qué hacen otros referentes y qué puede inspirar, sin asumir que funciona igual en Air Europa.',items:benchmarkEvidence,row:evidenceRow,visible:4});
  const avoidPanel=explorePanel({title:'Qué evitar',description:'Resultados, límites, contradicciones y riesgos que conviene tener presentes al diseñar.',items:avoidSet,row:avoidRow,visible:5});
  const opportunityPanel=explorePanel({title:'Oportunidades y qué podríamos probar',description:'Recomendaciones, hipótesis y oportunidades todavía no validadas.',items:opportunitySet,row:opportunityRow,visible:5});
  const questionPanel=explorePanel({title:'Qué falta saber',description:'Preguntas abiertas relevantes para este contexto.',items:questionSet,row:questionRow,visible:5});
  const sourcePanel=documentSet.length?`<section class="explore-section-panel"><details class="explore-source-disclosure"><summary>Fuentes y trazabilidad · ${documentSet.length}</summary>${documentSet.map(sourceRow).join('')}</details></section>`:'';
  const visibleSections=[knowledgePanel,observedPanel,testPanel,principlePanel,benchmarkPanel,avoidPanel,opportunityPanel,questionPanel].filter(Boolean).length;
  document.getElementById('explore-result').textContent=`${learningSet.length} ${learningSet.length===1?'learning':'learnings'} · ${visibleSections} bloques`;
  result.innerHTML=`<div class="explore-knowledge-view"><header class="explore-context-head"><div><span class="eyebrow">${escapeHtml(path.join(' / '))}</span><h2>${escapeHtml(contextName)} · Qué sabemos</h2><p>Conocimiento, evidencia y cuestiones pendientes reunidos en el contexto seleccionado.</p></div><span class="explore-context-count">${records.length} referencias relacionadas</span></header>${knowledgePanel}${observedPanel}${testPanel}${principlePanel}${benchmarkPanel}${avoidPanel}${opportunityPanel}${questionPanel}${sourcePanel}</div>`;
}

function documentEvolutionProposals(item) {
  if(!hasDocumentAnalysis(item)||isDocumentPublished(item))return [];
  const records=buildReviewInterpretation(item.analysis).units.map(unit=>normalizeCatalogContext({...unit,documentId:item.id,sourceName:item.name}));
  const insights=reviewInsightsForDocument(item);
  const technical=UXKnowledge.technicalProposals(records,evolutionState.validations,explorationQuestions()).map(proposal=>{
    const insight=insights.find(insight=>insight.findings.some(unit=>unit.id===proposal.unitId));
    const opportunities=knowledgeUnits.filter(unit=>['Oportunidad','Recomendación de sistema'].includes(unit.type)&&unit.documentId===item.id&&unit.clusterId===insight?.id);
    return {...proposal,relationIds:[...new Set([...(proposal.relationIds||[]),insight?.learningId,...opportunities.map(unit=>unit.id)].filter(Boolean))]};
  });
  const pairs=UXKnowledge.equivalenceProposals([...evidenceRecords(),...records]).filter(proposal=>records.some(record=>record.id===proposal.b)&&!records.some(record=>record.id===proposal.a)).map(proposal=>({...proposal,documentId:item.id,unitId:proposal.b}));
  return [...technical,...pairs];
}
function evolutionProposalMarkup(item) {
  const proposals=documentEvolutionProposals(item);if(!proposals.length)return '';
  const selected=evolutionState.selections[item.id]||[];
  return `<details class="cluster-card"><summary><span class="cluster-title"><strong>Posibles actualizaciones del conocimiento</strong><span>${proposals.length} coincidencias para comprobar · no modifican las decisiones ya revisadas</span></span><span class="cluster-disclosure">Ver propuestas</span></summary><div class="cluster-body"><p>Compara el origen y el contexto antes de incluir una actualización. Solo se aplicará desde el preview al publicar.</p>${proposals.map(proposal=>`<section class="drawer-section"><h3>${proposal.type==='technical'?'Validación técnica':proposal.type==='question'?'Posible pregunta resuelta':proposal.type==='contradiction'?'Posible contradicción':'Misma idea en otra fuente'}</h3><p><strong>Actual:</strong> ${escapeHtml(proposal.before)}</p><p><strong>Esta fuente:</strong> ${escapeHtml(proposal.after)}</p>${proposal.text?`<p>${escapeHtml(proposal.text)}</p>`:''}<p>${escapeHtml(pathOf(proposal.context||{}))}${proposal.source?.page?` · página ${proposal.source.page}`:''}</p>${reviewCanEdit(item)&&proposal.type!=='contradiction'?`<label><input type="checkbox" data-evolution-select="${escapeHtml(proposal.id)}" ${selected.includes(proposal.id)?'checked':''}> Incluir esta actualización en el preview</label>`:'<p>Conservada para contrastar; no se fusiona automáticamente.</p>'}</section>`).join('')}</div></details>`;
}
function selectedEvolutionProposals(item) { const selected=evolutionState.selections[item.id]||[];return documentEvolutionProposals(item).filter(proposal=>selected.includes(proposal.id)); }
function evolutionConflicts(item,plan) {
  const proposals=selectedEvolutionProposals(item),conflicts=[];
  proposals.filter(proposal=>proposal.type==='equivalence').forEach(proposal=>{
    const operation=plan.operations.find(operation=>operation.findings.some(unit=>unit.id===proposal.unitId));
    if(operation?.decision==='Crear nuevo learning')conflicts.push(`“${operation.name}” está marcado como nuevo learning y como evidencia equivalente. Revisa esa decisión antes de publicar.`);
  });
  proposals.filter(proposal=>proposal.type==='technical'&&proposal.targetId).forEach(proposal=>{
    if(proposals.some(other=>other.id!==proposal.id&&other.targetId===proposal.targetId&&other.after!==proposal.after))conflicts.push('Hay dos estados técnicos distintos propuestos para la misma validación. Elige cuál corresponde.');
  });
  return [...new Set(conflicts)];
}
function evolutionPreviewMarkup(item) {
  const proposals=selectedEvolutionProposals(item);return proposals.length?`<section class="drawer-section"><h3>Actualizaciones que has seleccionado</h3>${list(proposals.map(proposal=>`${proposal.type==='technical'?'Validación técnica':proposal.type==='question'?'Resolver pregunta':'Consolidar evidencia'}: ${proposal.before} → ${proposal.after}`))}<p>Se conservarán el estado anterior, esta fuente y la fecha de la decisión.</p></section>`:'';
}
function openValidation(id) {
  const item=evolutionState.validations.find(record=>record.id===id);if(!item)return;
  const header=`<div class="drawer-kicker">Validación técnica</div><h2>${escapeHtml(item.text)}</h2><p class="drawer-lead">${escapeHtml(item.technicalStatus)} · ${escapeHtml(item.status)}</p>`;
  const body=`<section class="drawer-section"><h3>Contexto</h3><p>${escapeHtml(pathOf(item))}</p><p>${escapeHtml(item.device||'Dispositivo no especificado')} · ${escapeHtml(item.market||'Mercado no especificado')}</p></section><section class="drawer-section"><h3>Solución UX</h3><p>${escapeHtml(item.solutionStatus||'No definida')}</p></section>${item.variants?.length?`<section class="drawer-section"><h3>Alternativas según viabilidad</h3>${list(item.variants.map(variant=>`${variant.condition}: ${variant.solution}`))}</section>`:''}<section class="drawer-section"><h3>Histórico</h3>${(item.history||[]).map(event=>`<p>${escapeHtml(formatDateEs(event.at))} · ${escapeHtml(event.before)} → ${escapeHtml(event.after)}<br><button class="text-button" data-open-source-detail="${escapeHtml(event.documentId)}">Ver fuente</button></p>`).join('')}</section>`;
  openDrawer(header,body);
}
document.addEventListener('click',event=>{
  const view=event.target.closest('[data-source-view]');if(view)consultDocument(view.dataset.sourceView);
  const knowledge=event.target.closest('[data-source-knowledge]');if(knowledge)openDocumentKnowledge(knowledge.dataset.sourceKnowledge);
  const unit=event.target.closest('[data-document-unit]');if(unit)openKnowledgeUnit(unit.dataset.documentUnit);
  const question=event.target.closest('[data-question-detail]');if(question)openExplorationQuestion(question.dataset.questionDetail);
  const validation=event.target.closest('[data-validation-detail]');if(validation)openValidation(validation.dataset.validationDetail);
});
document.addEventListener('change',event=>{
  const checkbox=event.target.closest('[data-evolution-select]'),item=typeof activeReviewDocument==='function'?activeReviewDocument():null;
  if(!checkbox||!reviewCanEdit(item))return;
  const selected=new Set(evolutionState.selections[item.id]||[]);
  checkbox.checked?selected.add(checkbox.dataset.evolutionSelect):selected.delete(checkbox.dataset.evolutionSelect);
  evolutionState.selections[item.id]=[...selected];queueProjectHistory();
});
