/* Derived knowledge index. Never changes source findings, classification or confidence. */
(function (root) {
  'use strict';
  const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const unique = values => [...new Set(values.filter(Boolean))];
  const unknown = value => !value || /^(no especificad[oa]|desconocid[oa]|sin clasificar)$/.test(normalize(value));
  const terms = [
    [/\b(accesos operativos|accesos de autogestion|autoservicio|autogestion)\b/g, 'autogestion'],
    [/\b(buscar vuelos|busqueda de vuelos|buscador de vuelos)\b/g, 'busqueda'],
    [/\b(visible[s]?|visibilidad|presencia)\b/g, 'visible'],
    [/\b(prioritario|prioridad|protagonismo|jerarquia principal)\b/g, 'prioridad'],
    [/\b(ordenar|reordenar|organizar|organizacion)\b/g, 'orden'],
    [/\b(movil|moviles|mobile)\b/g, 'mobile'],
    [/\b(escritorio|desktop)\b/g, 'desktop'],
    [/\b(recuperar|recuperacion)\b/g, 'recuperar'],
    [/\b(permitir|permite|permitido|disponible|disponibilidad del dato)\b/g, 'disponible'],
  ];
  function canonical(text) { let result = normalize(text); for (const [pattern, replacement] of terms) result = result.replace(pattern, replacement); return result.replace(/[^a-z0-9%]+/g, ' ').trim(); }
  const stop = new Set('a al de del el la las los un una unos unas en y o para por que se es son debe deben como con su sus lo sobre entre mas este esta estos estas desde seguir siendo ganar mantener sin'.split(' '));
  function tokens(text) { return new Set(canonical(text).split(' ').filter(word => word.length > 2 && !stop.has(word))); }
  function similarity(a, b) { const x = tokens(a), y = tokens(b); if (!x.size || !y.size) return 0; return [...x].filter(word => y.has(word)).length / Math.sqrt(x.size * y.size); }
  const dimensions = ['product','screen','component','element','device','market','segment','journey','passengerType','route','fare','identity','sessionState','zone'];
  function scope(item) {
    return dimensions.map(key => {
      const value = key === 'component' ? unique([...(item.components || []), item.component]).map(normalize).sort().join('|') : key === 'device' ? canonical(item[key]).split(/\s+(?:y)\s+|\s*\+\s*|,\s*/).sort().join('|') : normalize(item[key]);
      return unknown(value) ? '' : value;
    });
  }
  function compatible(a, b) {
    const x = scope(a), y = scope(b);
    // Missing context is not a license to generalize between journeys or devices.
    return Boolean(x[0] && x[1] && x[2]) && x.every((value, index) => value === y[index]);
  }
  function polarity(text) {
    const value = normalize(text);
    if (/\b(pendiente|validar|hipotesis|quizas|podria|por confirmar)\b|\?/.test(value)) return 'uncertain';
    return /\b(no|nunca|impide|empeora|reduce|disminuye|sin desplazar|sin perjudicar)\b/.test(value) ? 'qualified' : 'affirmative';
  }
  const textOf = item => item.authorSynthesis || item.contribution || item.text || item.know || item.description || item.title || item.name || '';
  const sourcesOf = item => item.sources || (item.documentId ? [{ id: item.documentId, name: item.sourceName || item.documentId, page: item.source?.page, recordId: item.id }] : []);
  function comparison(a, b) {
    const context = compatible(a, b), score = similarity(textOf(a), textOf(b));
    const sameKind = normalize(a.kind || a.type) === normalize(b.kind || b.type);
    const samePolarity = polarity(textOf(a)) === polarity(textOf(b));
    return { context, score, exact: context && sameKind && samePolarity && canonical(textOf(a)) === canonical(textOf(b)), candidate: context && sameKind && samePolarity && score >= .55, contradiction: context && !samePolarity && score >= .6 };
  }
  function consolidate(records, approvals = []) {
    const groups = [];
    for (const record of records) {
      // Automatic grouping requires exact equivalence with every member.
      // Human-confirmed links may add sources to an established idea, but never cross context boundaries.
      const group = groups.find(group => group.members.every(member => compatible(member,record)) && (
        group.members.every(member => comparison(member,record).exact) ||
        group.members.some(member => approvals.some(link => link.status==='confirmed' && [link.a,link.b].includes(member.unitId||member.id) && [link.a,link.b].includes(record.unitId||record.id)))
      ));
      if (group) group.members.push(record); else groups.push({ id: record.id, members: [record] });
    }
    return groups.map(group => {
      const representative = group.members.find(item => item.authorSynthesis || item.type === 'Insight del autor') || group.members[0];
      const sources = [...new Map(group.members.flatMap(sourcesOf).map(source => [JSON.stringify([source.id, source.page, source.recordId]), source])).values()];
      return { ...group, representative, text: textOf(representative), sources, sourceCount: unique(sources.map(source => source.id)).length,
        nuances: unique(group.members.flatMap(item => [item.nuance, ...(item.nuances || [])])),
        contradictions: unique(group.members.flatMap(item => item.contrary || [])),
        limits: unique(group.members.flatMap(item => item.noProof || item.limits || [])),
        questions: unique(group.members.flatMap(item => item.open || [])),
        // Deliberately no confidence aggregation or uplift based on repetitions.
        confidence: representative.confidence || 'No especificada' };
    });
  }
  function equivalenceProposals(records) {
    const proposals = [];
    records.forEach((record, index) => records.slice(index + 1).forEach(other => {
      const match = comparison(record, other);
      if (!match.exact && (match.candidate || match.contradiction)) proposals.push({ id: `equivalence:${record.unitId || record.id}:${other.unitId || other.id}`, type: match.contradiction ? 'contradiction' : 'equivalence', a: record.unitId || record.id, b: other.unitId || other.id, score: match.score, before: textOf(record), after: textOf(other), source:other.source, context:Object.fromEntries(dimensions.map(key=>[key,other[key]||''])) });
    }));
    return proposals.sort((a,b) => b.score - a.score);
  }
  // Navigation topics are not new knowledge units and never merge learning content.
  // Names come from recurring contexts or phrases in the actual records, not a topic catalog.
  function thematicGroups(records) {
    // Topic labels use literal phrases. Synonyms for evidence comparison are too
    // broad here ("Buscar vuelos" must not become every mention of "búsqueda").
    const topicKey=value=>normalize(value).replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
    const broad = new Set(records.flatMap(item => [item.product,item.screen,item.component,...(item.components||[])]).filter(Boolean).map(topicKey));
    const candidates = new Map();
    const content = item => topicKey([item.title,item.know,item.text,item.zone,item.element,...(item.contextConcepts||[]),...(item.applications||[])].filter(Boolean).join(' '));
    const add = (label, explicit=false) => {
      const key=topicKey(label);
      if (!key || broad.has(key) || key.split(' ').length>6) return;
      const previous=candidates.get(key);
      candidates.set(key,{key,label:previous?.label||label,explicit:explicit||previous?.explicit});
    };
    records.forEach(item=>{
      [item.zone,item.element,...(item.contextConcepts||[]),...(item.applications||[])].filter(Boolean).forEach(label=>add(label,true));
      [item.title,item.know,item.text].filter(Boolean).flatMap(text=>text.split(/[;,:.!?]/)).forEach(clause=>{
        const words=clause.trim().split(/\s+/);
        for(let size=2;size<=4;size++)for(let i=0;i+size<=words.length;i++){
          const phrase=words.slice(i,i+size),keys=phrase.map(topicKey);
          if(keys.some(key=>/^(debe|deben|puede|pueden|necesita|necesitan|es|son|no|como|cuando|mantiene|reduce)$/.test(key))||/^(decision|decisiones|criterio|criterios|learning|learnings|aprendizaje|aprendizajes|evidencia|evidencias|resultado|resultados)$/.test(keys[0])||stop.has(keys[0])||stop.has(keys.at(-1)))continue;
          add(phrase.join(' '));
        }
      });
    });
    const remaining=new Set(records),groups=[];
    while(remaining.size){
      const ranked=[...candidates.values()].map(candidate=>{
        const members=[...remaining].filter(item=>(' '+content(item)+' ').includes(' '+candidate.key+' '));
        // A theme never combines different products or screens just because words repeat.
        const partitions=new Map();
        members.forEach(item=>{const key=JSON.stringify([normalize(item.product),normalize(item.screen)]);if(!partitions.has(key))partitions.set(key,[]);partitions.get(key).push(item);});
        return [...partitions.values()].filter(items=>items.length>1).map(items=>({...candidate,members:items,score:items.length*(candidate.explicit?1.1:1)+Math.min(candidate.key.split(' ').length,4)/20}));
      }).flat().sort((a,b)=>b.score-a.score||a.key.localeCompare(b.key));
      if(!ranked.length)break;
      const best=ranked[0];groups.push({title:best.label.charAt(0).toUpperCase()+best.label.slice(1),learnings:best.members,grouped:true});best.members.forEach(item=>remaining.delete(item));
    }
    remaining.forEach(item=>groups.push({title:item.title,learnings:[item],grouped:false}));
    return groups;
  }
  const feasibilityStates = ['Pendiente','Viable','Viable con restricciones','No viable actualmente','Desconocida'];
  const solutionStates = ['No definida','Propuesta','Diseñada','Entregada','Testada','Recomendada','Implementada','Descartada','Desconocida'];
  const knowledgeKinds = ['Hecho','Evidencia interna','Evidencia externa','Hallazgo','Insight del autor','Hipótesis','Inferencia','Oportunidad','Learning consolidado','Patrón','Experimento','Resultado','Decisión'];
  const confidenceLevels = ['Alta','Media','Baja'];
  const evidenceOrigins = ['Interna','Externa','Mixta','No especificada'];
  const experimentResults = ['Positivo','Neutral','Negativo','Mixto','No especificado'];
  const implementationStates = ['Implementado','No implementado','Desconocida'];
  const recommendationStates = ['Observado','Recomendado','No especificado'];
  const internalValidationStates = ['No demostrada','Pendiente','Testada','Reforzada','Validada','Limitada','Contradicha','No especificada'];
  const explicit = (item, keys) => keys.map(key => key.split('.').reduce((value,part)=>value?.[part],item)).find(value => value !== undefined && value !== null && String(value).trim() !== '');
  const listed = (value, values, fallback) => values.find(option => normalize(option) === normalize(value)) || fallback;
  function evidenceOrigin(item) {
    const declared=explicit(item,['evidenceOrigin','originType','origin']);
    if(declared)return listed(declared,evidenceOrigins,'No especificada');
    // Only the explicit catalog type is accepted as origin. A tool or method name
    // (QM, CRO, research, benchmark...) is not enough to infer ownership.
    return ({interna:'Interna',externa:'Externa'})[normalize(item?.type)] || 'No especificada';
  }
  function knowledgeState(item) {
    const confidence=listed(explicit(item,['confidence']),confidenceLevels,'No especificada');
    const validation=listed(explicit(item,['internalValidation','validation.status']),internalValidationStates,'No especificada');
    const result=listed(explicit(item,['experimentResult','outcome']),experimentResults,'No especificado');
    const implementation=listed(explicit(item,['implementation','implementationStatus','pro']),implementationStates,'Desconocida');
    const recommendation=listed(explicit(item,['recommendationStatus','status']),recommendationStates,'No especificado');
    return {confidence,internalValidation:validation,experimentResult:result,recommendation,implementation};
  }
  function experimentLineage(item) {
    const lineage=item?.lineage||{};
    return {
      lineId:explicit(item,['experimentLineId','lineage.lineId'])||'',
      previousExperimentIds:unique([...(item?.previousExperimentIds||[]),...(lineage.previousExperimentIds||[])]),
      nextExperimentIds:unique([...(item?.nextExperimentIds||[]),...(lineage.nextExperimentIds||[])]),
      derivedFromLearningIds:unique([...(item?.derivedFromLearningIds||[]),...(lineage.derivedFromLearningIds||[])]),
      iteration:explicit(item,['iteration','lineage.iteration'])||'',
      multiChangeLimitation:explicit(item,['multiChangeLimitation','lineage.multiChangeLimitation'])||''
    };
  }
  function patternProvenance(item) {
    const provenance=item?.provenance||{};
    return {
      sourceIds:unique([...(item?.sourceIds||[]),...(provenance.sourceIds||[])]),
      evidenceIds:unique([...(item?.evidenceIds||[]),...(provenance.evidenceIds||[])]),
      learningIds:unique([...(item?.learningIds||[]),...(provenance.learningIds||[])]),
      experimentIds:unique([...(item?.experimentIds||[]),...(provenance.experimentIds||[])]),
      uiKitReferences:unique([...(item?.uiKitReferences||[]),...(provenance.uiKitReferences||[])]),
      limitations:unique([...(item?.limitations||[]),...(provenance.limitations||[])]),
      contradictions:unique([...(item?.contradictions||[]),...(provenance.contradictions||[])])
    };
  }
  function documentProvenance(item) {
    const provenance=item?.provenance||{};
    return {
      role:explicit(item,['documentRole','provenance.role'])||'No especificado',
      curated:explicit(item,['curated','provenance.curated'])===true,
      sourceDocumentIds:unique([...(item?.sourceDocumentIds||[]),...(provenance.sourceDocumentIds||[])])
    };
  }
  function technicalSignal(item) {
    const text = textOf(item), value = normalize(text);
    if (!/\b(amadeus|magnolia|pss|api|proveedor|tecnolog|tecnic|restriccion|cms)\w*\b/.test(value)) return null;
    let state = 'Desconocida';
    if (/\b(pendiente|confirmar|validar|comprobar|consultar)\b|\?/.test(value)) state = 'Pendiente';
    else if (/\b(no permite|no disponible|no soporta|no viable|impide|imposible)\b/.test(value)) state = 'No viable actualmente';
    else if (/\b(con restricciones|parcial|limitad|condicionado)\w*\b/.test(value)) state = 'Viable con restricciones';
    else if (/\b(permite|disponible|soporta|viable|confirmado)\b/.test(value)) state = 'Viable';
    // A vendor mention alone is neither a restriction nor a validation question.
    if (state === 'Desconocida' && !/\b(desconoc|desconoce|sin confirmar)\w*\b/.test(value)) return null;
    return { text, proposedState: state, source: item.documentId, unitId: item.id, context: Object.fromEntries(dimensions.map(key => [key, item[key] || ''])), reviewed: false };
  }
  function technicalProposals(records, validations = [], questions = []) {
    return records.flatMap(record => {
      const signal = technicalSignal(record);
      const result = [];
      if (signal) {
        const target = validations.filter(item => compatible(record, item) && similarity(textOf(record), textOf(item)) >= .4).sort((a,b) => similarity(textOf(record),textOf(b))-similarity(textOf(record),textOf(a)))[0];
        if (!target || signal.proposedState !== target.technicalStatus) result.push({ id: `technical:${record.id}:${target?.id || 'new'}`, type: 'technical', targetId: target?.id || '', unitId: record.id, documentId: record.documentId, before: target?.technicalStatus || 'Sin validación registrada', after: signal.proposedState, text: signal.text, context: signal.context, source: record.source, relationIds: target?.relationIds || [] });
      }
      // Only an explicit answer can be suggested as resolution; never close on similarity alone.
      if (/\b(confirmado|se confirma|permite|resuelto|disponible)\b/.test(normalize(textOf(record))) && !/\b(no|pendiente|validar|confirmar)\b|\?/.test(normalize(textOf(record)))) {
        questions.filter(question => question.status !== 'Resuelta' && compatible(question, record) && similarity(question.text, textOf(record)) >= .45).forEach(question => result.push({ id: `question:${record.id}:${question.id}`, type: 'question', targetId: question.id, unitId: record.id, documentId: record.documentId, before: question.text, after: textOf(record), text: textOf(record), context: signal?.context || Object.fromEntries(dimensions.map(key=>[key,record[key]||''])), source: record.source }));
      }
      return result;
    });
  }
  function applyEvolution(state, proposals, timestamp) {
    const next = JSON.parse(JSON.stringify(state));
    next.validations ||= []; next.questionUpdates ||= []; next.equivalences ||= []; next.events ||= [];
    proposals.forEach(proposal => {
      if (next.events.some(event => event.proposalId === proposal.id)) return;
      const event = { proposalId: proposal.id, type: proposal.type, documentId: proposal.documentId, unitId: proposal.unitId, source: proposal.source, before: proposal.before, after: proposal.after, at: timestamp };
      if (proposal.type === 'technical') {
        if (!feasibilityStates.includes(proposal.after)) throw Error('Estado de validación no válido');
        let target = next.validations.find(item => item.id === proposal.targetId);
        if (!target) { target = { id: proposal.targetId || `V-${proposal.unitId}`, text: proposal.text, ...proposal.context, technicalStatus: 'Desconocida', solutionStatus: 'No definida', history: [], relationIds: proposal.relationIds || [], variants: [] }; next.validations.push(target); }
        event.before = target.technicalStatus;
        event.previousSource = target.documentId || target.history.at(-1)?.documentId || null;
        event.previousSourceDetail = target.history.at(-1)?.source || null;
        target.technicalStatus = proposal.after;
        target.relationIds = unique([...(target.relationIds || []), ...(proposal.relationIds || [])]);
        target.status = proposal.after === 'Viable' ? 'Resuelta' : 'Vigente';
        target.history.push(event); target.documentId = proposal.documentId;
      } else if (proposal.type === 'question') next.questionUpdates.push({ id: proposal.targetId, status: 'Resuelta', ...event });
      else if (proposal.type === 'equivalence') next.equivalences.push({ a: proposal.a, b: proposal.b, status: 'confirmed', ...event });
      next.events.push(event);
    });
    return next;
  }
  root.UXKnowledge = { normalize, canonical, similarity, compatible, comparison, consolidate, equivalenceProposals, thematicGroups, technicalSignal, technicalProposals, applyEvolution, textOf, feasibilityStates, solutionStates, knowledgeKinds, confidenceLevels, evidenceOrigins, experimentResults, implementationStates, recommendationStates, internalValidationStates, evidenceOrigin, knowledgeState, experimentLineage, patternProvenance, documentProvenance };
})(typeof window === 'undefined' ? globalThis : window);
